# PC তে রান ও টেস্ট করার সম্পূর্ণ গাইড

এই গাইডটা উপর থেকে নিচে, ক্রমানুসারে অনুসরণ করুন। প্রতিটা ধাপে ✅ না পাওয়া পর্যন্ত পরের ধাপে যাবেন না।

---

## ধাপ ০ — সফটওয়্যার আছে কিনা চেক

Git Bash খুলে এই চারটা কমান্ড একে একে চালান:
```bash
php -v
composer -V
node -v
git --version
```
**চেক করুন:** প্রতিটা একটা version number দেখাবে। কোনোটা "command not found" দিলে সেটা ইনস্টল করুন:
- PHP না থাকলে: XAMPP ইনস্টল করুন (apachefriends.org), তারপর PATH এ `C:\xampp\php` যোগ করুন
- Composer না থাকলে: getcomposer.org/download
- Node না থাকলে: nodejs.org (LTS ভার্সন)
- Git না থাকলে: git-scm.com

---

## ধাপ ১ — XAMPP চালু

XAMPP Control Panel খুলে **Apache** এর পাশে "Start" চাপুন।

**চেক করুন:** Apache এর status সবুজ "Running" দেখাচ্ছে।

---

## ধাপ ২ — Zip Extract করা

`buyinghouse-erp-installer.zip` কে **`C:\xampp\htdocs\`** এর ভেতরে extract করুন।

**চেক করুন:** এই path টা থাকা উচিত:
```
C:\xampp\htdocs\buyinghouse-erp-package\install.sh
```

---

## ধাপ ৩ — পুরনো ফোল্ডার পরিষ্কার (যদি আগে চেষ্টা করে থাকেন)

Git Bash এ:
```bash
rm -rf ~/buyinghouse-erp-app
```

**চেক করুন:** `ls ~/buyinghouse-erp-app` চালালে "No such file or directory" আসা উচিত।

---

## ধাপ ৪ — Install Script চালানো

```bash
cd /c/xampp/htdocs/buyinghouse-erp-package
bash install.sh
```

**চেক করুন — প্রতিটা ধাপে সবুজ ✓ আসছে কিনা:**
- [ ] ১/১২ — টুলস চেক
- [ ] ২/১২ — Laravel স্ক্যাফোল্ড
- [ ] ৩/১২ — Breeze ইনস্টল
- [ ] ৪/১২ — npm build
- [ ] ৫/১২ — dompdf ইনস্টল
- [ ] ৬/১২ — Sanctum (API) ইনস্টল
- [ ] ৭/১২ — কাস্টম ফাইল বসানো
- [ ] ৮/১২ — Autoload + ক্লাস যাচাই ("সব ক্লাস ঠিকভাবে লোড হয়েছে")
- [ ] ৯/১২ — SQLite কনফিগার
- [ ] ১০/১২ — Migrate + Seed
- [ ] ১১/১২ — Cache পরিষ্কার
- [ ] ১২/১২ — "✅ ইনস্টলেশন সম্পূর্ণ" মেসেজ

**যদি কোনো ধাপে লাল ✗ আসে:** পুরো error message কপি করে পাঠান, এখানেই থামুন।

---

## ধাপ ৫ — সার্ভার চালু

```bash
cd ~/buyinghouse-erp-app
php artisan serve
```

**চেক করুন:** "Server running on [http://127.0.0.1:8000]" দেখাচ্ছে, কোনো error নেই।

এই টার্মিনাল **বন্ধ করবেন না** — চালু রেখে নতুন Git Bash window খুলুন বাকি কাজের জন্য।

---

## ধাপ ৬ — ব্রাউজার প্রস্তুত করা

Chrome/Edge এ `http://127.0.0.1:8000` খুলুন। **F12 চাপুন**, **Console ট্যাবে ক্লিক করুন** — এটা খোলা রাখুন পুরো টেস্টিং এর সময়।

---

## ধাপ ৭ — Public/Marketing পেজ চেক (BuyingCore ব্র্যান্ড)

| পেজ | URL | যা দেখা উচিত |
|---|---|---|
| Home | `/` | Fraunces ফন্টে heading, live order preview |
| Catalog | `/catalog` | প্রোডাক্ট কার্ড দেখাচ্ছে |
| About | `/about` | ব্র্যান্ডেড About পেজ |
| Contact | `/contact` | ফর্ম আছে |

**চেক করুন:** প্রতিটা পেজে Console এ কোনো লাল error আসছে কিনা। ডিজাইন (রং/ফন্ট) তাদের static site এর মতো দেখাচ্ছে কিনা।

---

## ধাপ ৮ — Register ও Login

```
/register এ গিয়ে নতুন account বানান
```
**চেক করুন:** Account তৈরি হয়ে লগইন হয়ে যায় কি না।

```
Logout করে /login দিয়ে আবার লগইন করুন
```
**চেক করুন:** সঠিক পাসওয়ার্ডে লগইন হয়, ভুল পাসওয়ার্ডে error দেখায়।

**🔴 বিশেষভাবে চেক করুন — Forgot Password বাগ:**
```
/login পেজে "Forgot password?" লিংকে ক্লিক করুন
```
**লিখে রাখুন:** কোন URL এ গেলেন, এবং কী দেখলেন। এটা যদি admin dashboard এ নিয়ে যায় (এটাই আগের রিপোর্ট করা বাগ), **screenshot নিন**।

---

## ধাপ ৯ — Admin Login ও Dashboard

```
Logout করে admin@buyinghouse.test / password দিয়ে লগইন করুন
```
**চেক করুন:** `/admin/dashboard` এ পৌঁছায়, stats card ও chart দেখা যায়।

---

## ধাপ ১০ — 🔴 Delete Modal বাগ নির্দিষ্টভাবে চেক

```
Sidebar থেকে "Suppliers" এ যান
```
**চেক করুন:**
1. পেজ normal দেখাচ্ছে কি, নাকি লোড হতেই কোনো কালো overlay/popup দেখাচ্ছে?
2. কোনো supplier এর পাশে "Delete" বাটনে ক্লিক করুন — Modal popup আসে কি?
3. Modal এ "বাতিল" বাটনে ক্লিক করুন — Modal বন্ধ হয় কি?
4. আবার Delete ক্লিক করে "হ্যাঁ, মুছে ফেলুন" চাপুন — Delete হয় কি?

**Console ট্যাবে এই মুহূর্তে কোনো লাল error আছে কিনা — থাকলে screenshot নিন।**

একই টেস্ট করুন **Production, Delivery, Inventory, Products** পেজেও।

---

## ধাপ ১১ — 🔴 Mobile Responsive চেক

```
F12 থেকে Device Toolbar আইকনে ক্লিক করুন (Ctrl+Shift+M), iPhone SE বা 375px সিলেক্ট করুন
```
**চেক করুন প্রতিটা পেজে:**
- Admin sidebar hamburger (☰) icon দেখায় ও কাজ করে কি?
- টেবিল/কার্ড overflow করে ভেঙে যাচ্ছে কি, নাকি scroll হচ্ছে?
- Home/Catalog/Login পেজ ছোট স্ক্রিনে ঠিক দেখাচ্ছে কি?

---

## ধাপ ১২ — Order চেইন (মূল ব্যবসায়িক লজিক)

```
Customer হিসেবে লগইন করে /catalog থেকে একটা প্রোডাক্ট "Order this" করুন
```
**চেক করুন:** ১৫০ পিস দিয়ে অর্ডার সফল হয়, confirmation slip দেখায়।

```
Admin হিসেবে লগইন করে Production → Delivery → Invoice এন্ট্রি দিন (আগের ক্রমে)
```
**চেক করুন:** প্রতিটা ধাপ আগের ধাপ ছাড়া করা যায় না (যেমন delivery ছাড়া invoice করা যাবে না)।

```
Invoice এ "Download PDF" ক্লিক করুন
```
**চেক করুন:** PDF ডাউনলোড হয়, তথ্য সঠিক।

---

## ধাপ ১৩ — Phase 2 মডিউল

```
CRM → Leads এ একটা lead যোগ করুন
Costing এ একটা costing draft বানান
Sample এ একটা sample request করুন
```
**চেক করুন:** প্রতিটা সেভ হচ্ছে, error ছাড়া।

---

## ধাপ ১৪ — যা রিপোর্ট করবেন

টেস্ট শেষে আমাকে এভাবে জানান:

1. **কোন ধাপ পর্যন্ত সব ঠিক ছিল** (যেমন: "ধাপ ৯ পর্যন্ত সব ঠিক")
2. **কোথায় প্রথম সমস্যা হলো** — ধাপ নম্বর + যা দেখলেন
3. **Console এর লাল error** (থাকলে) — screenshot
4. **Forgot password** এ কী হলো — নির্দিষ্টভাবে

একসাথে সব বাগ না জমিয়ে, **প্রথম যেখানে আটকান সেখান থেকে জানালে** সবচেয়ে দ্রুত এগোতে পারবো।
