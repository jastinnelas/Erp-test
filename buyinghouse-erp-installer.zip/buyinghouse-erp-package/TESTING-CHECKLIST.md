# Handover-Readiness Testing Checklist

প্রতিটা আইটেম ব্রাউজারে গিয়ে হাতে টেস্ট করুন। যেটা কাজ না করলে ✗ দিয়ে
error message/screenshot সহ পাঠান।

## Auth
- [ ] Customer হিসেবে register করা যায়
- [ ] Customer login করতে পারে
- [ ] Admin (admin@buyinghouse.test) login করতে পারে
- [ ] Logout কাজ করে

## Order (Customer)
- [ ] নতুন অর্ডার দেওয়া যায় (মিনিমাম ১০০ পিস validation কাজ করে)
- [ ] ১০০ এর কম দিলে error message আসে
- [ ] Attachment ফাইল আপলোড করা যায়
- [ ] Order confirmation slip দেখা যায়
- [ ] Order list এ search/filter কাজ করে

## Admin — Order Chain
- [ ] Production entry তৈরি করা যায়
- [ ] Delivery entry তৈরি করা যায় (শুধু completed production এর অর্ডার দেখায়)
- [ ] Invoice generate হয় (শুধু delivered অর্ডারের জন্য)
- [ ] Invoice PDF ডাউনলোড হয়
- [ ] Invoice/Order CSV export ডাউনলোড হয়

## Admin — বাকি Module
- [ ] Product যোগ করা যায় (ছবি আপলোড সহ)
- [ ] Supplier যোগ করা যায়
- [ ] Inventory entry যোগ করা যায়
- [ ] Audit log এ action দেখা যায়
- [ ] Dashboard chart দেখা যায়

## Messaging
- [ ] Customer → Admin মেসেজ পাঠাতে পারে
- [ ] Admin → Customer রিপ্লাই দিতে পারে
- [ ] Page reload করলে পুরনো মেসেজ থাকে

## Security Features
- [ ] `.env` এ `OTP_ENABLED=true` করে registration এ OTP verify কাজ করে
- [ ] Admin 2FA setup করতে পারে (QR স্ক্যান করে)
- [ ] 2FA enable করার পর পরের লগইনে code চাওয়া হয়
- [ ] Delete বাটনে confirmation modal আসে
- [ ] ফর্ম সাবমিট করলে loading spinner দেখা যায়

## Payment (AmarPay sandbox credentials দিয়ে)
- [ ] `/pay/invoice/{id}` এ গেলে AmarPay এর পেজে redirect হয়
- [ ] Sandbox এ টেস্ট পেমেন্ট করলে ফিরে এসে status "paid" হয়

## UI/Responsive
- [ ] মোবাইল সাইজে (DevTools দিয়ে) admin sidebar hamburger menu কাজ করে
- [ ] Toast notification দেখা যায় সফল action এ

## API
- [ ] POST /api/login টোকেন রিটার্ন করে (Postman দিয়ে)
- [ ] GET /api/orders টোকেন দিয়ে কাজ করে
