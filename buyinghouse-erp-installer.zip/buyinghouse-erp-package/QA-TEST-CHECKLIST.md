# QA Test Checklist — Buying House ERP (Phase-II)

এই checklist টা আপনার প্রজেক্টের **actual, বানানো ফিচারের** ভিত্তিতে তৈরি — জেনেরিক
এন্টারপ্রাইজ চেকলিস্ট না, তাই প্রতিটা আইটেম সত্যিই টেস্ট করা সম্ভব ও প্রাসঙ্গিক।

**নিয়ম:** প্রতিটা টেস্ট নিজে ব্রাউজারে করুন, ফলাফল অনুযায়ী **Status** কলামে
✅ Pass / ❌ Fail / ⬜ Not tested লিখুন। Fail হলে Notes এ কী হয়েছে লিখে রাখুন
— রিপোর্টে এবং Claude কে জানাতে দুটোতেই কাজে লাগবে।

---

## Module 1 — Authentication

| ID | Test Case | Steps | Expected Result | Status | Notes |
|---|---|---|---|---|---|
| AUTH-01 | Customer Registration | `/register` এ গিয়ে নতুন account বানান | Account তৈরি হয়, dashboard এ redirect করে | ⬜ | |
| AUTH-02 | Customer Login | সঠিক email/password দিয়ে login | Login সফল, dashboard/orders দেখায় | ⬜ | |
| AUTH-03 | Wrong Password | ভুল password দিয়ে login | "These credentials do not match" error | ⬜ | |
| AUTH-04 | Admin Login | admin@buyinghouse.test / password | Admin dashboard এ redirect | ⬜ | |
| AUTH-05 | Logout | Logout বাটনে ক্লিক | Login পেজে redirect, session শেষ | ⬜ | |
| AUTH-06 | Password Reset | "Forgot password" flow | Reset link/form কাজ করে | ⬜ | |
| AUTH-07 | Rate Limiting | ৬+ বার ভুল password দিন | সাময়িক ব্লক (throttle) হয় | ⬜ | |

## Module 2 — Order (Customer Side)

| ID | Test Case | Steps | Expected Result | Status | Notes |
|---|---|---|---|---|---|
| ORD-01 | Create Valid Order | ১৫০ পিস কোনো প্রোডাক্ট অর্ডার দিন | Order তৈরি হয়, confirmation slip দেখায় | ⬜ | |
| ORD-02 | Minimum Qty Validation | ৫০ পিস দিয়ে অর্ডার দিন | "Minimum order quantity is 100" error | ⬜ | |
| ORD-03 | File Attachment Upload | PDF/JPG attach করে অর্ডার দিন | ফাইল আপলোড হয়, error ছাড়া সাবমিট হয় | ⬜ | |
| ORD-04 | Invalid File Type | .exe/.zip ফাইল আপলোড চেষ্টা করুন | Validation error, আপলোড হয় না | ⬜ | |
| ORD-05 | Order List | নিজের সব অর্ডার তালিকা দেখুন | শুধু নিজের অর্ডার দেখায়, অন্যের না | ⬜ | |
| ORD-06 | Search Order | Order No দিয়ে সার্চ করুন | সঠিক ফলাফল filter হয় | ⬜ | |
| ORD-07 | Status Filter | Status dropdown দিয়ে filter করুন | শুধু সেই status এর order দেখায় | ⬜ | |
| ORD-08 | Order Detail View | একটা order এ ক্লিক করুন | Product, qty, status সব সঠিক দেখায় | ⬜ | |

## Module 3 — Order Chain (Admin Side)

| ID | Test Case | Steps | Expected Result | Status | Notes |
|---|---|---|---|---|---|
| CHAIN-01 | Production Entry Create | নতুন অর্ডারে production entry দিন | Supplier assign, stage সেভ হয় | ⬜ | |
| CHAIN-02 | Production Without Order | Production form এ কোনো order select না করে submit | Validation error দেখায় | ⬜ | |
| CHAIN-03 | Delivery Before Production | Production "completed" না করে delivery entry বানানোর চেষ্টা | সেই order create form এ দেখায় না (blocked) | ⬜ | |
| CHAIN-04 | Delivery Entry Create | Production completed অর্ডারে delivery entry দিন | Courier, tracking no সেভ হয় | ⬜ | |
| CHAIN-05 | Invoice Before Delivery | Delivery "delivered" না করে invoice বানানোর চেষ্টা | সেই order create form এ দেখায় না (blocked) | ⬜ | |
| CHAIN-06 | Invoice Generate | Delivered অর্ডারে invoice তৈরি করুন | Auto invoice_no জেনারেট হয় | ⬜ | |
| CHAIN-07 | Invoice PDF Download | Invoice এ "Download PDF" ক্লিক | PDF ফাইল ডাউনলোড হয়, তথ্য সঠিক | ⬜ | |
| CHAIN-08 | Duplicate Prevention | একই অর্ডারে দ্বিতীয়বার production entry দেওয়ার চেষ্টা | Error/blocked (unique constraint) | ⬜ | |

## Module 4 — Products, Suppliers, Inventory

| ID | Test Case | Steps | Expected Result | Status | Notes |
|---|---|---|---|---|---|
| PROD-01 | Add Product with Image | ছবি সহ নতুন প্রোডাক্ট যোগ করুন | Product তৈরি, ছবি দেখা যায় | ⬜ | |
| PROD-02 | Duplicate Item Code | আগের মতো item_code দিয়ে নতুন product | Unique constraint error | ⬜ | |
| PROD-03 | Edit Product | প্রোডাক্ট এডিট করুন | পরিবর্তন সেভ হয় | ⬜ | |
| PROD-04 | Delete Product (Soft) | Product delete করুন | তালিকা থেকে সরে যায়, ডাটাবেসে থাকে (soft delete) | ⬜ | |
| SUP-01 | Add Supplier | নতুন supplier যোগ করুন | Rating, contact সেভ হয় | ⬜ | |
| INV-01 | Add Stock Entry | ৫০ পিস স্টক এন্ট্রি দিন | Status "low_stock" auto সেট হয় (< 100) | ⬜ | |
| INV-02 | Stock Status Boundary | ঠিক ১০০ পিস দিন | Status "in_stock" হয় | ⬜ | |

## Module 5 — Access Control & Security

| ID | Test Case | Steps | Expected Result | Status | Notes |
|---|---|---|---|---|---|
| SEC-01 | Customer → Admin Route | Customer login করে `/admin/dashboard` এ যান সরাসরি URL দিয়ে | 403 Forbidden | ⬜ | |
| SEC-02 | Guest → Protected Route | Logout অবস্থায় `/orders` এ যান | Login পেজে redirect | ⬜ | |
| SEC-03 | Other User's Order | অন্য customer এর order ID দিয়ে সরাসরি URL access | 403 Forbidden | ⬜ | |
| SEC-04 | CSRF Protection | ফর্ম থেকে `@csrf` টোকেন সরিয়ে submit (dev tools দিয়ে) | 419 Page Expired error | ⬜ | |
| SEC-05 | Security Headers | Browser DevTools → Network → কোনো রেসপন্স হেডার দেখুন | X-Frame-Options, CSP header উপস্থিত | ⬜ | |
| SEC-06 | Audit Log Entry | একটা order তৈরি করুন, admin audit log দেখুন | Entry দেখায় কে, কখন, কী করলো | ⬜ | |
| SEC-07 | OTP Flow (enabled করে) | `.env` এ OTP_ENABLED=true করে register করুন | Email এ কোড আসে (log এ), verify করলে account active হয় | ⬜ | |
| SEC-08 | 2FA Setup | Admin থেকে 2FA setup, QR স্ক্যান করে enable করুন | পরের লগইনে code চায় | ⬜ | |
| SEC-09 | 2FA Wrong Code | ভুল 2FA code দিন | Error দেখায়, login হয় না | ⬜ | |

## Module 6 — Messaging

| ID | Test Case | Steps | Expected Result | Status | Notes |
|---|---|---|---|---|---|
| MSG-01 | Send Message (Customer) | Admin কে মেসেজ পাঠান | মেসেজ সেভ ও দেখা যায় | ⬜ | |
| MSG-02 | Reply (Admin) | Admin থেকে রিপ্লাই দিন | Customer side এ দেখা যায় | ⬜ | |
| MSG-03 | Persistence on Reload | Page reload করুন | পুরনো সব মেসেজ থাকে | ⬜ | |
| MSG-04 | Unread Count | নতুন মেসেজ আসার পর admin thread list দেখুন | Unread badge সংখ্যা দেখায় | ⬜ | |

## Module 7 — Export & Reporting

| ID | Test Case | Steps | Expected Result | Status | Notes |
|---|---|---|---|---|---|
| EXP-01 | Orders CSV Export | Dashboard থেকে "Export orders" ক্লিক | CSV ডাউনলোড হয়, Excel এ খোলে | ⬜ | |
| EXP-02 | Invoices CSV Export | Invoice list থেকে export | সঠিক ডেটা সহ CSV আসে | ⬜ | |
| EXP-03 | Bangla Text in CSV | CSV Excel এ খুলুন | বাংলা টেক্সট ভাঙা না দেখিয়ে ঠিক দেখায় | ⬜ | |
| EXP-04 | Dashboard Chart | Admin dashboard দেখুন | ৬ মাসের order trend chart রেন্ডার হয় | ⬜ | |

## Module 8 — Payment (AmarPay Sandbox)

| ID | Test Case | Steps | Expected Result | Status | Notes |
|---|---|---|---|---|---|
| PAY-01 | Initiate Payment | Unpaid invoice এ pay বাটনে ক্লিক | AmarPay sandbox পেজে redirect হয় | ⬜ | |
| PAY-02 | Successful Payment | Sandbox টেস্ট কার্ড দিয়ে পেমেন্ট complete করুন | ফিরে এসে status "paid" দেখায় | ⬜ | |
| PAY-03 | Cancelled Payment | Sandbox পেজ থেকে cancel করুন | Error message সহ ফিরে আসে, status অপরিবর্তিত | ⬜ | |
| PAY-04 | Amount Tampering | (advanced) callback এ ভিন্ন amount পাঠানোর চেষ্টা | Mismatch ধরা পড়ে, paid না হয় | ⬜ | |

## Module 9 — API (Sanctum)

| ID | Test Case | Steps | Expected Result | Status | Notes |
|---|---|---|---|---|---|
| API-01 | Login Endpoint | POST /api/login সঠিক credential দিয়ে (Postman) | Token রিটার্ন হয় | ⬜ | |
| API-02 | Wrong Credentials | ভুল password দিয়ে POST /api/login | 422/error response | ⬜ | |
| API-03 | Protected Route Without Token | Token ছাড়া GET /api/orders | 401 Unauthorized | ⬜ | |
| API-04 | Protected Route With Token | Bearer token সহ GET /api/orders | নিজের orders JSON এ আসে | ⬜ | |
| API-05 | Rate Limit on Login | দ্রুত ৬+ বার POST /api/login | 429 Too Many Requests | ⬜ | |

## Module 10 — UI/Responsive

| ID | Test Case | Steps | Expected Result | Status | Notes |
|---|---|---|---|---|---|
| UI-01 | Mobile Sidebar | DevTools এ 375px width সেট করুন, admin panel দেখুন | Hamburger icon দেখায়, ক্লিকে sidebar slide করে | ⬜ | |
| UI-02 | Toast Notification | যেকোনো successful action করুন | Animated popup ৪ সেকেন্ড পর মিলিয়ে যায় | ⬜ | |
| UI-03 | Delete Confirmation | যেকোনো delete বাটনে ক্লিক | Modal আসে, "বাতিল" এ কিছু হয় না | ⬜ | |
| UI-04 | Form Loading State | যেকোনো ফর্ম সাবমিট করুন | বাটনে spinner দেখায়, ডাবল-ক্লিক আটকায় | ⬜ | |
| UI-05 | Table Overflow (Mobile) | ছোট স্ক্রিনে কোনো ডেটা টেবিল দেখুন | Horizontal scroll হয়, layout ভাঙে না | ⬜ | |

## Module 11 — Phase 2: CRM

| ID | Test Case | Steps | Expected Result | Status | Notes |
|---|---|---|---|---|---|
| CRM-01 | Add Lead | নতুন lead যোগ করুন | Lead তৈরি হয়, status "new" | ⬜ | |
| CRM-02 | Log Activity | Lead detail এ activity log করুন | Timeline এ দেখা যায় | ⬜ | |
| CRM-03 | Change Lead Status | Status dropdown পরিবর্তন করুন | সেভ হয়, badge রঙ পরিবর্তন হয় | ⬜ | |
| CRM-04 | Buyer Profile Create | কোনো customer এর profile যোগ করুন | Company, currency, terms সেভ হয় | ⬜ | |

## Module 12 — Phase 2: Costing

| ID | Test Case | Steps | Expected Result | Status | Notes |
|---|---|---|---|---|---|
| COST-01 | Create Costing Draft | সব cost field পূরণ করে submit করুন | Selling price সঠিকভাবে calculate হয় | ⬜ | |
| COST-02 | Margin Calculation | Margin 20% এ total cost 1000 হলে | Selling price 1200 দেখায় | ⬜ | |
| COST-03 | Version Increment | একই প্রোডাক্টে দ্বিতীয় costing বানান | Version 2 হয়, আগেরটা অক্ষত থাকে | ⬜ | |
| COST-04 | Approve Costing | Draft costing approve করুন | Status "approved", edit বন্ধ হয়ে যায় | ⬜ | |
| COST-05 | Edit After Approval Blocked | Approved costing edit করার চেষ্টা | Blocked/error message | ⬜ | |

## Module 13 — Phase 2: Sample

| ID | Test Case | Steps | Expected Result | Status | Notes |
|---|---|---|---|---|---|
| SAMP-01 | Request Sample | নতুন sample request করুন | Stage "requested" এ তৈরি হয় | ⬜ | |
| SAMP-02 | Stage Progression | Stage "proto" থেকে "fit" এ পরিবর্তন | সেভ হয়, audit log এ entry হয় | ⬜ | |
| SAMP-03 | Add Feedback | Feedback text যোগ করুন | সেভ হয়, দেখা যায় | ⬜ | |
| SAMP-04 | Filter by Stage | Stage filter ব্যবহার করুন | সঠিক ফলাফল দেখায় | ⬜ | |

---

## সারসংক্ষেপ (টেস্ট শেষে পূরণ করুন)

| মোট Test Case | Pass | Fail | Not Tested |
|---|---|---|---|
| 60 | | | |

**সবচেয়ে গুরুত্বপূর্ণ Fail (যদি থাকে):**
1.
2.
3.
