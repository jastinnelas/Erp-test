// ---- mobile nav toggle (all pages) ----
(function(){
  var btn = document.getElementById('hamburger');
  var links = document.querySelector('.nav-links');
  if(!btn || !links) return;
  btn.addEventListener('click', function(){
    var open = links.classList.contains('mobile-open');
    links.classList.toggle('mobile-open', !open);
    links.style.display = open ? '' : 'flex';
    if(!open){
      links.style.cssText += 'flex-direction:column;position:absolute;top:76px;left:0;right:0;background:var(--cotton);padding:18px 24px;border-bottom:1px solid var(--line);gap:14px;z-index:40;';
    }
    btn.setAttribute('aria-expanded', String(!open));
  });
})();

// ---- OTP input auto-advance (otp.html) ----
(function(){
  var boxes = document.querySelectorAll('.otp-row input');
  if(!boxes.length) return;
  boxes.forEach(function(box, i){
    box.addEventListener('input', function(){
      box.value = box.value.replace(/[^0-9]/g,'').slice(0,1);
      if(box.value && boxes[i+1]) boxes[i+1].focus();
    });
    box.addEventListener('keydown', function(e){
      if(e.key === 'Backspace' && !box.value && boxes[i-1]) boxes[i-1].focus();
    });
  });
})();

// ---- product detail: qty -> tier highlight + total price ----
(function(){
  var qtyInput = document.getElementById('qtyInput');
  if(!qtyInput) return;
  var tiers = JSON.parse(document.getElementById('tierData').textContent);
  var rows = document.querySelectorAll('.tier-row:not(.head)');
  var totalEl = document.getElementById('orderTotal');
  var moq = parseInt(qtyInput.min, 10) || 100;

  function currentTier(qty){
    var chosen = tiers[0];
    tiers.forEach(function(t){ if(qty >= t.min) chosen = t; });
    return chosen;
  }
  function update(){
    var qty = parseInt(qtyInput.value, 10) || 0;
    rows.forEach(function(row, i){ row.classList.toggle('match', qty >= moq && tiers[i] === currentTier(qty)); });
    if(qty >= moq){
      var t = currentTier(qty);
      totalEl.textContent = '৳ ' + (qty * t.price).toLocaleString('en-IN');
      qtyInput.closest('.field') && qtyInput.closest('.field').classList.remove('error');
    } else {
      totalEl.textContent = '— enter at least ' + moq + ' pcs';
    }
  }
  qtyInput.addEventListener('input', update);
  update();

  // color / size pickers are purely visual state
  document.querySelectorAll('.swab').forEach(function(s){
    s.addEventListener('click', function(){
      document.querySelectorAll('.swab').forEach(function(o){o.classList.remove('picked')});
      s.classList.add('picked');
    });
  });
  document.querySelectorAll('.size-pick').forEach(function(s){
    s.addEventListener('click', function(){
      document.querySelectorAll('.size-pick').forEach(function(o){o.classList.remove('picked')});
      s.classList.add('picked');
    });
  });
})();

// ---- order form: enforce minimum 100 pcs before "submit" ----
(function(){
  var form = document.getElementById('orderForm');
  if(!form) return;
  form.addEventListener('submit', function(e){
    e.preventDefault();
    var qty = form.querySelector('#orderQty');
    var qtyField = qty.closest('.field');
    if(parseInt(qty.value, 10) < 100 || !qty.value){
      qtyField.classList.add('error');
      qty.focus();
      return;
    }
    qtyField.classList.remove('error');
    window.location.href = 'order-confirmation.html';
  });
})();

// ---- catalog filter tabs ----
(function(){
  var tabs = document.querySelectorAll('.filter-tabs a');
  if(!tabs.length) return;
  var cards = document.querySelectorAll('.product-grid .product-card');
  tabs.forEach(function(tab){
    tab.addEventListener('click', function(e){
      e.preventDefault();
      tabs.forEach(function(t){t.classList.remove('active')});
      tab.classList.add('active');
      var cat = tab.getAttribute('data-filter');
      cards.forEach(function(card){
        card.style.display = (cat === 'all' || card.getAttribute('data-category') === cat) ? '' : 'none';
      });
    });
  });
})();

// ---- signup: forward to OTP step ----
(function(){
  var form = document.getElementById('signupForm');
  if(!form) return;
  form.addEventListener('submit', function(e){
    e.preventDefault();
    window.location.href = 'otp.html';
  });
})();

// ---- otp: forward to home once all boxes filled ----
(function(){
  var form = document.getElementById('otpForm');
  if(!form) return;
  form.addEventListener('submit', function(e){
    e.preventDefault();
    window.location.href = 'index.html';
  });
})();

// ---- track page: demo lookup ----
(function(){
  var form = document.getElementById('trackForm');
  if(!form) return;
  var result = document.getElementById('trackResult');
  var empty = document.getElementById('trackEmpty');
  form.addEventListener('submit', function(e){
    e.preventDefault();
    result.style.display = 'block';
    empty.style.display = 'none';
  });
})();
