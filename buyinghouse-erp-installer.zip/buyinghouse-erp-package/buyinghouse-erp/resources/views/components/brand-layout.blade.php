<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{ $title ?? 'BuyingCore' }}</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Fraunces:wght@600;700&family=IBM+Plex+Sans:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('css/buyingcore.css') }}">
    <style>[x-cloak]{display:none!important}</style>

    @vite(['resources/js/app.js'])
</head>
<body>

    <x-toast />

    <header class="site-header">
        <div class="wrap nav">
            <a class="brand" href="{{ route('home') }}">
                <span class="brand-mark">BC</span> BuyingCore
            </a>
            <nav class="nav-links">
                <a href="{{ route('catalog.index') }}" class="{{ request()->routeIs('catalog.*') ? 'active' : '' }}">Catalog</a>
                <a href="{{ route('home') }}#how">How an order moves</a>
                <a href="{{ route('track.show') }}" class="{{ request()->routeIs('track.*') ? 'active' : '' }}">Track an order</a>
                <a href="{{ route('about') }}" class="{{ request()->routeIs('about') ? 'active' : '' }}">About</a>
            </nav>
            <div class="nav-actions">
                @auth
                    @if (auth()->user()->role === 'admin')
                        <a class="btn btn-ghost" href="{{ route('admin.dashboard') }}">Admin panel</a>
                    @else
                        <a class="btn btn-ghost" href="{{ route('orders.index') }}">My orders</a>
                    @endif
                    <form method="POST" action="{{ route('logout') }}">
                        @csrf
                        <button type="submit" class="btn btn-primary">Log out</button>
                    </form>
                @else
                    <a class="btn btn-ghost" href="{{ route('login') }}">Log in</a>
                    <a class="btn btn-primary" href="{{ route('catalog.index') }}">Start an order</a>
                @endauth
            </div>
            <button class="hamburger" aria-label="Open menu" aria-expanded="false" id="hamburger">☰</button>
        </div>
    </header>

    <main>
        {{ $slot }}
    </main>

    <footer>
        <div class="wrap footer-top">
            <div class="footer-brand">
                <a class="brand" href="{{ route('home') }}" style="color:var(--cotton)">
                    <span class="brand-mark" style="background:var(--gold);color:var(--ink)">BC</span> BuyingCore
                </a>
                <p>A buying-house ordering platform built for retailers who order by the hundred, not the piece.</p>
            </div>
            <div class="col">
                <h4>Catalog</h4>
                <a href="{{ route('catalog.index') }}">Wovens</a>
                <a href="{{ route('catalog.index') }}">Knitwear</a>
                <a href="{{ route('catalog.index') }}">Denim</a>
            </div>
            <div class="col">
                <h4>Account</h4>
                <a href="{{ route('login') }}">Log in</a>
                <a href="{{ route('register') }}">Sign up</a>
                <a href="{{ route('track.show') }}">Track an order</a>
            </div>
            <div class="col">
                <h4>Company</h4>
                <a href="{{ route('about') }}">About</a>
                <a href="{{ route('contact') }}">Contact</a>
            </div>
        </div>
        <div class="wrap footer-bottom">
            <span>© {{ date('Y') }} BuyingCore. All rights reserved.</span>
            <a href="{{ route('login') }}">Admin login</a>
        </div>
    </footer>

    <script>
        document.getElementById('hamburger')?.addEventListener('click', function () {
            document.querySelector('.nav-links')?.classList.toggle('open');
        });
    </script>
    <x-loading-script />
</body>
</html>
