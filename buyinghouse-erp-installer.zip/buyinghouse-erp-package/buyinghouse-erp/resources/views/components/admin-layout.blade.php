<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{ $title ?? 'Admin' }} — Buying House ERP</title>

    <style>[x-cloak] { display: none !important; }</style>

    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="antialiased bg-gray-100">
    <x-toast />

    <div class="flex flex-col md:flex-row min-h-screen">

        <x-admin-sidebar />

        <div class="flex-1 min-w-0">
            @isset($header)
                <header class="bg-white shadow-sm">
                    <div class="max-w-6xl mx-auto px-4 py-4">
                        {{ $header }}
                    </div>
                </header>
            @endisset

            <main class="px-4 md:px-0">
                {{ $slot }}
            </main>
        </div>

    </div>

    <x-loading-script />
</body>
</html>
