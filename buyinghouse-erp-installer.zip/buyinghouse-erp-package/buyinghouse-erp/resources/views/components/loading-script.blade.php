{{--
    সব ফর্মে loading state যোগ করে — সাবমিট বাটনে ক্লিক করলে
    বাটন disable হয়ে যাবে ও একটা ছোট spinner দেখাবে, ডাবল-সাবমিট আটকাবে।
    এটা admin-layout ও app-layout দুটোতেই একবার include করলেই যথেষ্ট।
--}}
<script>
    document.addEventListener('submit', function (e) {
        const form = e.target;
        const btn = form.querySelector('button[type="submit"]');
        if (!btn || btn.dataset.loading === 'true') return;

        btn.dataset.loading = 'true';
        btn.dataset.originalText = btn.innerHTML;
        btn.disabled = true;
        btn.classList.add('opacity-70', 'cursor-not-allowed');
        btn.innerHTML = `
            <span class="inline-flex items-center gap-2">
                <svg class="animate-spin h-4 w-4" viewBox="0 0 24 24" fill="none">
                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"></path>
                </svg>
                Processing...
            </span>`;
    });
</script>
