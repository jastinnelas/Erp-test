@props(['message' => 'আপনি কি নিশ্চিত?'])

{{--
    ব্যবহার:
    <form method="POST" action="...">
        @csrf @method('DELETE')
        <x-confirm-button message="এই প্রোডাক্টটি মুছে ফেলতে চান?">
            Delete
        </x-confirm-button>
    </form>
--}}

<div x-data="{ open: false }" class="inline">
    <button type="button" @click="open = true" {{ $attributes->merge(['class' => 'text-red-600 hover:underline']) }}>
        {{ $slot }}
    </button>

    <div x-show="open" x-cloak style="display:none"
         class="fixed inset-0 z-50 flex items-center justify-center bg-black/50 px-4"
         x-transition.opacity>
        <div @click.outside="open = false"
             class="bg-white rounded-lg shadow-xl max-w-sm w-full p-6"
             x-transition>
            <p class="text-gray-800 text-sm mb-5">{{ $message }}</p>
            <div class="flex justify-end gap-2">
                <button type="button" @click="open = false"
                        class="px-4 py-2 text-sm rounded border text-gray-600 hover:bg-gray-50">
                    বাতিল
                </button>
                <button type="submit"
                        class="px-4 py-2 text-sm rounded bg-red-600 text-white hover:bg-red-700">
                    হ্যাঁ, মুছে ফেলুন
                </button>
            </div>
        </div>
    </div>
</div>
