@php
    $links = [
        ['route' => 'admin.dashboard', 'label' => 'Dashboard', 'match' => 'admin.dashboard'],
        ['route' => 'admin.production.index', 'label' => 'Production Entry', 'match' => 'admin.production.*'],
        ['route' => 'admin.delivery.index', 'label' => 'Delivery Status', 'match' => 'admin.delivery.*'],
        ['route' => 'admin.invoices.index', 'label' => 'Invoice', 'match' => 'admin.invoices.*'],
        ['route' => 'admin.inventory.index', 'label' => 'Inventory', 'match' => 'admin.inventory.*'],
        ['route' => 'admin.products.index', 'label' => 'Products', 'match' => 'admin.products.*'],
        ['route' => 'admin.suppliers.index', 'label' => 'Suppliers', 'match' => 'admin.suppliers.*'],
        ['route' => 'messages.index', 'label' => 'Messages', 'match' => 'messages.*'],
        ['route' => 'two-factor.setup', 'label' => 'Security (2FA)', 'match' => 'two-factor.*'],
        ['route' => 'admin.crm.leads.index', 'label' => 'CRM — Leads', 'match' => 'admin.crm.leads.*'],
        ['route' => 'admin.crm.buyers.index', 'label' => 'CRM — Buyers', 'match' => 'admin.crm.buyers.*'],
        ['route' => 'admin.costing.index', 'label' => 'Costing', 'match' => 'admin.costing.*'],
        ['route' => 'admin.sample.index', 'label' => 'Samples', 'match' => 'admin.sample.*'],
        ['route' => 'admin.audit-logs.index', 'label' => 'Audit Log', 'match' => 'admin.audit-logs.*'],
    ];
@endphp

<div x-data="{ open: false }">

    {{-- মোবাইল টপ বার --}}
    <div class="md:hidden flex items-center justify-between bg-gray-900 text-white px-4 py-3">
        <span class="font-semibold">ADMIN</span>
        <button @click="open = !open" class="p-2" aria-label="Toggle menu">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path x-show="!open" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                <path x-show="open" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
        </button>
    </div>

    {{-- মোবাইলে খোলা থাকলে ব্যাকগ্রাউন্ড overlay --}}
    <div x-show="open" @click="open = false" x-cloak
         class="fixed inset-0 bg-black/50 z-30 md:hidden"></div>

    {{-- সাইডবার — desktop এ সবসময় দৃশ্যমান, মোবাইলে slide-in --}}
    <div
        :class="open ? 'translate-x-0' : '-translate-x-full'"
        class="fixed md:static top-0 left-0 z-40 h-full md:h-auto w-64 md:w-56 shrink-0
               bg-gray-900 text-gray-300 min-h-screen transition-transform duration-200
               md:translate-x-0">

        <div class="px-5 py-4 text-white font-semibold text-lg border-b border-gray-800 flex justify-between items-center">
            <span>ADMIN</span>
            <button @click="open = false" class="md:hidden text-gray-400">✕</button>
        </div>

        <nav class="py-3">
            @foreach ($links as $link)
                <a href="{{ route($link['route']) }}"
                   class="block px-5 py-2.5 text-sm hover:bg-gray-800 hover:text-white
                          {{ request()->routeIs($link['match']) ? 'bg-gray-800 text-white border-l-4 border-blue-500' : '' }}">
                    {{ $link['label'] }}
                </a>
            @endforeach
        </nav>

        <div class="px-5 py-4 mt-4 border-t border-gray-800">
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button type="submit" class="text-sm text-gray-400 hover:text-white">
                    Log Out
                </button>
            </form>
        </div>
    </div>

</div>
