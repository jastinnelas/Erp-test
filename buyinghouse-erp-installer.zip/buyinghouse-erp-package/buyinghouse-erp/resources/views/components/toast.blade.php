@if (session('success') || session('error'))
    <div
        x-data="{ show: true }"
        x-init="setTimeout(() => show = false, 4000)"
        x-show="show"
        x-transition:enter="transition ease-out duration-300"
        x-transition:enter-start="opacity-0 translate-y-2"
        x-transition:enter-end="opacity-100 translate-y-0"
        x-transition:leave="transition ease-in duration-200"
        x-transition:leave-start="opacity-100"
        x-transition:leave-end="opacity-0"
        x-cloak
        class="fixed top-4 right-4 z-50 max-w-sm w-full sm:w-auto">
        <div class="flex items-center gap-3 px-4 py-3 rounded-lg shadow-lg text-sm
                    {{ session('success') ? 'bg-green-600 text-white' : 'bg-red-600 text-white' }}">
            <span>
                @if (session('success')) ✓ @else ✕ @endif
            </span>
            <span>{{ session('success') ?? session('error') }}</span>
            <button @click="show = false" class="ml-auto opacity-75 hover:opacity-100">✕</button>
        </div>
    </div>
@endif
