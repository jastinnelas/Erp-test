{{--
    ব্যবহার (একটা ডিলিট ফর্মকে এভাবে বদলে দিন):

    <form action="{{ route('admin.production.destroy', $entry) }}" method="POST"
          x-data="{ confirmOpen: false }">
        @csrf @method('DELETE')
        <button type="button" @click="confirmOpen = true" class="text-red-600 hover:underline">Delete</button>
        <x-confirm-modal message="এই এন্ট্রি ডিলিট করতে চান?" />
    </form>
--}}
@props(['message' => 'আপনি কি নিশ্চিত?', 'confirmLabel' => 'হ্যাঁ, নিশ্চিত', 'cancelLabel' => 'বাতিল'])

<div x-show="confirmOpen" x-cloak
     class="fixed inset-0 z-50 flex items-center justify-center px-4"
     x-transition:enter="transition ease-out duration-150"
     x-transition:enter-start="opacity-0"
     x-transition:enter-end="opacity-100">

    <div @click="confirmOpen = false" class="fixed inset-0 bg-black/50"></div>

    <div class="relative bg-white rounded-lg shadow-xl max-w-sm w-full p-5"
         x-transition:enter="transition ease-out duration-150"
         x-transition:enter-start="opacity-0 scale-95"
         x-transition:enter-end="opacity-100 scale-100">
        <p class="text-sm text-gray-700 mb-4">{{ $message }}</p>
        <div class="flex justify-end gap-2">
            <button type="button" @click="confirmOpen = false"
                    class="px-3 py-1.5 text-sm rounded border text-gray-600 hover:bg-gray-50">
                {{ $cancelLabel }}
            </button>
            <button type="submit"
                    class="px-3 py-1.5 text-sm rounded bg-red-600 text-white hover:bg-red-700">
                {{ $confirmLabel }}
            </button>
        </div>
    </div>
</div>
