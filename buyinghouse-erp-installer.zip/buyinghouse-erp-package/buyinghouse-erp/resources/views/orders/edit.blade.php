<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            অর্ডার সম্পাদনা
        </h2>
    </x-slot>

    <div class="py-8">
        <div class="max-w-xl mx-auto sm:px-6 lg:px-8">

            <div class="bg-white shadow rounded p-6">

                @if ($errors->any())
                    <div class="mb-4 bg-red-100 text-red-700 px-4 py-3 rounded">
                        <ul class="list-disc list-inside text-sm">
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                <form method="POST" action="{{ route('orders.update', $order) }}" class="space-y-4">
                    @csrf
                    @method('PUT')

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">
                            প্রোডাক্ট
                        </label>
                        <input type="text" disabled
                               value="{{ $order->product->name }} ({{ $order->product->item_code }})"
                               class="w-full border-gray-200 rounded shadow-sm bg-gray-50 text-gray-500">
                        <p class="text-xs text-gray-400 mt-1">অর্ডার হয়ে যাওয়ার পর প্রোডাক্ট পরিবর্তন করা যায় না।</p>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">
                            পরিমাণ (মিনিমাম ১০০ পিস)
                        </label>
                        <input type="number" name="quantity" min="100"
                               value="{{ old('quantity', $order->quantity) }}"
                               required class="w-full border-gray-300 rounded shadow-sm">
                    </div>

                    <div class="flex justify-end gap-2 pt-2">
                        <a href="{{ route('orders.show', $order) }}"
                           class="px-4 py-2 rounded border text-gray-600 hover:bg-gray-50">
                            বাতিল
                        </a>
                        <button type="submit"
                                class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
                            আপডেট করুন
                        </button>
                    </div>

                </form>
            </div>

        </div>
    </div>
</x-app-layout>
