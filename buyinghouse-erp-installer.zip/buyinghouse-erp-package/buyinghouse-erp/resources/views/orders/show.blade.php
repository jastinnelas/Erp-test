<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            অর্ডার বিস্তারিত
        </h2>
    </x-slot>

    <div class="py-8">
        <div class="max-w-xl mx-auto sm:px-6 lg:px-8">

            @if (session('success'))
                <div class="mb-4 bg-green-100 text-green-800 px-4 py-3 rounded">
                    {{ session('success') }}
                </div>
            @endif

            <div class="bg-white shadow rounded p-6">

                <div class="text-center border-b pb-4 mb-4">
                    <p class="text-xs uppercase tracking-wide text-gray-400">Order confirmation slip</p>
                    <p class="text-lg font-semibold text-blue-700">{{ $order->order_no }}</p>
                    <span class="inline-block mt-1 px-3 py-1 text-xs rounded-full bg-gray-100 capitalize">
                        {{ str_replace('_', ' ', $order->status) }}
                    </span>
                </div>

                <dl class="grid grid-cols-2 gap-y-3 text-sm">
                    <dt class="text-gray-500">প্রোডাক্ট</dt>
                    <dd class="text-right font-medium">{{ $order->product->name }}</dd>

                    <dt class="text-gray-500">আইটেম কোড</dt>
                    <dd class="text-right">{{ $order->product->item_code }}</dd>

                    <dt class="text-gray-500">পরিমাণ</dt>
                    <dd class="text-right">{{ $order->quantity }} pcs</dd>

                    <dt class="text-gray-500">অর্ডার তারিখ</dt>
                    <dd class="text-right">{{ $order->order_date->format('d M, Y') }}</dd>

                    <dt class="text-gray-500">ডেলিভারি তারিখ</dt>
                    <dd class="text-right">
                        {{ $order->delivery_date?->format('d M, Y') ?? 'নির্ধারিত হয়নি' }}
                    </dd>
                </dl>

                <div class="mt-6 border-t pt-4">
                    <p class="text-sm font-medium text-gray-600 mb-2">প্রোডাকশন ও ডেলিভারি স্ট্যাটাস</p>
                    <ul class="text-sm space-y-1 text-gray-500">
                        <li>
                            প্রোডাকশন:
                            {{ $order->productionEntry?->stage ?? 'এখনো শুরু হয়নি' }}
                        </li>
                        <li>
                            ডেলিভারি:
                            {{ $order->deliveryEntry?->status ?? 'এখনো শুরু হয়নি' }}
                        </li>
                        <li>
                            ইনভয়েস:
                            {{ $order->invoice ? $order->invoice->payment_status : 'এখনো জেনারেট হয়নি' }}
                            @if ($order->invoice && $order->invoice->payment_status === 'pending')
                                <a href="{{ route('payment.initiate', $order->invoice) }}"
                                   class="ml-2 inline-block px-3 py-1 bg-green-600 text-white text-xs rounded hover:bg-green-700">
                                    Pay Now (৳{{ number_format($order->invoice->amount, 2) }})
                                </a>
                            @endif
                        </li>
                    </ul>
                </div>

                <div class="mt-6 flex justify-between">
                    <a href="{{ route('orders.index') }}" class="text-blue-600 hover:underline text-sm">
                        ← তালিকায় ফিরুন
                    </a>
                    <button onclick="window.print()"
                            class="px-4 py-2 bg-gray-800 text-white rounded text-sm hover:bg-gray-900">
                        Print slip
                    </button>
                </div>

            </div>

        </div>
    </div>
</x-app-layout>
