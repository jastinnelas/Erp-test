<x-brand-layout title="New Order — BuyingCore">

    <div class="page-head">
        <div class="wrap">
            <div class="crumb"><a href="{{ route('home') }}">Home</a> / <a href="{{ route('orders.index') }}">My orders</a> / New</div>
            <h1>Place an order</h1>
            <p>Minimum 100 pieces per style.</p>
        </div>
    </div>

    <section class="section" style="padding-top:32px">
        <div class="wrap" style="max-width:560px">
            <div class="form-card" style="margin:0">

                @if ($errors->any())
                    <div style="background:rgba(155,59,46,.1);color:var(--error);padding:14px 16px;border-radius:6px;margin-bottom:20px;font-size:14.5px">
                        <ul style="margin:0;padding-left:18px">
                            @foreach ($errors->all() as $error) <li>{{ $error }}</li> @endforeach
                        </ul>
                    </div>
                @endif

                <form method="POST" action="{{ route('orders.store') }}" enctype="multipart/form-data">
                    @csrf

                    <div class="field">
                        <label for="product_id">প্রোডাক্ট</label>
                        <select name="product_id" id="product_id" required>
                            <option value="">-- প্রোডাক্ট বাছাই করুন --</option>
                            @foreach ($products as $product)
                                <option value="{{ $product->id }}"
                                    {{ old('product_id', $selectedProductId) == $product->id ? 'selected' : '' }}>
                                    {{ $product->name }} ({{ $product->item_code }})
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <div class="field">
                        <label for="quantity">পরিমাণ (মিনিমাম ১০০ পিস)</label>
                        <input type="number" name="quantity" id="quantity" min="100" value="{{ old('quantity') }}"
                               required placeholder="যেমন: 150">
                    </div>

                    <div class="field">
                        <label for="order_date">অর্ডার তারিখ</label>
                        <input type="date" name="order_date" id="order_date"
                               value="{{ old('order_date', date('Y-m-d')) }}" required>
                    </div>

                    <div class="field">
                        <label for="attachment">সংযুক্তি (Design/Sample, ঐচ্ছিক)</label>
                        <input type="file" name="attachment" id="attachment" accept=".pdf,.jpg,.jpeg,.png">
                    </div>

                    <button type="submit" class="btn btn-primary btn-block" style="margin-top:20px">
                        অর্ডার সাবমিট করুন
                    </button>
                </form>
            </div>
        </div>
    </section>

</x-brand-layout>
