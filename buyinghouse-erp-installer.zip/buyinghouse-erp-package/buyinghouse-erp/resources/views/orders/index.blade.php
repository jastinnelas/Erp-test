<x-brand-layout title="My Orders — BuyingCore">

    <div class="page-head">
        <div class="wrap">
            <div class="crumb"><a href="{{ route('home') }}">Home</a> / My orders</div>
            <h1>My orders</h1>
            <p>{{ $orders->total() }} order(s) on your account.</p>
        </div>
    </div>

    <section class="section" style="padding-top:32px">
        <div class="wrap">

            <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:14px;margin-bottom:20px">
                <form method="GET" class="filter-bar">
                    <input type="text" name="search" value="{{ request('search') }}" placeholder="Order No বা প্রোডাক্ট...">
                    <select name="status" onchange="this.form.submit()">
                        <option value="">সব স্ট্যাটাস</option>
                        @foreach (['pending', 'in_production', 'delivered', 'cancelled'] as $status)
                            <option value="{{ $status }}" {{ request('status') === $status ? 'selected' : '' }}>
                                {{ ucfirst(str_replace('_', ' ', $status)) }}
                            </option>
                        @endforeach
                    </select>
                </form>
                <a href="{{ route('orders.create') }}" class="btn btn-primary">+ নতুন অর্ডার</a>
            </div>

            <table class="data-table">
                <thead>
                    <tr>
                        <th>Order No</th>
                        <th>Product</th>
                        <th>Qty</th>
                        <th>Order Date</th>
                        <th>Status</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($orders as $order)
                        <tr>
                            <td style="font-weight:600">{{ $order->order_no }}</td>
                            <td>{{ $order->product->name }}</td>
                            <td>{{ $order->quantity }}</td>
                            <td>{{ $order->order_date->format('d M, Y') }}</td>
                            <td>
                                <span class="status-pill status-{{ $order->status }}">
                                    {{ ucfirst(str_replace('_', ' ', $order->status)) }}
                                </span>
                            </td>
                            <td style="text-align:right">
                                <a href="{{ route('orders.show', $order) }}" style="color:var(--indigo);font-weight:600">View</a>
                            </td>
                        </tr>
                    @empty
                        <tr><td colspan="6" style="text-align:center;color:var(--ink-soft);padding:32px">No orders yet.</td></tr>
                    @endforelse
                </tbody>
            </table>

            <div style="margin-top:24px">{{ $orders->links() }}</div>

        </div>
    </section>

</x-brand-layout>
