@php
    $layout = auth()->user()->role === 'admin' ? 'admin-layout' : 'app-layout';
@endphp

<x-dynamic-component :component="$layout">
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ $otherUser->name }}
        </h2>
    </x-slot>

    <div class="py-8">
        <div class="max-w-xl mx-auto sm:px-6 lg:px-8">

            <div class="bg-white shadow rounded flex flex-col h-[28rem]">

                <div class="flex-1 overflow-y-auto p-4 space-y-3">
                    @forelse ($conversation as $message)
                        @php $isMine = $message->sender_id === auth()->id(); @endphp
                        <div class="flex {{ $isMine ? 'justify-end' : 'justify-start' }}">
                            <div class="max-w-xs px-3 py-2 rounded-lg text-sm
                                {{ $isMine ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-800' }}">
                                {{ $message->content }}
                                <div class="text-[10px] mt-1 opacity-70">
                                    {{ $message->created_at->format('h:i A') }}
                                </div>
                            </div>
                        </div>
                    @empty
                        <p class="text-center text-gray-400 text-sm mt-10">
                            এখনো কোনো মেসেজ নেই। প্রথম মেসেজ পাঠান।
                        </p>
                    @endforelse
                </div>

                <form method="POST" action="{{ route('messages.store', $otherUser) }}"
                      class="border-t p-3 flex gap-2">
                    @csrf
                    <input type="text" name="content" required autocomplete="off"
                           placeholder="Type your message..."
                           class="flex-1 border-gray-300 rounded shadow-sm text-sm">
                    <button type="submit"
                            class="px-4 py-2 bg-blue-600 text-white rounded text-sm hover:bg-blue-700">
                        Send
                    </button>
                </form>

            </div>

        </div>
    </div>
</x-dynamic-component>
