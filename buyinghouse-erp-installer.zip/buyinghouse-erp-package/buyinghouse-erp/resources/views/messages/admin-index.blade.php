<x-admin-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">Messages</h2>
    </x-slot>

    <div class="py-8">
        <div class="max-w-xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white shadow rounded divide-y">
                @forelse ($threads as $thread)
                    <a href="{{ route('messages.show', $thread) }}"
                       class="flex justify-between items-center px-4 py-3 hover:bg-gray-50">
                        <span class="text-sm font-medium">{{ $thread->name }}</span>
                        @if ($thread->unread_count > 0)
                            <span class="w-5 h-5 flex items-center justify-center text-xs bg-red-500 text-white rounded-full">
                                {{ $thread->unread_count }}
                            </span>
                        @endif
                    </a>
                @empty
                    <p class="px-4 py-6 text-center text-gray-400 text-sm">No customers yet.</p>
                @endforelse
            </div>
        </div>
    </div>
</x-admin-layout>
