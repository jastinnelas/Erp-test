<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">Two-Factor Authentication সেটআপ</h2>
    </x-slot>

    <div class="py-8">
        <div class="max-w-md mx-auto sm:px-6 lg:px-8">
            <div class="bg-white shadow rounded p-6 text-center">

                @if ($errors->any())
                    <div class="mb-4 bg-red-100 text-red-700 px-4 py-3 rounded text-sm text-left">
                        {{ $errors->first() }}
                    </div>
                @endif

                <p class="text-sm text-gray-600 mb-4">
                    Google Authenticator বা Authy অ্যাপ দিয়ে নিচের QR কোডটি স্ক্যান করুন:
                </p>

                <div id="qrcode" class="flex justify-center mb-4"></div>

                <p class="text-xs text-gray-400 mb-4">
                    স্ক্যান করতে না পারলে ম্যানুয়ালি এই কোড দিন: <br>
                    <code class="bg-gray-100 px-2 py-1 rounded">{{ $user->google2fa_secret }}</code>
                </p>

                <form method="POST" action="{{ route('two-factor.enable') }}">
                    @csrf
                    <input type="text" name="code" maxlength="6" placeholder="৬ সংখ্যার কোড"
                           class="w-full text-center tracking-widest text-lg border-gray-300 rounded shadow-sm mb-3"
                           required autofocus>
                    <button type="submit"
                            class="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700">
                        চালু করুন
                    </button>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/qrcodejs@1.0.0/qrcode.min.js"></script>
    <script>
        new QRCode(document.getElementById("qrcode"), {
            text: @json($otpAuthUrl),
            width: 200,
            height: 200,
        });
    </script>
</x-app-layout>
