<x-brand-layout title="Log in — BuyingCore">

    @if (session('status'))
        <div class="wrap" style="padding-top:20px">
            <div style="background:rgba(75,122,99,.15);color:var(--loom-green);padding:12px 16px;border-radius:6px;font-size:14px;max-width:440px;margin:0 auto">
                {{ session('status') }}
            </div>
        </div>
    @endif

    <div class="form-shell">
        <div class="form-card">
            <h1>Log in</h1>
            <p class="sub">Enter your registered email to continue.</p>

            <form method="POST" action="{{ route('login') }}">
                @csrf

                <div class="field {{ $errors->has('email') ? 'error' : '' }}">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" value="{{ old('email') }}"
                           placeholder="you@example.com" required autofocus autocomplete="username">
                    @error('email')<p class="err" style="display:block">{{ $message }}</p>@enderror
                </div>

                <div class="field {{ $errors->has('password') ? 'error' : '' }}">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" placeholder="••••••••"
                           required autocomplete="current-password">
                    @error('password')<p class="err" style="display:block">{{ $message }}</p>@enderror
                </div>

                <div class="check-row">
                    <input type="checkbox" id="remember" name="remember">
                    <label for="remember" style="margin:0;font-weight:400">Keep me logged in on this device</label>
                </div>

                <button type="submit" class="btn btn-primary btn-block" style="margin-top:22px">Log in</button>
            </form>

            @if (Route::has('password.request'))
                <p class="form-foot"><a href="{{ route('password.request') }}">Forgot password?</a></p>
            @endif
            <p class="form-foot">Don't have an account? <a href="{{ route('register') }}">Sign up</a></p>
        </div>
    </div>

</x-brand-layout>
