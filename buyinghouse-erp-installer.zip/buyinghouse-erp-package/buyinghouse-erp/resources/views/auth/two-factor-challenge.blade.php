<x-guest-layout>
    <div class="mb-4 text-sm text-gray-600">
        আপনার Authenticator অ্যাপ থেকে ৬-সংখ্যার কোডটি দিন।
    </div>

    <form method="POST" action="{{ route('two-factor.verify') }}">
        @csrf
        <div>
            <x-input-label for="code" value="Authentication Code" />
            <x-text-input id="code" name="code" type="text" maxlength="6"
                           class="mt-1 block w-full text-center tracking-widest text-lg"
                           required autofocus />
            <x-input-error :messages="$errors->get('code')" class="mt-2" />
        </div>

        <div class="flex items-center justify-end mt-4">
            <x-primary-button>যাচাই করুন</x-primary-button>
        </div>
    </form>
</x-guest-layout>
