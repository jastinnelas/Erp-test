<x-guest-layout>
    <div class="mb-4 text-sm text-gray-600">
        আপনার ইমেইলে একটি ৬-সংখ্যার কোড পাঠানো হয়েছে। সেটি নিচে দিন।
    </div>

    @if (session('success'))
        <div class="mb-4 text-sm text-green-600">{{ session('success') }}</div>
    @endif

    <form method="POST" action="{{ route('otp.verify') }}">
        @csrf
        <div>
            <x-input-label for="code" value="ভেরিফিকেশন কোড" />
            <x-text-input id="code" name="code" type="text" maxlength="6"
                           class="mt-1 block w-full text-center tracking-widest text-lg"
                           required autofocus />
            <x-input-error :messages="$errors->get('code')" class="mt-2" />
        </div>

        <div class="flex items-center justify-between mt-4">
            <x-primary-button>যাচাই করুন</x-primary-button>
        </div>
    </form>

    <form method="POST" action="{{ route('otp.resend') }}" class="mt-4">
        @csrf
        <button type="submit" class="text-sm text-gray-600 underline hover:text-gray-900">
            কোড পাননি? আবার পাঠান
        </button>
    </form>
</x-guest-layout>
