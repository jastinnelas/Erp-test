<x-brand-layout title="Sign up — BuyingCore">

    <div class="form-shell">
        <div class="form-card">
            <h1>Create your account</h1>
            <p class="sub">Register to start placing bulk orders.</p>

            <form method="POST" action="{{ route('register') }}">
                @csrf

                <div class="field {{ $errors->has('name') ? 'error' : '' }}">
                    <label for="name">Full name or shop name</label>
                    <input type="text" id="name" name="name" value="{{ old('name') }}"
                           placeholder="Jahid Hasan" required autofocus autocomplete="name">
                    @error('name')<p class="err" style="display:block">{{ $message }}</p>@enderror
                </div>

                <div class="field {{ $errors->has('email') ? 'error' : '' }}">
                    <label for="email">Email address</label>
                    <input type="email" id="email" name="email" value="{{ old('email') }}"
                           placeholder="you@example.com" required autocomplete="username">
                    @error('email')<p class="err" style="display:block">{{ $message }}</p>@enderror
                </div>

                <div class="field {{ $errors->has('password') ? 'error' : '' }}">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" placeholder="At least 8 characters"
                           required autocomplete="new-password">
                    @error('password')<p class="err" style="display:block">{{ $message }}</p>@enderror
                </div>

                <div class="field">
                    <label for="password_confirmation">Confirm password</label>
                    <input type="password" id="password_confirmation" name="password_confirmation"
                           placeholder="Repeat password" required autocomplete="new-password">
                </div>

                <div class="check-row">
                    <input type="checkbox" required>
                    <label style="margin:0;font-weight:400">I agree to the Terms and Privacy Policy</label>
                </div>

                <button type="submit" class="btn btn-primary btn-block" style="margin-top:22px">Create account</button>
            </form>

            <p class="form-foot">Already have an account? <a href="{{ route('login') }}">Log in</a></p>
        </div>
    </div>

</x-brand-layout>
