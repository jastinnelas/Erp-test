<x-brand-layout title="About — BuyingCore">

    <div class="about-hero">
        <div class="wrap">
            <div class="crumb"><a href="{{ route('home') }}">Home</a> / About</div>
            <h1>Bulk sourcing, without the guesswork.</h1>
            <p>BuyingCore started as a buying house handling orders the usual way — phone calls, paper slips, and a lot of following up. We built this platform because our own retailers kept asking the same question: "where's my order right now?" Now every one of them can just look.</p>
        </div>
    </div>

    <div class="ledger">
        <div class="wrap ledger-row">
            <div class="ledger-item"><div class="num">2024</div><div class="label">the year we moved online</div></div>
            <div class="ledger-item"><div class="num">3</div><div class="label">factory partners on the platform</div></div>
            <div class="ledger-item"><div class="num">7 days</div><div class="label">average quality-check turnaround</div></div>
        </div>
    </div>

    <section class="section">
        <div class="wrap">
            <div class="section-head">
                <h2>What we hold ourselves to</h2>
            </div>
            <div class="mission-grid">
                <div>
                    <h3 style="font-size:19px;margin-bottom:8px">Traceable by default</h3>
                    <p style="color:var(--ink-soft);font-size:15px">Every order has a stage, and every stage change is logged against it — not kept in someone's head or a phone call log.</p>
                </div>
                <div>
                    <h3 style="font-size:19px;margin-bottom:8px">Priced for volume</h3>
                    <p style="color:var(--ink-soft);font-size:15px">Price breaks are listed on the catalog page itself. What you see before you order is what you pay.</p>
                </div>
                <div>
                    <h3 style="font-size:19px;margin-bottom:8px">Backed by a real production floor</h3>
                    <p style="color:var(--ink-soft);font-size:15px">We're a buying house, not a reseller. Production and quality checks happen on floors we work with directly.</p>
                </div>
                <div>
                    <h3 style="font-size:19px;margin-bottom:8px">One place for the paperwork</h3>
                    <p style="color:var(--ink-soft);font-size:15px">Order confirmation, delivery status and invoice all sit against the same order number — nothing to chase separately.</p>
                </div>
            </div>
        </div>
    </section>

</x-brand-layout>
