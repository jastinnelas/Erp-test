<x-brand-layout title="Catalog — BuyingCore">

    <div class="page-head">
        <div class="wrap">
            <div class="crumb"><a href="{{ route('home') }}">Home</a> / Catalog</div>
            <h1>Order by the hundred</h1>
            <p>Browse the current catalog. Minimum order quantity is 100 pieces per style.</p>
        </div>
    </div>

    <section class="section" style="padding-top:40px">
        <div class="wrap">

            <form method="GET" style="margin-bottom:28px;display:flex;gap:10px;max-width:520px">
                <input type="text" name="search" value="{{ request('search') }}" placeholder="Search styles...">
                <button type="submit" class="btn btn-ghost">Search</button>
            </form>

            @if ($categories->isNotEmpty())
                <div class="filter-tabs">
                    <a href="{{ route('catalog.index') }}" class="{{ ! request('category') ? 'active' : '' }}">All</a>
                    @foreach ($categories as $category)
                        <a href="{{ route('catalog.index', ['category' => $category]) }}"
                           class="{{ request('category') === $category ? 'active' : '' }}">{{ $category }}</a>
                    @endforeach
                </div>
            @endif

            <div class="product-grid">
                @forelse ($products as $product)
                    <div class="product-card">
                        <a class="card-link" href="{{ route('catalog.show', $product) }}">
                            <div class="swatch" style="background:#{{ substr(md5($product->name), 0, 6) }}">
                                <span class="gsm">{{ $product->color ?? 'Multi' }}</span>
                            </div>
                            <div class="product-body">
                                <div class="cat">{{ $product->category ?? 'Apparel' }}</div>
                                <h3>{{ $product->name }}</h3>
                                <div class="spec">
                                    <div class="spec-row"><span>Item code</span><span>{{ $product->item_code }}</span></div>
                                    <div class="spec-row"><span>Unit price</span><span>৳{{ number_format($product->unit_price, 2) }}</span></div>
                                    <div class="spec-row"><span>MOQ</span><span>100 pcs</span></div>
                                </div>
                            </div>
                        </a>
                        <a href="{{ route('orders.create', ['product_id' => $product->id]) }}" class="btn btn-primary">
                            Order this
                        </a>
                    </div>
                @empty
                    <p style="color:var(--ink-soft)">কোনো প্রোডাক্ট পাওয়া যায়নি।</p>
                @endforelse
            </div>

            <div style="margin-top:32px">{{ $products->links() }}</div>

        </div>
    </section>

</x-brand-layout>
