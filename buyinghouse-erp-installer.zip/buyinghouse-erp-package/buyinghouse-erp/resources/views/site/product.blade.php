<x-brand-layout title="{{ $product->name }} — BuyingCore">

    <div class="page-head">
        <div class="wrap">
            <div class="crumb">
                <a href="{{ route('home') }}">Home</a> / <a href="{{ route('catalog.index') }}">Catalog</a> / {{ $product->name }}
            </div>
        </div>
    </div>

    <section class="section" style="padding-top:36px">
        <div class="wrap detail-grid">

            <div>
                <div class="gallery-main" style="background:#{{ substr(md5($product->name), 0, 6) }}"></div>
            </div>

            <div>
                <div class="detail-title">
                    <div class="cat">{{ $product->category ?? 'Apparel' }}</div>
                    <h1>{{ $product->name }}</h1>
                </div>
                <div class="detail-meta">Item code {{ $product->item_code }} · Color {{ $product->color ?? '—' }} · Size {{ $product->size ?? '—' }}</div>

                <div class="tier-table">
                    <div class="tier-row head"><span>Quantity</span><span>Unit Price</span><span>Total</span></div>
                    <div class="tier-row">
                        <span>100 pcs (min)</span>
                        <span>৳{{ number_format($product->unit_price, 2) }}</span>
                        <span>৳{{ number_format($product->unit_price * 100, 2) }}</span>
                    </div>
                    <div class="tier-row">
                        <span>500 pcs</span>
                        <span>৳{{ number_format($product->unit_price, 2) }}</span>
                        <span>৳{{ number_format($product->unit_price * 500, 2) }}</span>
                    </div>
                </div>

                <div class="order-box">
                    <div class="total">
                        <span>Starting from</span>
                        ৳{{ number_format($product->unit_price * 100, 2) }} for 100 pcs
                    </div>
                    <a href="{{ route('orders.create', ['product_id' => $product->id]) }}"
                       class="btn btn-primary btn-block" style="margin-top:16px">
                        Order this style
                    </a>
                </div>
            </div>

        </div>
    </section>

</x-brand-layout>
