<x-brand-layout title="Track an order — BuyingCore">

    <div class="page-head">
        <div class="wrap">
            <div class="crumb"><a href="{{ route('home') }}">Home</a> / Track an order</div>
            <h1>Track an order</h1>
            <p>Enter your order number to see its current stage.</p>
        </div>
    </div>

    <section class="section" style="padding-top:36px">
        <div class="wrap">

            <form method="GET" class="track-search">
                <input type="text" name="order_no" value="{{ request('order_no') }}" placeholder="e.g. ORD-2026-00001">
                <button type="submit" class="btn btn-primary">Track</button>
            </form>

            @if ($order)
                <div class="manifest light" style="max-width:520px;margin-top:32px">
                    <div class="manifest-top">
                        <div>
                            <div class="oid">Order {{ $order->order_no }}</div>
                            <div class="style">{{ $order->product->name }} — {{ $order->quantity }} pcs</div>
                        </div>
                    </div>
                    @php
                        $prodStage = $order->productionEntry?->stage;
                        $delivered = $order->deliveryEntry?->status === 'delivered';
                        $inTransit = in_array($order->deliveryEntry?->status, ['in_transit', 'out_for_delivery']);
                    @endphp
                    <div class="stage-list">
                        <div class="stage done">
                            <span class="dot"></span><span class="stage-label">Order placed</span>
                            <span class="stage-time">{{ $order->order_date->format('M j') }}</span>
                        </div>
                        <div class="stage {{ $prodStage && $prodStage !== 'completed' ? 'current' : ($prodStage ? 'done' : '') }}">
                            <span class="dot"></span><span class="stage-label">In production</span>
                            <span class="stage-time">{{ $prodStage ? ucfirst(str_replace('_', ' ', $prodStage)) : 'Pending' }}</span>
                        </div>
                        <div class="stage {{ $inTransit ? 'current' : ($delivered ? 'done' : '') }}">
                            <span class="dot"></span><span class="stage-label">Out for delivery</span>
                            <span class="stage-time">{{ $inTransit ? 'In transit' : ($delivered ? 'Done' : 'Pending') }}</span>
                        </div>
                        <div class="stage {{ $delivered ? 'done' : '' }}">
                            <span class="dot"></span><span class="stage-label">Delivered</span>
                            <span class="stage-time">{{ $delivered ? 'Delivered' : 'Pending' }}</span>
                        </div>
                    </div>
                </div>
                <p style="margin-top:16px">
                    <a href="{{ route('orders.show', $order) }}" style="color:var(--indigo);font-weight:600">
                        সম্পূর্ণ বিস্তারিত দেখুন →
                    </a>
                </p>
            @elseif ($notFound)
                <div class="track-empty">এই অর্ডার নম্বরে আপনার কোনো অর্ডার পাওয়া যায়নি।</div>
            @endif

        </div>
    </section>

</x-brand-layout>
