<x-brand-layout title="Contact — BuyingCore">

    <div class="page-head">
        <div class="wrap">
            <div class="crumb"><a href="{{ route('home') }}">Home</a> / Contact</div>
            <h1>Get in touch</h1>
            <p>Questions about a style, a bulk quote, or an order already placed — send it here and we'll reply within a business day.</p>
        </div>
    </div>

    <section class="section">
        <div class="wrap contact-grid">

            <div>
                @if (session('success'))
                    <div style="background:rgba(75,122,99,.15);color:var(--loom-green);padding:14px 16px;border-radius:6px;margin-bottom:20px;font-size:14.5px">
                        {{ session('success') }}
                    </div>
                @endif

                <form method="POST" action="{{ route('contact.submit') }}">
                    @csrf
                    <div class="field">
                        <label for="cName">Your name</label>
                        <input type="text" id="cName" name="name" value="{{ old('name') }}"
                               placeholder="Full name or shop name" required>
                    </div>
                    <div class="field-row">
                        <div class="field">
                            <label for="cPhone">Phone</label>
                            <input type="tel" id="cPhone" name="phone" value="{{ old('phone') }}" placeholder="01XXXXXXXXX">
                        </div>
                        <div class="field">
                            <label for="cEmail">Email (optional)</label>
                            <input type="email" id="cEmail" name="email" value="{{ old('email') }}" placeholder="you@example.com">
                        </div>
                    </div>
                    <div class="field">
                        <label for="cMessage">Message</label>
                        <textarea id="cMessage" name="message" rows="5"
                                  placeholder="Tell us what you're sourcing, and roughly how many pieces" required>{{ old('message') }}</textarea>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block" style="margin-top:20px">Send message</button>
                </form>
            </div>

            <div class="contact-info">
                <div class="item">
                    <h4>Office</h4>
                    <div>House 45, Road 7, Sector 3<br>Uttara, Dhaka 1230, Bangladesh</div>
                </div>
                <div class="item">
                    <h4>Phone</h4>
                    <div>+880 1711-234567</div>
                </div>
                <div class="item">
                    <h4>Email</h4>
                    <div>orders@buyingcore.xyz</div>
                </div>
                <div class="item">
                    <h4>Office hours</h4>
                    <div>Sunday – Thursday, 9:00 AM – 6:00 PM</div>
                </div>
            </div>

        </div>
    </section>

</x-brand-layout>
