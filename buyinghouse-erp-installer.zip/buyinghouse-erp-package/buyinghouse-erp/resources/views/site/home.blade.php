<x-brand-layout title="BuyingCore — Place the order. Watch it get made.">

    <section class="hero">
        <div class="wrap hero-grid">
            <div>
                <h1>Place the order.<br>Watch it get made.</h1>
                <p class="lede">BuyingCore is where retailers order apparel by the hundred and follow every piece — cutting, sewing, quality check, delivery — without a single phone call.</p>
                <div class="hero-cta">
                    <a class="btn btn-primary" href="{{ route('catalog.index') }}">Start an order</a>
                    <a class="btn btn-ghost" href="{{ route('track.show') }}">See a live order</a>
                </div>
                <p class="hero-trust">Retailers in Dhaka, Chattogram and Sylhet place orders through BuyingCore every week.</p>
            </div>

            <div class="manifest">
                @if ($sampleOrder)
                    <div class="manifest-top">
                        <div>
                            <div class="oid">Order {{ $sampleOrder->order_no }}</div>
                            <div class="style">{{ $sampleOrder->product->name }} — {{ $sampleOrder->quantity }} pcs</div>
                        </div>
                    </div>
                    @php
                        $prodDone = (bool) $sampleOrder->productionEntry;
                        $prodStage = $sampleOrder->productionEntry?->stage;
                        $delivered = $sampleOrder->deliveryEntry?->status === 'delivered';
                        $inTransit = in_array($sampleOrder->deliveryEntry?->status, ['in_transit', 'out_for_delivery']);
                    @endphp
                    <div class="stage-list">
                        <div class="stage done">
                            <span class="dot"></span><span class="stage-label">Order placed</span>
                            <span class="stage-time">{{ $sampleOrder->order_date->format('M j') }}</span>
                        </div>
                        <div class="stage {{ $prodDone && $prodStage !== 'completed' ? 'current' : ($prodDone ? 'done' : '') }}">
                            <span class="dot"></span><span class="stage-label">In production</span>
                            <span class="stage-time">{{ $prodDone ? ucfirst(str_replace('_', ' ', $prodStage)) : 'Pending' }}</span>
                        </div>
                        <div class="stage {{ $prodStage === 'quality_check' ? 'current' : ($prodStage === 'completed' ? 'done' : '') }}">
                            <span class="dot"></span><span class="stage-label">Quality check</span>
                            <span class="stage-time">{{ $prodStage === 'completed' ? 'Passed' : 'Pending' }}</span>
                        </div>
                        <div class="stage {{ $inTransit ? 'current' : ($delivered ? 'done' : '') }}">
                            <span class="dot"></span><span class="stage-label">Out for delivery</span>
                            <span class="stage-time">{{ $inTransit ? 'In transit' : ($delivered ? 'Done' : 'Pending') }}</span>
                        </div>
                        <div class="stage {{ $delivered ? 'done' : '' }}">
                            <span class="dot"></span><span class="stage-label">Delivered</span>
                            <span class="stage-time">{{ $delivered ? 'Delivered' : 'Pending' }}</span>
                        </div>
                    </div>
                @else
                    <div class="manifest-top">
                        <div>
                            <div class="oid">No orders yet</div>
                            <div class="style">প্রথম অর্ডার এলে এখানে live দেখা যাবে</div>
                        </div>
                    </div>
                @endif
            </div>
        </div>
    </section>

    <div class="ledger">
        <div class="wrap ledger-row">
            <div class="ledger-item">
                <div class="num">{{ $stats['buyers'] }}+</div>
                <div class="label">retailers registered</div>
            </div>
            <div class="ledger-item">
                <div class="num">{{ number_format($stats['pieces']) }}</div>
                <div class="label">pieces ordered to date</div>
            </div>
            <div class="ledger-item">
                <div class="num">{{ $stats['products'] }}</div>
                <div class="label">styles in catalog</div>
            </div>
        </div>
    </div>

    <section class="section" id="how">
        <div class="wrap">
            <div class="section-head">
                <h2>How an order moves</h2>
                <p>Four stages, visible to you the whole way — the same pipeline our production floor and delivery team work from.</p>
            </div>
            <div class="steps">
                <div class="step">
                    <div class="step-num">1</div>
                    <h3>Place your order</h3>
                    <p>Minimum 100 pieces per style. Choose sizes and colours, submit — no separate quote call needed.</p>
                </div>
                <div class="step">
                    <div class="step-num">2</div>
                    <h3>Production starts</h3>
                    <p>Cutting and sewing begin at the factory floor. Your order page updates the moment the stage changes.</p>
                </div>
                <div class="step">
                    <div class="step-num">3</div>
                    <h3>Quality checked</h3>
                    <p>Every batch is inspected before it leaves the floor, with the result recorded against your order.</p>
                </div>
                <div class="step">
                    <div class="step-num">4</div>
                    <h3>Delivered and invoiced</h3>
                    <p>Your order arrives with a courier you can track, and the invoice is ready to pay the same day.</p>
                </div>
            </div>
        </div>
    </section>

</x-brand-layout>
