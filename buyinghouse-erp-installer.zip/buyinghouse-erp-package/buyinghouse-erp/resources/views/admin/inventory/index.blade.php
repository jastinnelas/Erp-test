<x-admin-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">Inventory</h2>
    </x-slot>

    <div class="py-8">
        <div class="max-w-5xl mx-auto sm:px-6 lg:px-8">

            @if (session('success'))
                <div class="mb-4 bg-green-100 text-green-800 px-4 py-3 rounded">{{ session('success') }}</div>
            @endif

            <div class="flex justify-between items-center mb-4">
                <p class="text-sm text-gray-500">{{ $inventory->total() }} stock entries</p>
                <a href="{{ route('admin.inventory.create') }}"
                   class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">+ Add stock entry</a>
            </div>

            <div class="bg-white shadow rounded overflow-x-auto">
                <table class="min-w-full text-sm text-left">
                    <thead class="bg-gray-50 text-gray-600">
                        <tr>
                            <th class="px-4 py-3">Product</th>
                            <th class="px-4 py-3">Supplier</th>
                            <th class="px-4 py-3">Stock Qty</th>
                            <th class="px-4 py-3">Status</th>
                            <th class="px-4 py-3"></th>
                        </tr>
                    </thead>
                    <tbody class="divide-y">
                        @forelse ($inventory as $item)
                            <tr>
                                <td class="px-4 py-3 font-medium">{{ $item->product->name }}</td>
                                <td class="px-4 py-3">{{ $item->supplier?->name ?? '—' }}</td>
                                <td class="px-4 py-3">{{ $item->stock_qty }}</td>
                                <td class="px-4 py-3">
                                    @php
                                        $badgeColors = [
                                            'in_stock' => 'bg-green-100 text-green-700',
                                            'low_stock' => 'bg-yellow-100 text-yellow-700',
                                            'out_of_stock' => 'bg-red-100 text-red-700',
                                        ];
                                    @endphp
                                    <span class="px-2 py-1 rounded text-xs {{ $badgeColors[$item->status] ?? '' }}">
                                        {{ str_replace('_', ' ', $item->status) }}
                                    </span>
                                </td>
                                <td class="px-4 py-3 text-right space-x-2">
                                    <a href="{{ route('admin.inventory.edit', $item) }}"
                                       class="text-blue-600 hover:underline">Edit</a>
                                    <form action="{{ route('admin.inventory.destroy', $item) }}" method="POST"
                                          class="inline">
                                        @csrf @method('DELETE')
                                        <x-confirm-button message="এই স্টক এন্ট্রিটি মুছে ফেলতে চান?">Delete</x-confirm-button>
                                    </form>
                                </td>
                            </tr>
                        @empty
                            <tr><td colspan="5" class="px-4 py-6 text-center text-gray-400">No stock entries yet.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>

            <div class="mt-4">{{ $inventory->links() }}</div>

        </div>
    </div>
</x-admin-layout>
