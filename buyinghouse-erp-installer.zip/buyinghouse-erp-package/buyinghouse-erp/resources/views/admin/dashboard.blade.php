<x-admin-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Admin Dashboard
        </h2>
    </x-slot>

    <div class="py-8">
        <div class="max-w-6xl mx-auto sm:px-6 lg:px-8">

            <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                <div class="bg-white shadow rounded p-4">
                    <p class="text-xs text-gray-500">Total Orders</p>
                    <p class="text-2xl font-semibold">{{ $stats['total_orders'] }}</p>
                </div>
                <div class="bg-white shadow rounded p-4">
                    <p class="text-xs text-gray-500">In Production</p>
                    <p class="text-2xl font-semibold">{{ $stats['in_production'] }}</p>
                </div>
                <div class="bg-white shadow rounded p-4">
                    <p class="text-xs text-gray-500">Delivered</p>
                    <p class="text-2xl font-semibold">{{ $stats['delivered'] }}</p>
                </div>
                <div class="bg-white shadow rounded p-4">
                    <p class="text-xs text-gray-500">Pending Invoices</p>
                    <p class="text-2xl font-semibold">{{ $stats['pending_invoices'] }}</p>
                </div>
            </div>

            <div class="bg-white shadow rounded p-4 mb-6">
                <p class="text-sm font-medium text-gray-600 mb-3">গত ৬ মাসের অর্ডার ট্রেন্ড</p>
                <canvas id="monthlyTrendChart" height="80"></canvas>
            </div>

            <div class="bg-white shadow rounded overflow-x-auto">
                <div class="px-4 py-3 border-b font-medium text-sm text-gray-600 flex justify-between items-center">
                    <span>Recent Orders</span>
                    <a href="{{ route('admin.export.orders') }}" class="text-blue-600 hover:underline text-xs">
                        ⬇ Export all orders (CSV)
                    </a>
                </div>
                <table class="min-w-full text-sm text-left">
                    <thead class="bg-gray-50 text-gray-600">
                        <tr>
                            <th class="px-4 py-3">Order No</th>
                            <th class="px-4 py-3">Customer</th>
                            <th class="px-4 py-3">Product</th>
                            <th class="px-4 py-3">Qty</th>
                            <th class="px-4 py-3">Status</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y">
                        @forelse ($recentOrders as $order)
                            <tr>
                                <td class="px-4 py-3 font-medium">{{ $order->order_no }}</td>
                                <td class="px-4 py-3">{{ $order->user->name }}</td>
                                <td class="px-4 py-3">{{ $order->product->name }}</td>
                                <td class="px-4 py-3">{{ $order->quantity }}</td>
                                <td class="px-4 py-3 capitalize">{{ str_replace('_', ' ', $order->status) }}</td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="5" class="px-4 py-6 text-center text-gray-400">No orders yet.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>

        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script>
    <script>
        const ctx = document.getElementById('monthlyTrendChart');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: @json($monthlyTrend->pluck('label')),
                datasets: [{
                    label: 'Orders',
                    data: @json($monthlyTrend->pluck('count')),
                    borderColor: '#2563eb',
                    backgroundColor: 'rgba(37, 99, 235, 0.1)',
                    tension: 0.3,
                    fill: true,
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { display: false } },
                scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } }
            }
        });
    </script>
</x-admin-layout>
