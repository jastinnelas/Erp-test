<x-admin-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Invoices
        </h2>
    </x-slot>

    <div class="py-8">
        <div class="max-w-6xl mx-auto sm:px-6 lg:px-8">

            @if (session('success'))
                <div class="mb-4 bg-green-100 text-green-800 px-4 py-3 rounded">
                    {{ session('success') }}
                </div>
            @endif

            <div class="flex justify-between items-center mb-4">
                <p class="text-sm text-gray-500">{{ $invoices->total() }} invoices</p>
                <a href="{{ route('admin.export.invoices') }}"
                   class="px-4 py-2 border rounded hover:bg-gray-50 text-sm">
                    ⬇ Export CSV
                </a>
                <a href="{{ route('admin.invoices.create') }}"
                   class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
                    + Create invoice
                </a>
            </div>

            <div class="bg-white shadow rounded overflow-x-auto">
                <table class="min-w-full text-sm text-left">
                    <thead class="bg-gray-50 text-gray-600">
                        <tr>
                            <th class="px-4 py-3">Invoice No</th>
                            <th class="px-4 py-3">Order No</th>
                            <th class="px-4 py-3">Customer</th>
                            <th class="px-4 py-3">Amount</th>
                            <th class="px-4 py-3">Payment</th>
                            <th class="px-4 py-3"></th>
                        </tr>
                    </thead>
                    <tbody class="divide-y">
                        @forelse ($invoices as $invoice)
                            <tr>
                                <td class="px-4 py-3 font-medium">{{ $invoice->invoice_no }}</td>
                                <td class="px-4 py-3">{{ $invoice->order->order_no }}</td>
                                <td class="px-4 py-3">{{ $invoice->order->user->name }}</td>
                                <td class="px-4 py-3">৳{{ number_format($invoice->amount, 2) }}</td>
                                <td class="px-4 py-3">
                                    @php
                                        $badgeColors = [
                                            'pending' => 'bg-yellow-100 text-yellow-700',
                                            'paid' => 'bg-green-100 text-green-700',
                                            'overdue' => 'bg-red-100 text-red-700',
                                        ];
                                    @endphp
                                    <span class="px-2 py-1 rounded text-xs {{ $badgeColors[$invoice->payment_status] ?? '' }}">
                                        {{ ucfirst($invoice->payment_status) }}
                                    </span>
                                </td>
                                <td class="px-4 py-3 text-right space-x-2">
                                    <a href="{{ route('admin.invoices.show', $invoice) }}"
                                       class="text-blue-600 hover:underline">View</a>
                                    <a href="{{ route('admin.invoices.edit', $invoice) }}"
                                       class="text-blue-600 hover:underline">Edit</a>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="6" class="px-4 py-6 text-center text-gray-400">
                                    No invoices yet.
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>

            <div class="mt-4">{{ $invoices->links() }}</div>

        </div>
    </div>
</x-admin-layout>
