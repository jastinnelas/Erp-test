<x-admin-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Create Invoice
        </h2>
    </x-slot>

    <div class="py-8">
        <div class="max-w-xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white shadow rounded p-6">

                @if ($errors->any())
                    <div class="mb-4 bg-red-100 text-red-700 px-4 py-3 rounded">
                        <ul class="list-disc list-inside text-sm">
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                <form method="POST" action="{{ route('admin.invoices.store') }}" class="space-y-4">
                    @csrf

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Order</label>
                        <select name="order_id" required class="w-full border-gray-300 rounded shadow-sm">
                            <option value="">-- Select an order --</option>
                            @foreach ($orders as $order)
                                <option value="{{ $order->id }}"
                                    {{ (old('order_id', $selectedOrderId)) == $order->id ? 'selected' : '' }}>
                                    {{ $order->order_no }} — {{ $order->user->name }} — {{ $order->product->name }}
                                </option>
                            @endforeach
                        </select>
                        <p class="text-xs text-gray-400 mt-1">
                            শুধু যেসব অর্ডার ইতিমধ্যে ডেলিভার হয়েছে কিন্তু ইনভয়েস এখনো নেই, তা দেখানো হচ্ছে।
                        </p>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Amount (৳)</label>
                        <input type="number" step="0.01" name="amount" value="{{ old('amount') }}"
                               required class="w-full border-gray-300 rounded shadow-sm">
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Payment Status</label>
                        <select name="payment_status" required class="w-full border-gray-300 rounded shadow-sm">
                            @foreach (['pending', 'paid', 'overdue'] as $status)
                                <option value="{{ $status }}" {{ old('payment_status') === $status ? 'selected' : '' }}>
                                    {{ ucfirst($status) }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Issue Date</label>
                            <input type="date" name="issue_date" value="{{ old('issue_date', date('Y-m-d')) }}"
                                   required class="w-full border-gray-300 rounded shadow-sm">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Due Date</label>
                            <input type="date" name="due_date" value="{{ old('due_date') }}"
                                   class="w-full border-gray-300 rounded shadow-sm">
                        </div>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Remarks</label>
                        <textarea name="remarks" rows="3"
                                  class="w-full border-gray-300 rounded shadow-sm">{{ old('remarks') }}</textarea>
                    </div>

                    <div class="flex justify-end gap-2 pt-2">
                        <a href="{{ route('admin.invoices.index') }}"
                           class="px-4 py-2 rounded border text-gray-600 hover:bg-gray-50">Cancel</a>
                        <button type="submit"
                                class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Generate invoice</button>
                    </div>

                </form>
            </div>
        </div>
    </div>
</x-admin-layout>
