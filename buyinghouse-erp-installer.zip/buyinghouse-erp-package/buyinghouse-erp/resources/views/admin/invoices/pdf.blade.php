<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body { font-family: DejaVu Sans, sans-serif; font-size: 13px; color: #222; }
        .header { text-align: center; margin-bottom: 20px; }
        .header h2 { margin: 0; color: #2563eb; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        td, th { padding: 6px 8px; text-align: left; }
        .label { color: #666; width: 40%; }
        .total-row td { border-top: 2px solid #333; font-weight: bold; font-size: 15px; padding-top: 10px; }
        .badge { display: inline-block; padding: 3px 10px; border-radius: 12px; font-size: 11px; }
        .paid { background: #d1fae5; color: #065f46; }
        .pending { background: #fef3c7; color: #92400e; }
        .overdue { background: #fee2e2; color: #991b1b; }
    </style>
</head>
<body>
    <div class="header">
        <h2>INVOICE</h2>
        <p>{{ $invoice->invoice_no }}</p>
        <span class="badge {{ $invoice->payment_status }}">{{ ucfirst($invoice->payment_status) }}</span>
    </div>

    <table>
        <tr><td class="label">Order No</td><td>{{ $invoice->order->order_no }}</td></tr>
        <tr><td class="label">Customer</td><td>{{ $invoice->order->user->name }}</td></tr>
        <tr><td class="label">Product</td><td>{{ $invoice->order->product->name }}</td></tr>
        <tr><td class="label">Quantity</td><td>{{ $invoice->order->quantity }} pcs</td></tr>
        <tr><td class="label">Issue Date</td><td>{{ $invoice->issue_date->format('d M, Y') }}</td></tr>
        <tr><td class="label">Due Date</td><td>{{ $invoice->due_date?->format('d M, Y') ?? '—' }}</td></tr>
        <tr class="total-row">
            <td>Total Amount</td>
            <td>Tk {{ number_format($invoice->amount, 2) }}</td>
        </tr>
    </table>

    @if ($invoice->remarks)
        <p style="margin-top: 20px;"><strong>Remarks:</strong> {{ $invoice->remarks }}</p>
    @endif

    <p style="margin-top: 40px; font-size: 11px; color: #999; text-align: center;">
        Generated on {{ now()->format('d M, Y h:i A') }} — Buying House ERP
    </p>
</body>
</html>
