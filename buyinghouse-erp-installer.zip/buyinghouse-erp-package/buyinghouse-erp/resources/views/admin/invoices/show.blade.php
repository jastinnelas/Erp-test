<x-admin-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Invoice — {{ $invoice->invoice_no }}
        </h2>
    </x-slot>

    <div class="py-8">
        <div class="max-w-xl mx-auto sm:px-6 lg:px-8">

            @if (session('success'))
                <div class="mb-4 bg-green-100 text-green-800 px-4 py-3 rounded">
                    {{ session('success') }}
                </div>
            @endif

            <div class="bg-white shadow rounded p-6">

                <div class="text-center border-b pb-4 mb-4">
                    <p class="text-xs uppercase tracking-wide text-gray-400">Invoice</p>
                    <p class="text-lg font-semibold text-blue-700">{{ $invoice->invoice_no }}</p>
                    <span class="inline-block mt-1 px-3 py-1 text-xs rounded-full
                        {{ $invoice->payment_status === 'paid' ? 'bg-green-100 text-green-700' :
                           ($invoice->payment_status === 'overdue' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700') }}">
                        {{ ucfirst($invoice->payment_status) }}
                    </span>
                </div>

                <dl class="grid grid-cols-2 gap-y-3 text-sm">
                    <dt class="text-gray-500">Order No</dt>
                    <dd class="text-right font-medium">{{ $invoice->order->order_no }}</dd>

                    <dt class="text-gray-500">Customer</dt>
                    <dd class="text-right">{{ $invoice->order->user->name }}</dd>

                    <dt class="text-gray-500">Product</dt>
                    <dd class="text-right">{{ $invoice->order->product->name }}</dd>

                    <dt class="text-gray-500">Quantity</dt>
                    <dd class="text-right">{{ $invoice->order->quantity }} pcs</dd>

                    <dt class="text-gray-500">Issue Date</dt>
                    <dd class="text-right">{{ $invoice->issue_date->format('d M, Y') }}</dd>

                    <dt class="text-gray-500">Due Date</dt>
                    <dd class="text-right">{{ $invoice->due_date?->format('d M, Y') ?? '—' }}</dd>

                    <dt class="text-gray-500 font-semibold text-base pt-2">Total Amount</dt>
                    <dd class="text-right font-semibold text-base pt-2">৳{{ number_format($invoice->amount, 2) }}</dd>
                </dl>

                @if ($invoice->remarks)
                    <div class="mt-4 pt-4 border-t text-sm text-gray-500">
                        <span class="font-medium text-gray-600">Remarks:</span> {{ $invoice->remarks }}
                    </div>
                @endif

                <div class="mt-6 flex justify-between">
                    <a href="{{ route('admin.invoices.index') }}" class="text-blue-600 hover:underline text-sm">
                        ← All invoices
                    </a>
                    <div class="space-x-2">
                        <a href="{{ route('admin.invoices.edit', $invoice) }}"
                           class="px-3 py-2 border rounded text-sm hover:bg-gray-50">Edit</a>
                        <a href="{{ route('admin.invoices.pdf', $invoice) }}"
                           class="px-4 py-2 bg-green-600 text-white rounded text-sm hover:bg-green-700">
                            Download PDF
                        </a>
                        <button onclick="window.print()"
                                class="px-4 py-2 bg-gray-800 text-white rounded text-sm hover:bg-gray-900">
                            Print
                        </button>
                    </div>
                </div>

            </div>

        </div>
    </div>
</x-admin-layout>
