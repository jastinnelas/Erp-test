@props(['supplier' => null])

<div>
    <label class="block text-sm font-medium text-gray-700 mb-1">Name</label>
    <input type="text" name="name" value="{{ old('name', $supplier?->name ?? '') }}"
           required class="w-full border-gray-300 rounded shadow-sm">
</div>

<div>
    <label class="block text-sm font-medium text-gray-700 mb-1">Contact</label>
    <input type="text" name="contact" value="{{ old('contact', $supplier?->contact ?? '') }}"
           class="w-full border-gray-300 rounded shadow-sm">
</div>

<div>
    <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
    <input type="email" name="email" value="{{ old('email', $supplier?->email ?? '') }}"
           class="w-full border-gray-300 rounded shadow-sm">
</div>

<div>
    <label class="block text-sm font-medium text-gray-700 mb-1">Address</label>
    <textarea name="address" rows="2" class="w-full border-gray-300 rounded shadow-sm">{{ old('address', $supplier?->address ?? '') }}</textarea>
</div>

<div>
    <label class="block text-sm font-medium text-gray-700 mb-1">Rating (0–5)</label>
    <input type="number" name="rating" min="0" max="5"
           value="{{ old('rating', $supplier?->rating ?? 3) }}"
           required class="w-full border-gray-300 rounded shadow-sm">
</div>
