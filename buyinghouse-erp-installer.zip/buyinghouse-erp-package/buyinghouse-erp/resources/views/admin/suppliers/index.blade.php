<x-admin-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">Suppliers</h2>
    </x-slot>

    <div class="py-8">
        <div class="max-w-5xl mx-auto sm:px-6 lg:px-8">

            @if (session('success'))
                <div class="mb-4 bg-green-100 text-green-800 px-4 py-3 rounded">{{ session('success') }}</div>
            @endif

            <div class="flex justify-between items-center mb-4">
                <p class="text-sm text-gray-500">{{ $suppliers->total() }} suppliers</p>
                <a href="{{ route('admin.suppliers.create') }}"
                   class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">+ Add supplier</a>
            </div>

            <div class="bg-white shadow rounded overflow-x-auto">
                <table class="min-w-full text-sm text-left">
                    <thead class="bg-gray-50 text-gray-600">
                        <tr>
                            <th class="px-4 py-3">Name</th>
                            <th class="px-4 py-3">Contact</th>
                            <th class="px-4 py-3">Rating</th>
                            <th class="px-4 py-3">Active Orders</th>
                            <th class="px-4 py-3"></th>
                        </tr>
                    </thead>
                    <tbody class="divide-y">
                        @forelse ($suppliers as $supplier)
                            <tr>
                                <td class="px-4 py-3 font-medium">{{ $supplier->name }}</td>
                                <td class="px-4 py-3">{{ $supplier->contact ?? '—' }}</td>
                                <td class="px-4 py-3">{{ str_repeat('★', $supplier->rating) }}{{ str_repeat('☆', 5 - $supplier->rating) }}</td>
                                <td class="px-4 py-3">{{ $supplier->production_entries_count }}</td>
                                <td class="px-4 py-3 text-right space-x-2">
                                    <a href="{{ route('admin.suppliers.edit', $supplier) }}"
                                       class="text-blue-600 hover:underline">Edit</a>
                                    <form action="{{ route('admin.suppliers.destroy', $supplier) }}" method="POST"
                                          class="inline">
                                        @csrf @method('DELETE')
                                        <x-confirm-button message="এই সাপ্লায়ারকে মুছে ফেলতে চান?">Delete</x-confirm-button>
                                    </form>
                                </td>
                            </tr>
                        @empty
                            <tr><td colspan="5" class="px-4 py-6 text-center text-gray-400">No suppliers yet.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>

            <div class="mt-4">{{ $suppliers->links() }}</div>

        </div>
    </div>
</x-admin-layout>
