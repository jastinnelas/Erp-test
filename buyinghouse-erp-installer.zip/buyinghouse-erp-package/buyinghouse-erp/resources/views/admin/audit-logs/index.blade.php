<x-admin-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">Audit Log</h2>
    </x-slot>

    <div class="py-8">
        <div class="max-w-5xl mx-auto sm:px-6 lg:px-8">

            <div class="bg-white shadow rounded overflow-x-auto">
                <table class="min-w-full text-sm text-left">
                    <thead class="bg-gray-50 text-gray-600">
                        <tr>
                            <th class="px-4 py-3">সময়</th>
                            <th class="px-4 py-3">কে করেছে</th>
                            <th class="px-4 py-3">অ্যাকশন</th>
                            <th class="px-4 py-3">বিস্তারিত</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y">
                        @forelse ($logs as $log)
                            <tr>
                                <td class="px-4 py-3 whitespace-nowrap">{{ $log->created_at->format('d M, h:i A') }}</td>
                                <td class="px-4 py-3">{{ $log->user?->name ?? 'System' }}</td>
                                <td class="px-4 py-3">
                                    <span class="px-2 py-1 rounded text-xs bg-blue-100 text-blue-700">
                                        {{ str_replace('_', ' ', $log->action) }}
                                    </span>
                                </td>
                                <td class="px-4 py-3">{{ $log->description }}</td>
                            </tr>
                        @empty
                            <tr><td colspan="4" class="px-4 py-6 text-center text-gray-400">এখনো কোনো লগ নেই।</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>

            <div class="mt-4">{{ $logs->links() }}</div>

        </div>
    </div>
</x-admin-layout>
