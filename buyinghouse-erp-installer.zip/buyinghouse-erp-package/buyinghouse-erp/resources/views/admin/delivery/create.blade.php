<x-admin-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            New Delivery Entry
        </h2>
    </x-slot>

    <div class="py-8">
        <div class="max-w-xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white shadow rounded p-6">

                @if ($errors->any())
                    <div class="mb-4 bg-red-100 text-red-700 px-4 py-3 rounded">
                        <ul class="list-disc list-inside text-sm">
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                <form method="POST" action="{{ route('admin.delivery.store') }}" class="space-y-4">
                    @csrf

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Order</label>
                        <select name="order_id" required class="w-full border-gray-300 rounded shadow-sm">
                            <option value="">-- Select an order --</option>
                            @foreach ($orders as $order)
                                <option value="{{ $order->id }}"
                                    {{ (old('order_id', $selectedOrderId)) == $order->id ? 'selected' : '' }}>
                                    {{ $order->order_no }} — {{ $order->user->name }} — {{ $order->product->name }}
                                </option>
                            @endforeach
                        </select>
                        <p class="text-xs text-gray-400 mt-1">
                            শুধু যেসব অর্ডারের প্রোডাকশন সম্পন্ন হয়েছে ("completed") কিন্তু delivery entry এখনো নেই, তা দেখানো হচ্ছে।
                        </p>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Courier / Delivery partner</label>
                        <input type="text" name="courier" value="{{ old('courier') }}"
                               class="w-full border-gray-300 rounded shadow-sm" placeholder="যেমন: Pathao, Steadfast">
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Tracking No</label>
                        <input type="text" name="tracking_no" value="{{ old('tracking_no') }}"
                               class="w-full border-gray-300 rounded shadow-sm">
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Delivery Address</label>
                        <textarea name="delivery_address" rows="2"
                                  class="w-full border-gray-300 rounded shadow-sm">{{ old('delivery_address') }}</textarea>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Status</label>
                        <select name="status" required class="w-full border-gray-300 rounded shadow-sm">
                            @foreach (['pending_dispatch', 'in_transit', 'out_for_delivery', 'delivered', 'delayed'] as $status)
                                <option value="{{ $status }}" {{ old('status') === $status ? 'selected' : '' }}>
                                    {{ str_replace('_', ' ', ucfirst($status)) }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <div class="flex justify-end gap-2 pt-2">
                        <a href="{{ route('admin.delivery.index') }}"
                           class="px-4 py-2 rounded border text-gray-600 hover:bg-gray-50">Cancel</a>
                        <button type="submit"
                                class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Save entry</button>
                    </div>

                </form>
            </div>
        </div>
    </div>
</x-admin-layout>
