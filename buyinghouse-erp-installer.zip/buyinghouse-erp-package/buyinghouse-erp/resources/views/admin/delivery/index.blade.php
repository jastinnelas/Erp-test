<x-admin-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Delivery Entries
        </h2>
    </x-slot>

    <div class="py-8">
        <div class="max-w-6xl mx-auto sm:px-6 lg:px-8">

            @if (session('success'))
                <div class="mb-4 bg-green-100 text-green-800 px-4 py-3 rounded">
                    {{ session('success') }}
                </div>
            @endif

            <div class="flex justify-between items-center mb-4">
                <p class="text-sm text-gray-500">{{ $entries->total() }} entries</p>
                <a href="{{ route('admin.delivery.create') }}"
                   class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
                    + Add delivery
                </a>
            </div>

            <div class="bg-white shadow rounded overflow-x-auto">
                <table class="min-w-full text-sm text-left">
                    <thead class="bg-gray-50 text-gray-600">
                        <tr>
                            <th class="px-4 py-3">Order No</th>
                            <th class="px-4 py-3">Customer</th>
                            <th class="px-4 py-3">Courier</th>
                            <th class="px-4 py-3">Tracking No</th>
                            <th class="px-4 py-3">Status</th>
                            <th class="px-4 py-3"></th>
                        </tr>
                    </thead>
                    <tbody class="divide-y">
                        @forelse ($entries as $entry)
                            <tr>
                                <td class="px-4 py-3 font-medium">{{ $entry->order->order_no }}</td>
                                <td class="px-4 py-3">{{ $entry->order->user->name }}</td>
                                <td class="px-4 py-3">{{ $entry->courier ?? '—' }}</td>
                                <td class="px-4 py-3">{{ $entry->tracking_no ?? '—' }}</td>
                                <td class="px-4 py-3">
                                    @php
                                        $badgeColors = [
                                            'pending_dispatch' => 'bg-gray-100 text-gray-600',
                                            'in_transit' => 'bg-blue-100 text-blue-700',
                                            'out_for_delivery' => 'bg-purple-100 text-purple-700',
                                            'delivered' => 'bg-green-100 text-green-700',
                                            'delayed' => 'bg-red-100 text-red-700',
                                        ];
                                    @endphp
                                    <span class="px-2 py-1 rounded text-xs {{ $badgeColors[$entry->status] ?? '' }}">
                                        {{ str_replace('_', ' ', $entry->status) }}
                                    </span>
                                </td>
                                <td class="px-4 py-3 text-right space-x-2">
                                    <a href="{{ route('admin.delivery.edit', $entry) }}"
                                       class="text-blue-600 hover:underline">Edit</a>
                                    <form action="{{ route('admin.delivery.destroy', $entry) }}"
                                          method="POST" class="inline">
                                        @csrf @method('DELETE')
                                        <x-confirm-button message="এই ডেলিভারি এন্ট্রিটি মুছে ফেলতে চান?">Delete</x-confirm-button>
                                    </form>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="6" class="px-4 py-6 text-center text-gray-400">
                                    No delivery entries yet.
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>

            <div class="mt-4">{{ $entries->links() }}</div>

        </div>
    </div>
</x-admin-layout>
