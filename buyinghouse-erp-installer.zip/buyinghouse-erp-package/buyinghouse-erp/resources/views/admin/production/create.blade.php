<x-admin-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            New Production Entry
        </h2>
    </x-slot>

    <div class="py-8">
        <div class="max-w-xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white shadow rounded p-6">

                @if ($errors->any())
                    <div class="mb-4 bg-red-100 text-red-700 px-4 py-3 rounded">
                        <ul class="list-disc list-inside text-sm">
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                <form method="POST" action="{{ route('admin.production.store') }}" class="space-y-4">
                    @csrf

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Order</label>
                        <select name="order_id" required class="w-full border-gray-300 rounded shadow-sm">
                            <option value="">-- Select an order --</option>
                            @foreach ($orders as $order)
                                <option value="{{ $order->id }}"
                                    {{ (old('order_id', $selectedOrderId)) == $order->id ? 'selected' : '' }}>
                                    {{ $order->order_no }} — {{ $order->user->name }} — {{ $order->product->name }}
                                </option>
                            @endforeach
                        </select>
                        <p class="text-xs text-gray-400 mt-1">শুধু যেসব অর্ডারের এখনো production entry নেই, তা দেখানো হচ্ছে।</p>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Supplier / Factory</label>
                        <select name="supplier_id" class="w-full border-gray-300 rounded shadow-sm">
                            <option value="">-- None --</option>
                            @foreach ($suppliers as $supplier)
                                <option value="{{ $supplier->id }}" {{ old('supplier_id') == $supplier->id ? 'selected' : '' }}>
                                    {{ $supplier->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Stage</label>
                        <select name="stage" required class="w-full border-gray-300 rounded shadow-sm">
                            @foreach (['queued', 'in_production', 'quality_check', 'completed', 'delayed'] as $stage)
                                <option value="{{ $stage }}" {{ old('stage') === $stage ? 'selected' : '' }}>
                                    {{ str_replace('_', ' ', ucfirst($stage)) }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Start time</label>
                            <input type="datetime-local" name="start_time" value="{{ old('start_time') }}"
                                   class="w-full border-gray-300 rounded shadow-sm">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Finish time</label>
                            <input type="datetime-local" name="finish_time" value="{{ old('finish_time') }}"
                                   class="w-full border-gray-300 rounded shadow-sm">
                        </div>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Remarks</label>
                        <textarea name="remarks" rows="3"
                                  class="w-full border-gray-300 rounded shadow-sm">{{ old('remarks') }}</textarea>
                    </div>

                    <div class="flex justify-end gap-2 pt-2">
                        <a href="{{ route('admin.production.index') }}"
                           class="px-4 py-2 rounded border text-gray-600 hover:bg-gray-50">Cancel</a>
                        <button type="submit"
                                class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Save entry</button>
                    </div>

                </form>
            </div>
        </div>
    </div>
</x-admin-layout>
