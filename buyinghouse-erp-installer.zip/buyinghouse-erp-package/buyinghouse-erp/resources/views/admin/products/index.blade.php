<x-admin-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">Products</h2>
    </x-slot>

    <div class="py-8">
        <div class="max-w-5xl mx-auto sm:px-6 lg:px-8">

            @if (session('success'))
                <div class="mb-4 bg-green-100 text-green-800 px-4 py-3 rounded">{{ session('success') }}</div>
            @endif

            <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 mb-4">
                <form method="GET" class="flex-1 w-full sm:max-w-xs">
                    <input type="text" name="search" value="{{ request('search') }}"
                           placeholder="নাম বা কোড দিয়ে সার্চ করুন..."
                           class="w-full border-gray-300 rounded shadow-sm text-sm">
                </form>
                <a href="{{ route('admin.products.create') }}"
                   class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 whitespace-nowrap">
                    + Add product
                </a>
            </div>

            <div class="bg-white shadow rounded overflow-x-auto">
                <table class="min-w-full text-sm text-left">
                    <thead class="bg-gray-50 text-gray-600">
                        <tr>
                            <th class="px-4 py-3">Image</th>
                            <th class="px-4 py-3">Name</th>
                            <th class="px-4 py-3">Item Code</th>
                            <th class="px-4 py-3">Price</th>
                            <th class="px-4 py-3"></th>
                        </tr>
                    </thead>
                    <tbody class="divide-y">
                        @forelse ($products as $product)
                            <tr>
                                <td class="px-4 py-3">
                                    @if ($product->image_path)
                                        <img src="{{ asset('storage/' . $product->image_path) }}"
                                             class="w-10 h-10 object-cover rounded" alt="">
                                    @else
                                        <div class="w-10 h-10 bg-gray-100 rounded"></div>
                                    @endif
                                </td>
                                <td class="px-4 py-3 font-medium">{{ $product->name }}</td>
                                <td class="px-4 py-3">{{ $product->item_code }}</td>
                                <td class="px-4 py-3">৳{{ number_format($product->unit_price, 2) }}</td>
                                <td class="px-4 py-3 text-right space-x-2">
                                    <a href="{{ route('admin.products.edit', $product) }}"
                                       class="text-blue-600 hover:underline">Edit</a>
                                    <form action="{{ route('admin.products.destroy', $product) }}" method="POST"
                                          class="inline">
                                        @csrf @method('DELETE')
                                        <x-confirm-button message="এই প্রোডাক্টটি মুছে ফেলতে চান?">Delete</x-confirm-button>
                                    </form>
                                </td>
                            </tr>
                        @empty
                            <tr><td colspan="5" class="px-4 py-6 text-center text-gray-400">কোনো প্রোডাক্ট পাওয়া যায়নি।</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>

            <div class="mt-4">{{ $products->links() }}</div>

        </div>
    </div>
</x-admin-layout>
