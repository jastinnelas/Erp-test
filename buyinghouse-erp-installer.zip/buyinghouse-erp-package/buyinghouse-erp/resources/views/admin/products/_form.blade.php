@props(['product' => null])

@if ($product?->image_path)
    <div>
        <img src="{{ asset('storage/' . $product->image_path) }}" class="w-20 h-20 object-cover rounded mb-2" alt="">
    </div>
@endif

<div>
    <label class="block text-sm font-medium text-gray-700 mb-1">Product Image</label>
    <input type="file" name="image" accept="image/*" class="w-full text-sm">
    <p class="text-xs text-gray-400 mt-1">JPG/PNG, সর্বোচ্চ ২MB</p>
</div>

<div>
    <label class="block text-sm font-medium text-gray-700 mb-1">Item Code</label>
    <input type="text" name="item_code" value="{{ old('item_code', $product?->item_code) }}"
           required class="w-full border-gray-300 rounded shadow-sm">
</div>

<div>
    <label class="block text-sm font-medium text-gray-700 mb-1">Name</label>
    <input type="text" name="name" value="{{ old('name', $product?->name) }}"
           required class="w-full border-gray-300 rounded shadow-sm">
</div>

<div class="grid grid-cols-2 gap-4">
    <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Category</label>
        <input type="text" name="category" value="{{ old('category', $product?->category) }}"
               class="w-full border-gray-300 rounded shadow-sm">
    </div>
    <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Color</label>
        <input type="text" name="color" value="{{ old('color', $product?->color) }}"
               class="w-full border-gray-300 rounded shadow-sm">
    </div>
</div>

<div class="grid grid-cols-2 gap-4">
    <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Size</label>
        <input type="text" name="size" value="{{ old('size', $product?->size) }}"
               class="w-full border-gray-300 rounded shadow-sm">
    </div>
    <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Unit Price (৳)</label>
        <input type="number" step="0.01" name="unit_price" value="{{ old('unit_price', $product?->unit_price) }}"
               required class="w-full border-gray-300 rounded shadow-sm">
    </div>
</div>
