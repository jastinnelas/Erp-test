<x-mail::message>
# অর্ডার নিশ্চিত হয়েছে!

**Order No:** {{ $order->order_no }}
**Product:** {{ $order->product->name }}
**Quantity:** {{ $order->quantity }} pcs
**Order Date:** {{ $order->order_date->format('d M, Y') }}

আপনার অর্ডারটি সফলভাবে গ্রহণ করা হয়েছে। শীঘ্রই আমরা প্রোডাকশন শুরু করবো।

<x-mail::button :url="config('app.url')">
আপনার অর্ডার দেখুন
</x-mail::button>

ধন্যবাদ,<br>
{{ config('app.name') }}
</x-mail::message>
