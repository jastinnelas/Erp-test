<x-admin-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Edit Costing — {{ $costing->product->name }} (v{{ $costing->version }})
        </h2>
    </x-slot>

    <div class="py-8">
        <div class="max-w-xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white shadow rounded p-6">

                @if ($errors->any())
                    <div class="mb-4 bg-red-100 text-red-700 px-4 py-3 rounded">
                        <ul class="list-disc list-inside text-sm">
                            @foreach ($errors->all() as $error) <li>{{ $error }}</li> @endforeach
                        </ul>
                    </div>
                @endif

                <form method="POST" action="{{ route('admin.costing.update', $costing) }}" class="space-y-4">
                    @csrf @method('PUT')

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Product</label>
                        <input type="text" disabled value="{{ $costing->product->name }}"
                               class="w-full border-gray-200 rounded shadow-sm bg-gray-50 text-gray-500">
                    </div>

                    <div class="grid grid-cols-2 gap-4">
                        @foreach ([
                            'fabric_cost' => 'Fabric', 'trims_cost' => 'Trims', 'cm_cost' => 'CM (labor)',
                            'washing_cost' => 'Washing', 'printing_cost' => 'Printing', 'packaging_cost' => 'Packaging',
                            'freight_cost' => 'Freight', 'commission_cost' => 'Commission', 'other_cost' => 'Other',
                        ] as $field => $label)
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">{{ $label }} (৳)</label>
                                <input type="number" step="0.01" name="{{ $field }}"
                                       value="{{ old($field, $costing->$field) }}"
                                       min="0" required class="w-full border-gray-300 rounded shadow-sm">
                            </div>
                        @endforeach
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Margin (%)</label>
                        <input type="number" step="0.01" name="margin_percent"
                               value="{{ old('margin_percent', $costing->margin_percent) }}"
                               min="0" required class="w-full border-gray-300 rounded shadow-sm">
                    </div>

                    <div class="flex justify-end gap-2 pt-2">
                        <a href="{{ route('admin.costing.show', $costing) }}"
                           class="px-4 py-2 rounded border text-gray-600 hover:bg-gray-50">Cancel</a>
                        <button type="submit"
                                class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</x-admin-layout>
