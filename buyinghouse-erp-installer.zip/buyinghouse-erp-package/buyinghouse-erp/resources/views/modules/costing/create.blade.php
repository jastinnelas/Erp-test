<x-admin-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">New Costing</h2>
    </x-slot>

    <div class="py-8">
        <div class="max-w-xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white shadow rounded p-6">

                @if ($errors->any())
                    <div class="mb-4 bg-red-100 text-red-700 px-4 py-3 rounded">
                        <ul class="list-disc list-inside text-sm">
                            @foreach ($errors->all() as $error) <li>{{ $error }}</li> @endforeach
                        </ul>
                    </div>
                @endif

                <form method="POST" action="{{ route('admin.costing.store') }}" class="space-y-4">
                    @csrf

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Product</label>
                        <select name="product_id" required class="w-full border-gray-300 rounded shadow-sm">
                            <option value="">-- Select product --</option>
                            @foreach ($products as $product)
                                <option value="{{ $product->id }}" {{ old('product_id') == $product->id ? 'selected' : '' }}>
                                    {{ $product->name }} ({{ $product->item_code }})
                                </option>
                            @endforeach
                        </select>
                        <p class="text-xs text-gray-400 mt-1">নতুন version হিসেবে সেভ হবে (আগের costing পরিবর্তন হবে না)।</p>
                    </div>

                    <div class="grid grid-cols-2 gap-4">
                        @foreach ([
                            'fabric_cost' => 'Fabric', 'trims_cost' => 'Trims', 'cm_cost' => 'CM (labor)',
                            'washing_cost' => 'Washing', 'printing_cost' => 'Printing', 'packaging_cost' => 'Packaging',
                            'freight_cost' => 'Freight', 'commission_cost' => 'Commission', 'other_cost' => 'Other',
                        ] as $field => $label)
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">{{ $label }} (৳)</label>
                                <input type="number" step="0.01" name="{{ $field }}" value="{{ old($field, 0) }}"
                                       min="0" required class="w-full border-gray-300 rounded shadow-sm">
                            </div>
                        @endforeach
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Margin (%)</label>
                        <input type="number" step="0.01" name="margin_percent" value="{{ old('margin_percent', 20) }}"
                               min="0" required class="w-full border-gray-300 rounded shadow-sm">
                        <p class="text-xs text-gray-400 mt-1">Selling price = মোট খরচ + (margin% × মোট খরচ), সাবমিট করার পর দেখা যাবে।</p>
                    </div>

                    <div class="flex justify-end gap-2 pt-2">
                        <a href="{{ route('admin.costing.index') }}"
                           class="px-4 py-2 rounded border text-gray-600 hover:bg-gray-50">Cancel</a>
                        <button type="submit"
                                class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Save draft</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</x-admin-layout>
