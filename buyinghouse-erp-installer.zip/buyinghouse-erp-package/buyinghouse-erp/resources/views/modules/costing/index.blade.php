<x-admin-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">Product Costing</h2>
    </x-slot>

    <div class="py-8">
        <div class="max-w-5xl mx-auto sm:px-6 lg:px-8">

            @if (session('success'))
                <div class="mb-4 bg-green-100 text-green-800 px-4 py-3 rounded">{{ session('success') }}</div>
            @endif

            <div class="flex justify-end mb-4">
                <a href="{{ route('admin.costing.create') }}"
                   class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">+ New costing</a>
            </div>

            <div class="bg-white shadow rounded overflow-x-auto">
                <table class="min-w-full text-sm text-left">
                    <thead class="bg-gray-50 text-gray-600">
                        <tr>
                            <th class="px-4 py-3">Product</th>
                            <th class="px-4 py-3">Version</th>
                            <th class="px-4 py-3">Total Cost</th>
                            <th class="px-4 py-3">Margin</th>
                            <th class="px-4 py-3">Selling Price</th>
                            <th class="px-4 py-3">Status</th>
                            <th class="px-4 py-3"></th>
                        </tr>
                    </thead>
                    <tbody class="divide-y">
                        @forelse ($costings as $costing)
                            <tr>
                                <td class="px-4 py-3 font-medium">{{ $costing->product->name }}</td>
                                <td class="px-4 py-3">v{{ $costing->version }}</td>
                                <td class="px-4 py-3">৳{{ number_format($costing->totalCost(), 2) }}</td>
                                <td class="px-4 py-3">{{ $costing->margin_percent }}%</td>
                                <td class="px-4 py-3 font-medium">৳{{ number_format($costing->selling_price, 2) }}</td>
                                <td class="px-4 py-3">
                                    <span class="px-2 py-1 rounded text-xs
                                        {{ $costing->status === 'approved' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700' }}">
                                        {{ ucfirst($costing->status) }}
                                    </span>
                                </td>
                                <td class="px-4 py-3 text-right">
                                    <a href="{{ route('admin.costing.show', $costing) }}"
                                       class="text-blue-600 hover:underline">View</a>
                                </td>
                            </tr>
                        @empty
                            <tr><td colspan="7" class="px-4 py-6 text-center text-gray-400">No costings yet.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>

            <div class="mt-4">{{ $costings->links() }}</div>

        </div>
    </div>
</x-admin-layout>
