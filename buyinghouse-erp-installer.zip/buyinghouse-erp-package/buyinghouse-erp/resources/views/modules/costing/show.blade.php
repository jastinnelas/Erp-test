<x-admin-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Costing — {{ $costing->product->name }} (v{{ $costing->version }})
        </h2>
    </x-slot>

    <div class="py-8">
        <div class="max-w-xl mx-auto sm:px-6 lg:px-8">

            @if (session('success'))
                <div class="mb-4 bg-green-100 text-green-800 px-4 py-3 rounded">{{ session('success') }}</div>
            @endif

            <div class="bg-white shadow rounded p-6">

                <div class="text-center border-b pb-4 mb-4">
                    <span class="inline-block px-3 py-1 text-xs rounded-full
                        {{ $costing->status === 'approved' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700' }}">
                        {{ ucfirst($costing->status) }}
                    </span>
                    @if ($costing->status === 'approved')
                        <p class="text-xs text-gray-400 mt-1">
                            {{ $costing->approver?->name }} — {{ $costing->approved_at?->format('d M, Y') }}
                        </p>
                    @endif
                </div>

                <dl class="grid grid-cols-2 gap-y-2 text-sm">
                    <dt class="text-gray-500">Fabric</dt><dd class="text-right">৳{{ number_format($costing->fabric_cost, 2) }}</dd>
                    <dt class="text-gray-500">Trims</dt><dd class="text-right">৳{{ number_format($costing->trims_cost, 2) }}</dd>
                    <dt class="text-gray-500">CM (labor)</dt><dd class="text-right">৳{{ number_format($costing->cm_cost, 2) }}</dd>
                    <dt class="text-gray-500">Washing</dt><dd class="text-right">৳{{ number_format($costing->washing_cost, 2) }}</dd>
                    <dt class="text-gray-500">Printing</dt><dd class="text-right">৳{{ number_format($costing->printing_cost, 2) }}</dd>
                    <dt class="text-gray-500">Packaging</dt><dd class="text-right">৳{{ number_format($costing->packaging_cost, 2) }}</dd>
                    <dt class="text-gray-500">Freight</dt><dd class="text-right">৳{{ number_format($costing->freight_cost, 2) }}</dd>
                    <dt class="text-gray-500">Commission</dt><dd class="text-right">৳{{ number_format($costing->commission_cost, 2) }}</dd>
                    <dt class="text-gray-500">Other</dt><dd class="text-right">৳{{ number_format($costing->other_cost, 2) }}</dd>

                    <dt class="text-gray-600 font-medium pt-2 border-t">Total Cost</dt>
                    <dd class="text-right font-medium pt-2 border-t">৳{{ number_format($costing->totalCost(), 2) }}</dd>

                    <dt class="text-gray-500">Margin</dt><dd class="text-right">{{ $costing->margin_percent }}%</dd>

                    <dt class="text-gray-800 font-semibold text-base pt-2 border-t">Selling Price</dt>
                    <dd class="text-right font-semibold text-base pt-2 border-t">৳{{ number_format($costing->selling_price, 2) }}</dd>
                </dl>

                <div class="mt-6 flex justify-between">
                    <a href="{{ route('admin.costing.index') }}" class="text-blue-600 hover:underline text-sm">← All costings</a>
                    <div class="space-x-2">
                        @if ($costing->status !== 'approved')
                            <a href="{{ route('admin.costing.edit', $costing) }}"
                               class="px-3 py-2 border rounded text-sm hover:bg-gray-50">Edit</a>
                            <form action="{{ route('admin.costing.approve', $costing) }}" method="POST" class="inline">
                                @csrf
                                <button type="submit" class="px-4 py-2 bg-green-600 text-white rounded text-sm hover:bg-green-700">
                                    Approve
                                </button>
                            </form>
                        @endif
                    </div>
                </div>

            </div>
        </div>
    </div>
</x-admin-layout>
