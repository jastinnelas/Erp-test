<x-admin-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">CRM — Leads</h2>
    </x-slot>

    <div class="py-8">
        <div class="max-w-5xl mx-auto sm:px-6 lg:px-8">

            @if (session('success'))
                <div class="mb-4 bg-green-100 text-green-800 px-4 py-3 rounded">{{ session('success') }}</div>
            @endif

            <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 mb-4">
                <form method="GET" class="flex gap-2">
                    <select name="status" onchange="this.form.submit()" class="border-gray-300 rounded shadow-sm text-sm">
                        <option value="">সব status</option>
                        @foreach (['new', 'contacted', 'qualified', 'won', 'lost'] as $status)
                            <option value="{{ $status }}" {{ request('status') === $status ? 'selected' : '' }}>
                                {{ ucfirst($status) }}
                            </option>
                        @endforeach
                    </select>
                </form>
                <a href="{{ route('admin.crm.leads.create') }}"
                   class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">+ Add lead</a>
            </div>

            <div class="bg-white shadow rounded overflow-x-auto">
                <table class="min-w-full text-sm text-left">
                    <thead class="bg-gray-50 text-gray-600">
                        <tr>
                            <th class="px-4 py-3">Name</th>
                            <th class="px-4 py-3">Company</th>
                            <th class="px-4 py-3">Source</th>
                            <th class="px-4 py-3">Status</th>
                            <th class="px-4 py-3">Assigned To</th>
                            <th class="px-4 py-3"></th>
                        </tr>
                    </thead>
                    <tbody class="divide-y">
                        @forelse ($leads as $lead)
                            @php
                                $badgeColors = [
                                    'new' => 'bg-gray-100 text-gray-600',
                                    'contacted' => 'bg-blue-100 text-blue-700',
                                    'qualified' => 'bg-purple-100 text-purple-700',
                                    'won' => 'bg-green-100 text-green-700',
                                    'lost' => 'bg-red-100 text-red-700',
                                ];
                            @endphp
                            <tr>
                                <td class="px-4 py-3 font-medium">{{ $lead->name }}</td>
                                <td class="px-4 py-3">{{ $lead->company ?? '—' }}</td>
                                <td class="px-4 py-3">{{ $lead->source ?? '—' }}</td>
                                <td class="px-4 py-3">
                                    <span class="px-2 py-1 rounded text-xs {{ $badgeColors[$lead->status] ?? '' }}">
                                        {{ ucfirst($lead->status) }}
                                    </span>
                                </td>
                                <td class="px-4 py-3">{{ $lead->assignedTo?->name ?? '—' }}</td>
                                <td class="px-4 py-3 text-right">
                                    <a href="{{ route('admin.crm.leads.show', $lead) }}"
                                       class="text-blue-600 hover:underline">View</a>
                                </td>
                            </tr>
                        @empty
                            <tr><td colspan="6" class="px-4 py-6 text-center text-gray-400">No leads yet.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>

            <div class="mt-4">{{ $leads->links() }}</div>

        </div>
    </div>
</x-admin-layout>
