<x-admin-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">Lead — {{ $lead->name }}</h2>
    </x-slot>

    <div class="py-8">
        <div class="max-w-2xl mx-auto sm:px-6 lg:px-8 space-y-6">

            @if (session('success'))
                <div class="bg-green-100 text-green-800 px-4 py-3 rounded">{{ session('success') }}</div>
            @endif

            <div class="bg-white shadow rounded p-6">
                <div class="flex justify-between items-start mb-4">
                    <div>
                        <p class="text-sm text-gray-500">{{ $lead->company ?? 'No company' }}</p>
                        <p class="text-xs text-gray-400">Source: {{ $lead->source ?? '—' }} · Assigned: {{ $lead->assignedTo?->name ?? '—' }}</p>
                    </div>
                    <a href="{{ route('admin.crm.leads.edit', $lead) }}" class="text-sm text-blue-600 hover:underline">Edit</a>
                </div>

                <form method="POST" action="{{ route('admin.crm.leads.update', $lead) }}" class="flex items-center gap-2">
                    @csrf @method('PUT')
                    <input type="hidden" name="name" value="{{ $lead->name }}">
                    <input type="hidden" name="company" value="{{ $lead->company }}">
                    <input type="hidden" name="source" value="{{ $lead->source }}">
                    <label class="text-sm text-gray-600">Status:</label>
                    <select name="status" onchange="this.form.submit()" class="border-gray-300 rounded text-sm">
                        @foreach (['new', 'contacted', 'qualified', 'won', 'lost'] as $status)
                            <option value="{{ $status }}" {{ $lead->status === $status ? 'selected' : '' }}>
                                {{ ucfirst($status) }}
                            </option>
                        @endforeach
                    </select>
                </form>
            </div>

            <div class="bg-white shadow rounded p-6">
                <p class="text-sm font-medium text-gray-600 mb-3">Log new activity</p>
                <form method="POST" action="{{ route('admin.crm.leads.activities.store', $lead) }}" class="space-y-3">
                    @csrf
                    <div class="flex gap-2">
                        <select name="type" required class="border-gray-300 rounded shadow-sm text-sm">
                            @foreach (['call', 'email', 'meeting', 'note'] as $type)
                                <option value="{{ $type }}">{{ ucfirst($type) }}</option>
                            @endforeach
                        </select>
                        <input type="datetime-local" name="due_at" class="border-gray-300 rounded shadow-sm text-sm">
                    </div>
                    <textarea name="notes" rows="2" placeholder="Notes..."
                              class="w-full border-gray-300 rounded shadow-sm text-sm"></textarea>
                    <button type="submit" class="px-3 py-1.5 bg-gray-800 text-white rounded text-sm hover:bg-gray-900">
                        Log activity
                    </button>
                </form>
            </div>

            <div class="bg-white shadow rounded p-6">
                <p class="text-sm font-medium text-gray-600 mb-3">Activity timeline</p>
                <div class="space-y-3">
                    @forelse ($lead->activities()->latest()->get() as $activity)
                        <div class="border-l-2 border-gray-200 pl-3 text-sm">
                            <p class="font-medium">{{ ucfirst($activity->type) }} — {{ $activity->creator->name }}</p>
                            <p class="text-gray-500">{{ $activity->notes }}</p>
                            <p class="text-xs text-gray-400">{{ $activity->created_at->format('d M, Y h:i A') }}</p>
                        </div>
                    @empty
                        <p class="text-sm text-gray-400">কোনো activity লগ হয়নি।</p>
                    @endforelse
                </div>
            </div>

        </div>
    </div>
</x-admin-layout>
