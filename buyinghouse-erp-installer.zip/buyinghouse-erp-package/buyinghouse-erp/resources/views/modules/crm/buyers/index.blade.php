<x-admin-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">CRM — Buyer Profiles</h2>
    </x-slot>

    <div class="py-8">
        <div class="max-w-5xl mx-auto sm:px-6 lg:px-8">

            @if (session('success'))
                <div class="mb-4 bg-green-100 text-green-800 px-4 py-3 rounded">{{ session('success') }}</div>
            @endif

            <div class="bg-white shadow rounded overflow-x-auto">
                <table class="min-w-full text-sm text-left">
                    <thead class="bg-gray-50 text-gray-600">
                        <tr>
                            <th class="px-4 py-3">Customer</th>
                            <th class="px-4 py-3">Company</th>
                            <th class="px-4 py-3">Country</th>
                            <th class="px-4 py-3">Currency</th>
                            <th class="px-4 py-3">Payment Terms</th>
                            <th class="px-4 py-3"></th>
                        </tr>
                    </thead>
                    <tbody class="divide-y">
                        @forelse ($buyers as $buyer)
                            <tr>
                                <td class="px-4 py-3 font-medium">{{ $buyer->name }}</td>
                                <td class="px-4 py-3">{{ $buyer->buyerProfile?->company_name ?? '—' }}</td>
                                <td class="px-4 py-3">{{ $buyer->buyerProfile?->country ?? '—' }}</td>
                                <td class="px-4 py-3">{{ $buyer->buyerProfile?->currency ?? 'BDT' }}</td>
                                <td class="px-4 py-3">{{ $buyer->buyerProfile?->payment_terms ?? '—' }}</td>
                                <td class="px-4 py-3 text-right">
                                    <a href="{{ route('admin.crm.buyers.edit', $buyer) }}"
                                       class="text-blue-600 hover:underline">
                                        {{ $buyer->buyerProfile ? 'Edit' : 'Add profile' }}
                                    </a>
                                </td>
                            </tr>
                        @empty
                            <tr><td colspan="6" class="px-4 py-6 text-center text-gray-400">No customers yet.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>

            <div class="mt-4">{{ $buyers->links() }}</div>

        </div>
    </div>
</x-admin-layout>
