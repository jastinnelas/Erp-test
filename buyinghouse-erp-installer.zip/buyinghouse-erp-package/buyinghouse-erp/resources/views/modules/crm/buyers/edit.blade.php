<x-admin-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">Buyer Profile — {{ $user->name }}</h2>
    </x-slot>

    <div class="py-8">
        <div class="max-w-xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white shadow rounded p-6">

                @if ($errors->any())
                    <div class="mb-4 bg-red-100 text-red-700 px-4 py-3 rounded">
                        <ul class="list-disc list-inside text-sm">
                            @foreach ($errors->all() as $error) <li>{{ $error }}</li> @endforeach
                        </ul>
                    </div>
                @endif

                <form method="POST" action="{{ route('admin.crm.buyers.update', $user) }}" class="space-y-4">
                    @csrf @method('PUT')

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Company Name</label>
                        <input type="text" name="company_name" value="{{ old('company_name', $profile?->company_name) }}"
                               required class="w-full border-gray-300 rounded shadow-sm">
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Country</label>
                        <input type="text" name="country" value="{{ old('country', $profile?->country) }}"
                               class="w-full border-gray-300 rounded shadow-sm">
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Currency</label>
                        <select name="currency" required class="w-full border-gray-300 rounded shadow-sm">
                            @foreach (['BDT', 'USD', 'EUR', 'GBP'] as $currency)
                                <option value="{{ $currency }}"
                                    {{ old('currency', $profile?->currency ?? 'BDT') === $currency ? 'selected' : '' }}>
                                    {{ $currency }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Payment Terms</label>
                        <input type="text" name="payment_terms" value="{{ old('payment_terms', $profile?->payment_terms) }}"
                               placeholder="যেমন: 30% advance, 70% on shipment"
                               class="w-full border-gray-300 rounded shadow-sm">
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Shipping Terms</label>
                        <input type="text" name="shipping_terms" value="{{ old('shipping_terms', $profile?->shipping_terms) }}"
                               placeholder="যেমন: FOB Chattogram"
                               class="w-full border-gray-300 rounded shadow-sm">
                    </div>

                    <div class="flex justify-end gap-2 pt-2">
                        <a href="{{ route('admin.crm.buyers.index') }}"
                           class="px-4 py-2 rounded border text-gray-600 hover:bg-gray-50">Cancel</a>
                        <button type="submit"
                                class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Save profile</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</x-admin-layout>
