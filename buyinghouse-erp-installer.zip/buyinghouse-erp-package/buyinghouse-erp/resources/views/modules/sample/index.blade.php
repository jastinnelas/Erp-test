<x-admin-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">Sample Development</h2>
    </x-slot>

    <div class="py-8">
        <div class="max-w-5xl mx-auto sm:px-6 lg:px-8">

            @if (session('success'))
                <div class="mb-4 bg-green-100 text-green-800 px-4 py-3 rounded">{{ session('success') }}</div>
            @endif

            <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 mb-4">
                <form method="GET" class="flex gap-2">
                    <select name="stage" onchange="this.form.submit()" class="border-gray-300 rounded shadow-sm text-sm">
                        <option value="">সব stage</option>
                        @foreach ($stages as $stage)
                            <option value="{{ $stage }}" {{ request('stage') === $stage ? 'selected' : '' }}>
                                {{ str_replace('_', ' ', ucfirst($stage)) }}
                            </option>
                        @endforeach
                    </select>
                </form>
                <a href="{{ route('admin.sample.create') }}"
                   class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">+ Request sample</a>
            </div>

            <div class="bg-white shadow rounded overflow-x-auto">
                <table class="min-w-full text-sm text-left">
                    <thead class="bg-gray-50 text-gray-600">
                        <tr>
                            <th class="px-4 py-3">#</th>
                            <th class="px-4 py-3">Product</th>
                            <th class="px-4 py-3">Order</th>
                            <th class="px-4 py-3">Stage</th>
                            <th class="px-4 py-3">Requested By</th>
                            <th class="px-4 py-3"></th>
                        </tr>
                    </thead>
                    <tbody class="divide-y">
                        @php
                            $badgeColors = [
                                'requested' => 'bg-gray-100 text-gray-600',
                                'proto' => 'bg-blue-100 text-blue-700',
                                'fit' => 'bg-indigo-100 text-indigo-700',
                                'size_set' => 'bg-purple-100 text-purple-700',
                                'pp_sample' => 'bg-orange-100 text-orange-700',
                                'sent' => 'bg-cyan-100 text-cyan-700',
                                'approved' => 'bg-green-100 text-green-700',
                                'rejected' => 'bg-red-100 text-red-700',
                            ];
                        @endphp
                        @forelse ($samples as $sample)
                            <tr>
                                <td class="px-4 py-3 font-medium">#{{ $sample->id }}</td>
                                <td class="px-4 py-3">{{ $sample->product->name ?? '—' }}</td>
                                <td class="px-4 py-3">{{ $sample->order->order_no ?? '—' }}</td>
                                <td class="px-4 py-3">
                                    <span class="px-2 py-1 rounded text-xs {{ $badgeColors[$sample->stage] ?? '' }}">
                                        {{ str_replace('_', ' ', ucfirst($sample->stage)) }}
                                    </span>
                                </td>
                                <td class="px-4 py-3">{{ $sample->requestedBy->name }}</td>
                                <td class="px-4 py-3 text-right">
                                    <a href="{{ route('admin.sample.show', $sample) }}"
                                       class="text-blue-600 hover:underline">View</a>
                                </td>
                            </tr>
                        @empty
                            <tr><td colspan="6" class="px-4 py-6 text-center text-gray-400">No samples yet.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>

            <div class="mt-4">{{ $samples->links() }}</div>

        </div>
    </div>
</x-admin-layout>
