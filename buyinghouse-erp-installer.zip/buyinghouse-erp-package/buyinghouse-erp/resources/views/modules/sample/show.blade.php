<x-admin-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">Sample #{{ $sample->id }}</h2>
    </x-slot>

    <div class="py-8">
        <div class="max-w-xl mx-auto sm:px-6 lg:px-8">

            @if (session('success'))
                <div class="mb-4 bg-green-100 text-green-800 px-4 py-3 rounded">{{ session('success') }}</div>
            @endif

            <div class="bg-white shadow rounded p-6">

                <dl class="grid grid-cols-2 gap-y-3 text-sm mb-6">
                    <dt class="text-gray-500">Product</dt>
                    <dd class="text-right">{{ $sample->product->name ?? '—' }}</dd>

                    <dt class="text-gray-500">Order</dt>
                    <dd class="text-right">{{ $sample->order->order_no ?? '—' }}</dd>

                    <dt class="text-gray-500">Requested By</dt>
                    <dd class="text-right">{{ $sample->requestedBy->name }}</dd>

                    <dt class="text-gray-500">Sent At</dt>
                    <dd class="text-right">{{ $sample->sent_at?->format('d M, Y') ?? '—' }}</dd>
                </dl>

                <form method="POST" action="{{ route('admin.sample.update-stage', $sample) }}" class="space-y-3 border-t pt-4">
                    @csrf @method('PUT')

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Stage</label>
                        <select name="stage" required class="w-full border-gray-300 rounded shadow-sm">
                            @foreach ($stages as $stage)
                                <option value="{{ $stage }}" {{ $sample->stage === $stage ? 'selected' : '' }}>
                                    {{ str_replace('_', ' ', ucfirst($stage)) }}
                                </option>
                            @endforeach
                        </select>
                        <p class="text-xs text-gray-400 mt-1">
                            Flow: requested → proto → fit → size_set → pp_sample → sent → approved/rejected
                        </p>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Feedback</label>
                        <textarea name="feedback" rows="3"
                                  class="w-full border-gray-300 rounded shadow-sm">{{ old('feedback', $sample->feedback) }}</textarea>
                    </div>

                    <div class="flex justify-end gap-2 pt-2">
                        <a href="{{ route('admin.sample.index') }}"
                           class="px-4 py-2 rounded border text-gray-600 hover:bg-gray-50">Back</a>
                        <button type="submit"
                                class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Update stage</button>
                    </div>
                </form>

            </div>
        </div>
    </div>
</x-admin-layout>
