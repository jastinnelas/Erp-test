<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class EnsureTwoFactorVerified
{
    public function handle(Request $request, Closure $next)
    {
        $user = $request->user();

        if (
            $user
            && $user->two_factor_enabled
            && ! session('2fa_verified')
            && ! $request->routeIs('two-factor.*', 'logout')
        ) {
            return redirect()->route('two-factor.challenge');
        }

        return $next($request);
    }
}
