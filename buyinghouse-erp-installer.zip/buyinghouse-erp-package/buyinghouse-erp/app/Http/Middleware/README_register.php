<?php

// এই ফাইলটা চালানোর জন্য না — শুধু নির্দেশনা।
// আপনার প্রজেক্টের bootstrap/app.php ফাইলে withMiddleware() অংশে
// নিচের লাইনটা যোগ করুন:

/*
use App\Http\Middleware\EnsureUserHasRole;

->withMiddleware(function (Middleware $middleware) {
    $middleware->alias([
        'role' => EnsureUserHasRole::class,
    ]);
})
*/

// এরপর যেকোনো route এ ->middleware('role:admin') লিখে
// শুধু admin role এর ইউজারদের জন্য সীমাবদ্ধ করতে পারবেন।
