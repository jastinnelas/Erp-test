<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class EnsureOtpVerified
{
    public function handle(Request $request, Closure $next)
    {
        if (
            config('otp.enabled')
            && $request->user()
            && ! $request->user()->hasVerifiedEmail()
            && ! $request->routeIs('otp.*', 'logout')
        ) {
            return redirect()->route('otp.show');
        }

        return $next($request);
    }
}
