<?php

namespace App\Http\Controllers;

use App\Models\AuditLog;
use App\Models\Order;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class OrderController extends Controller
{
    // Buyer-facing: list only the logged-in user's own orders
    public function index(Request $request)
    {
        $orders = Order::with('product')
            ->where('user_id', $request->user()->id)
            ->when($request->search, function ($q, $search) {
                $q->where(function ($q2) use ($search) {
                    $q2->where('order_no', 'like', "%{$search}%")
                       ->orWhereHas('product', fn ($q3) => $q3->where('name', 'like', "%{$search}%"));
                });
            })
            ->when($request->status, fn ($q, $status) => $q->where('status', $status))
            ->latest()
            ->paginate(10)
            ->withQueryString();

        return view('orders.index', compact('orders'));
    }

    public function create(Request $request)
    {
        $products = Product::orderBy('name')->get();
        $selectedProductId = $request->query('product_id');

        return view('orders.create', compact('products', 'selectedProductId'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'product_id' => ['required', 'exists:products,id'],
            'quantity'   => ['required', 'integer', 'min:100'], // bulk-order rule
            'order_date' => ['required', 'date'],
            'attachment' => ['nullable', 'file', 'mimes:pdf,jpg,jpeg,png', 'max:4096'],
        ], [
            'quantity.min' => 'Minimum order quantity is 100 pieces.',
        ]);

        $attachmentPath = null;
        if ($request->hasFile('attachment')) {
            $attachmentPath = $request->file('attachment')->store('order-attachments', 'public');
        }

        $order = Order::create([
            'order_no'   => 'ORD-' . now()->format('Y') . '-' . str_pad((Order::max('id') + 1), 5, '0', STR_PAD_LEFT),
            'user_id'    => $request->user()->id,
            'product_id' => $validated['product_id'],
            'quantity'   => $validated['quantity'],
            'order_date' => $validated['order_date'],
            'status'     => 'pending',
            'attachment_path' => $attachmentPath,
        ]);

        AuditLog::record('created', $order, "Order {$order->order_no} placed ({$order->quantity} pcs)");
        \App\Jobs\SendOrderConfirmationJob::dispatch($order);

        return redirect()
            ->route('orders.show', $order)
            ->with('success', 'Order placed. Your confirmation slip is ready below.');
    }

    public function show(Order $order)
    {
        $this->authorizeOwner($order);

        $order->load('product', 'productionEntry', 'deliveryEntry', 'invoice');

        return view('orders.show', compact('order'));
    }

    public function edit(Order $order)
    {
        $this->authorizeOwner($order);
        $products = Product::orderBy('name')->get();

        return view('orders.edit', compact('order', 'products'));
    }

    public function update(Request $request, Order $order)
    {
        $this->authorizeOwner($order);

        $validated = $request->validate([
            'quantity' => ['required', 'integer', 'min:100'],
        ], [
            'quantity.min' => 'Minimum order quantity is 100 pieces.',
        ]);

        $old = $order->only('quantity');
        $order->update($validated);
        AuditLog::record('updated', $order, "Order {$order->order_no} quantity changed", $old, $validated);

        return redirect()->route('orders.show', $order)->with('success', 'Order updated.');
    }

    public function destroy(Order $order)
    {
        $this->authorizeOwner($order);
        $order->delete();
        AuditLog::record('deleted', $order, "Order {$order->order_no} cancelled");

        return redirect()->route('orders.index')->with('success', 'Order cancelled.');
    }

    private function authorizeOwner(Order $order): void
    {
        abort_unless($order->user_id === request()->user()->id, 403);
    }
}
