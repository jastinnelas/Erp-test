<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Product;
use Illuminate\Http\Request;

class ProductApiController extends Controller
{
    /**
     * GET /api/products — সব প্রোডাক্ট (public, লগইন লাগে না)
     */
    public function index(Request $request)
    {
        $products = Product::query()
            ->when($request->search, fn ($q, $s) => $q->where('name', 'like', "%{$s}%"))
            ->paginate(15);

        return response()->json($products);
    }

    /**
     * GET /api/products/{product}
     */
    public function show(Product $product)
    {
        return response()->json($product);
    }
}
