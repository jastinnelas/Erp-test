<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Models\Order;
use Illuminate\Http\Request;

class OrderApiController extends Controller
{
    /**
     * GET /api/orders — লগইন করা ইউজারের নিজের অর্ডার তালিকা
     */
    public function index(Request $request)
    {
        $orders = Order::with('product')
            ->where('user_id', $request->user()->id)
            ->latest()
            ->paginate(15);

        return response()->json($orders);
    }

    /**
     * GET /api/orders/{order} — একটা নির্দিষ্ট অর্ডারের বিস্তারিত
     */
    public function show(Request $request, Order $order)
    {
        abort_unless($order->user_id === $request->user()->id, 403);

        $order->load('product', 'productionEntry', 'deliveryEntry', 'invoice');

        return response()->json($order);
    }

    /**
     * POST /api/orders — নতুন অর্ডার তৈরি (মোবাইল অ্যাপ থেকে)
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'product_id' => ['required', 'exists:products,id'],
            'quantity'   => ['required', 'integer', 'min:100'],
            'order_date' => ['required', 'date'],
        ], [
            'quantity.min' => 'Minimum order quantity is 100 pieces.',
        ]);

        $order = Order::create([
            'order_no'   => 'ORD-' . now()->format('Y') . '-' . str_pad((Order::max('id') + 1), 5, '0', STR_PAD_LEFT),
            'user_id'    => $request->user()->id,
            'product_id' => $validated['product_id'],
            'quantity'   => $validated['quantity'],
            'order_date' => $validated['order_date'],
            'status'     => 'pending',
        ]);

        AuditLog::record('created', $order, "Order {$order->order_no} placed via API ({$order->quantity} pcs)");
        \App\Jobs\SendOrderConfirmationJob::dispatch($order);

        return response()->json($order->load('product'), 201);
    }
}
