<?php

namespace App\Http\Controllers;

use App\Models\Message;
use App\Models\User;
use Illuminate\Http\Request;

class MessageController extends Controller
{
    /**
     * Inbox — thread list. Customers see only the admin thread;
     * Admins see one thread per customer.
     */
    public function index(Request $request)
    {
        $user = $request->user();

        if ($user->role === 'admin') {
            $threads = User::where('role', 'customer')
                ->withCount(['receivedMessages as unread_count' => function ($q) use ($user) {
                    $q->where('sender_id', '!=', $user->id)->where('is_read', false);
                }])
                ->orderBy('name')
                ->get();

            return view('messages.admin-index', compact('threads'));
        }

        // customer: শুধু admin এর সাথে থ্রেড, সরাসরি সেখানে পাঠিয়ে দেওয়া হলো
        $admin = User::where('role', 'admin')->first();

        return redirect()->route('messages.show', $admin);
    }

    /**
     * একটা নির্দিষ্ট ইউজারের সাথে কথোপকথন দেখানো + নতুন মেসেজ read করা
     */
    public function show(Request $request, User $user)
    {
        $me = $request->user();

        $conversation = Message::where(function ($q) use ($me, $user) {
                $q->where('sender_id', $me->id)->where('receiver_id', $user->id);
            })
            ->orWhere(function ($q) use ($me, $user) {
                $q->where('sender_id', $user->id)->where('receiver_id', $me->id);
            })
            ->orderBy('created_at')
            ->get();

        Message::where('sender_id', $user->id)
            ->where('receiver_id', $me->id)
            ->where('is_read', false)
            ->update(['is_read' => true]);

        return view('messages.show', [
            'otherUser' => $user,
            'conversation' => $conversation,
        ]);
    }

    public function store(Request $request, User $user)
    {
        $validated = $request->validate([
            'content' => ['required', 'string', 'max:2000'],
        ]);

        Message::create([
            'sender_id' => $request->user()->id,
            'receiver_id' => $user->id,
            'content' => $validated['content'],
        ]);

        return redirect()->route('messages.show', $user);
    }
}
