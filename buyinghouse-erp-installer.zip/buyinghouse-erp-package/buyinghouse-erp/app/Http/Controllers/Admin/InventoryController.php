<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Inventory;
use App\Models\Product;
use App\Models\Supplier;
use Illuminate\Http\Request;

class InventoryController extends Controller
{
    private const LOW_STOCK_THRESHOLD = 100;

    public function index()
    {
        $inventory = Inventory::with('product', 'supplier')->latest()->paginate(10);

        return view('admin.inventory.index', compact('inventory'));
    }

    public function create()
    {
        $products = Product::orderBy('name')->get();
        $suppliers = Supplier::orderBy('name')->get();

        return view('admin.inventory.create', compact('products', 'suppliers'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'product_id'  => ['required', 'exists:products,id'],
            'supplier_id' => ['nullable', 'exists:suppliers,id'],
            'stock_qty'   => ['required', 'integer', 'min:0'],
        ]);

        $validated['status'] = $this->resolveStatus($validated['stock_qty']);

        Inventory::create($validated);

        return redirect()->route('admin.inventory.index')->with('success', 'Stock entry added.');
    }

    public function edit(Inventory $inventory)
    {
        $products = Product::orderBy('name')->get();
        $suppliers = Supplier::orderBy('name')->get();

        return view('admin.inventory.edit', compact('inventory', 'products', 'suppliers'));
    }

    public function update(Request $request, Inventory $inventory)
    {
        $validated = $request->validate([
            'supplier_id' => ['nullable', 'exists:suppliers,id'],
            'stock_qty'   => ['required', 'integer', 'min:0'],
        ]);

        $validated['status'] = $this->resolveStatus($validated['stock_qty']);

        $inventory->update($validated);

        return redirect()->route('admin.inventory.index')->with('success', 'Stock updated.');
    }

    public function destroy(Inventory $inventory)
    {
        $inventory->delete();

        return redirect()->route('admin.inventory.index')->with('success', 'Stock entry removed.');
    }

    private function resolveStatus(int $qty): string
    {
        return match (true) {
            $qty === 0 => 'out_of_stock',
            $qty < self::LOW_STOCK_THRESHOLD => 'low_stock',
            default => 'in_stock',
        };
    }
}
