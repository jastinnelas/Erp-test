<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\ProductionEntry;
use App\Models\Supplier;
use Illuminate\Http\Request;

class ProductionEntryController extends Controller
{
    public function index()
    {
        $entries = ProductionEntry::with('order.product', 'order.user', 'supplier')
            ->latest()
            ->paginate(10);

        return view('admin.production.index', compact('entries'));
    }

    public function create(Request $request)
    {
        $orders = Order::whereDoesntHave('productionEntry')->with('product', 'user')->get();
        $suppliers = Supplier::orderBy('name')->get();
        $selectedOrderId = $request->query('order_id');

        return view('admin.production.create', compact('orders', 'suppliers', 'selectedOrderId'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'order_id'    => ['required', 'exists:orders,id', 'unique:production_entries,order_id'],
            'supplier_id' => ['nullable', 'exists:suppliers,id'],
            'stage'       => ['required', 'in:queued,in_production,quality_check,completed,delayed'],
            'start_time'  => ['nullable', 'date'],
            'finish_time' => ['nullable', 'date', 'after_or_equal:start_time'],
            'remarks'     => ['nullable', 'string', 'max:1000'],
        ]);

        $entry = ProductionEntry::create($validated);

        // Order-এর overall status টাও সিঙ্ক করে দেওয়া হলো
        if ($validated['stage'] === 'completed') {
            $entry->order->update(['status' => 'in_production']);
        }

        return redirect()
            ->route('admin.production.index')
            ->with('success', 'Production entry created.');
    }

    public function edit(ProductionEntry $production)
    {
        $suppliers = Supplier::orderBy('name')->get();
        $production->load('order.product', 'order.user');

        return view('admin.production.edit', [
            'entry' => $production,
            'suppliers' => $suppliers,
        ]);
    }

    public function update(Request $request, ProductionEntry $production)
    {
        $validated = $request->validate([
            'supplier_id' => ['nullable', 'exists:suppliers,id'],
            'stage'       => ['required', 'in:queued,in_production,quality_check,completed,delayed'],
            'start_time'  => ['nullable', 'date'],
            'finish_time' => ['nullable', 'date', 'after_or_equal:start_time'],
            'remarks'     => ['nullable', 'string', 'max:1000'],
        ]);

        $oldStage = $production->stage;
        $production->update($validated);

        if ($oldStage !== $validated['stage']) {
            \App\Models\AuditLog::record(
                'status_changed',
                $production,
                "Production for order {$production->order->order_no} changed from {$oldStage} to {$validated['stage']}",
                ['stage' => $oldStage],
                ['stage' => $validated['stage']]
            );
        }

        return redirect()
            ->route('admin.production.index')
            ->with('success', 'Production entry updated.');
    }

    public function destroy(ProductionEntry $production)
    {
        $production->delete();

        return redirect()
            ->route('admin.production.index')
            ->with('success', 'Production entry removed.');
    }
}
