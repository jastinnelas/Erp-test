<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\DeliveryEntry;
use App\Models\Invoice;
use App\Models\Order;
use App\Models\ProductionEntry;

class DashboardController extends Controller
{
    public function index()
    {
        $stats = [
            'total_orders'      => Order::count(),
            'in_production'     => ProductionEntry::where('stage', 'in_production')->count(),
            'delivered'         => DeliveryEntry::where('status', 'delivered')->count(),
            'pending_invoices'  => Invoice::where('payment_status', 'pending')->count(),
        ];

        $recentOrders = Order::with('user', 'product')->latest()->limit(8)->get();

        // গত ৬ মাসের অর্ডার ট্রেন্ড (Analytics chart এর জন্য)
        $monthlyTrend = collect(range(5, 0))->map(function ($monthsAgo) {
            $date = now()->subMonths($monthsAgo);
            return [
                'label' => $date->format('M Y'),
                'count' => Order::whereYear('order_date', $date->year)
                    ->whereMonth('order_date', $date->month)
                    ->count(),
            ];
        });

        return view('admin.dashboard', compact('stats', 'recentOrders', 'monthlyTrend'));
    }
}
