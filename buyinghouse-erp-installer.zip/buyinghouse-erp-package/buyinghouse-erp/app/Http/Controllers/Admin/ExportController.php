<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Invoice;
use App\Models\Order;
use Symfony\Component\HttpFoundation\StreamedResponse;

class ExportController extends Controller
{
    public function orders(): StreamedResponse
    {
        return $this->csvResponse('orders.csv', function ($handle) {
            fputcsv($handle, ['Order No', 'Customer', 'Product', 'Quantity', 'Order Date', 'Status']);

            Order::with('user', 'product')->chunk(200, function ($orders) use ($handle) {
                foreach ($orders as $order) {
                    fputcsv($handle, [
                        $order->order_no,
                        $order->user->name,
                        $order->product->name,
                        $order->quantity,
                        $order->order_date->format('Y-m-d'),
                        $order->status,
                    ]);
                }
            });
        });
    }

    public function invoices(): StreamedResponse
    {
        return $this->csvResponse('invoices.csv', function ($handle) {
            fputcsv($handle, ['Invoice No', 'Order No', 'Customer', 'Amount', 'Payment Status', 'Issue Date']);

            Invoice::with('order.user')->chunk(200, function ($invoices) use ($handle) {
                foreach ($invoices as $invoice) {
                    fputcsv($handle, [
                        $invoice->invoice_no,
                        $invoice->order->order_no,
                        $invoice->order->user->name,
                        $invoice->amount,
                        $invoice->payment_status,
                        $invoice->issue_date->format('Y-m-d'),
                    ]);
                }
            });
        });
    }

    private function csvResponse(string $filename, callable $writer): StreamedResponse
    {
        $response = new StreamedResponse(function () use ($writer) {
            $handle = fopen('php://output', 'w');
            fwrite($handle, "\xEF\xBB\xBF"); // UTF-8 BOM যাতে Bangla টেক্সট Excel এ ঠিক দেখায়
            $writer($handle);
            fclose($handle);
        });

        $response->headers->set('Content-Type', 'text/csv; charset=UTF-8');
        $response->headers->set('Content-Disposition', "attachment; filename=\"{$filename}\"");

        return $response;
    }
}
