<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Invoice;
use App\Models\Order;
use Illuminate\Http\Request;

class InvoiceController extends Controller
{
    public function index()
    {
        $invoices = Invoice::with('order.product', 'order.user')
            ->latest()
            ->paginate(10);

        return view('admin.invoices.index', compact('invoices'));
    }

    public function create(Request $request)
    {
        // শুধু যেসব order ডেলিভার হয়েছে কিন্তু ইনভয়েস এখনো নেই
        $orders = Order::whereHas('deliveryEntry', fn ($q) => $q->where('status', 'delivered'))
            ->whereDoesntHave('invoice')
            ->with('product', 'user')
            ->get();

        $selectedOrderId = $request->query('order_id');

        return view('admin.invoices.create', compact('orders', 'selectedOrderId'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'order_id'       => ['required', 'exists:orders,id', 'unique:invoices,order_id'],
            'amount'         => ['required', 'numeric', 'min:0'],
            'payment_status' => ['required', 'in:pending,paid,overdue'],
            'issue_date'     => ['required', 'date'],
            'due_date'       => ['nullable', 'date', 'after_or_equal:issue_date'],
            'remarks'        => ['nullable', 'string', 'max:1000'],
        ]);

        $validated['invoice_no'] = 'INV-' . now()->format('Y') . '-' .
            str_pad((Invoice::max('id') + 1), 4, '0', STR_PAD_LEFT);

        $invoice = Invoice::create($validated);

        return redirect()
            ->route('admin.invoices.show', $invoice)
            ->with('success', 'Invoice generated.');
    }

    public function show(Invoice $invoice)
    {
        $invoice->load('order.product', 'order.user', 'order.deliveryEntry');

        return view('admin.invoices.show', compact('invoice'));
    }

    public function edit(Invoice $invoice)
    {
        $invoice->load('order.product', 'order.user');

        return view('admin.invoices.edit', compact('invoice'));
    }

    public function update(Request $request, Invoice $invoice)
    {
        $validated = $request->validate([
            'amount'         => ['required', 'numeric', 'min:0'],
            'payment_status' => ['required', 'in:pending,paid,overdue'],
            'due_date'       => ['nullable', 'date', 'after_or_equal:issue_date'],
            'remarks'        => ['nullable', 'string', 'max:1000'],
        ]);

        $oldStatus = $invoice->payment_status;
        $invoice->update($validated);

        if ($oldStatus !== $validated['payment_status']) {
            \App\Models\AuditLog::record(
                'status_changed',
                $invoice,
                "Invoice {$invoice->invoice_no} payment status changed from {$oldStatus} to {$validated['payment_status']}",
                ['payment_status' => $oldStatus],
                ['payment_status' => $validated['payment_status']]
            );
        }

        return redirect()
            ->route('admin.invoices.show', $invoice)
            ->with('success', 'Invoice updated.');
    }

    public function destroy(Invoice $invoice)
    {
        $invoice->delete();

        return redirect()
            ->route('admin.invoices.index')
            ->with('success', 'Invoice removed.');
    }

    public function downloadPdf(Invoice $invoice)
    {
        $invoice->load('order.product', 'order.user');

        $pdf = \Barryvdh\DomPDF\Facade\Pdf::loadView('admin.invoices.pdf', compact('invoice'));

        return $pdf->download("{$invoice->invoice_no}.pdf");
    }
}
