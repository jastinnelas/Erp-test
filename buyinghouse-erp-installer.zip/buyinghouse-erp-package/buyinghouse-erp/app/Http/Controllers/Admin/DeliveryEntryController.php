<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\DeliveryEntry;
use App\Models\Order;
use Illuminate\Http\Request;

class DeliveryEntryController extends Controller
{
    public function index()
    {
        $entries = DeliveryEntry::with('order.product', 'order.user')
            ->latest()
            ->paginate(10);

        return view('admin.delivery.index', compact('entries'));
    }

    public function create(Request $request)
    {
        // শুধু যেসব order-এর production "completed" স্টেজে আছে এবং delivery entry এখনো নেই
        $orders = Order::whereHas('productionEntry', fn ($q) => $q->where('stage', 'completed'))
            ->whereDoesntHave('deliveryEntry')
            ->with('product', 'user')
            ->get();

        $selectedOrderId = $request->query('order_id');

        return view('admin.delivery.create', compact('orders', 'selectedOrderId'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'order_id'         => ['required', 'exists:orders,id', 'unique:delivery_entries,order_id'],
            'courier'          => ['nullable', 'string', 'max:255'],
            'tracking_no'      => ['nullable', 'string', 'max:255'],
            'delivery_address' => ['nullable', 'string', 'max:500'],
            'status'           => ['required', 'in:pending_dispatch,in_transit,out_for_delivery,delivered,delayed'],
        ]);

        $entry = DeliveryEntry::create($validated);

        if ($validated['status'] === 'delivered') {
            $entry->order->update(['status' => 'delivered']);
        }

        return redirect()
            ->route('admin.delivery.index')
            ->with('success', 'Delivery entry created.');
    }

    public function edit(DeliveryEntry $delivery)
    {
        $delivery->load('order.product', 'order.user');

        return view('admin.delivery.edit', ['entry' => $delivery]);
    }

    public function update(Request $request, DeliveryEntry $delivery)
    {
        $validated = $request->validate([
            'courier'          => ['nullable', 'string', 'max:255'],
            'tracking_no'      => ['nullable', 'string', 'max:255'],
            'delivery_address' => ['nullable', 'string', 'max:500'],
            'status'           => ['required', 'in:pending_dispatch,in_transit,out_for_delivery,delivered,delayed'],
        ]);

        $oldStatus = $delivery->status;
        $delivery->update($validated);

        if ($oldStatus !== $validated['status']) {
            \App\Models\AuditLog::record(
                'status_changed',
                $delivery,
                "Delivery for order {$delivery->order->order_no} changed from {$oldStatus} to {$validated['status']}",
                ['status' => $oldStatus],
                ['status' => $validated['status']]
            );
        }

        if ($validated['status'] === 'delivered') {
            $delivery->order->update(['status' => 'delivered']);
        }

        return redirect()
            ->route('admin.delivery.index')
            ->with('success', 'Delivery entry updated.');
    }

    public function destroy(DeliveryEntry $delivery)
    {
        $delivery->delete();

        return redirect()
            ->route('admin.delivery.index')
            ->with('success', 'Delivery entry removed.');
    }
}
