<?php

namespace App\Http\Controllers\Site;

use App\Http\Controllers\Controller;
use App\Models\Order;
use Illuminate\Http\Request;

class TrackController extends Controller
{
    public function show(Request $request)
    {
        $order = null;
        $notFound = false;

        if ($request->filled('order_no')) {
            $query = Order::with('product', 'productionEntry', 'deliveryEntry', 'invoice');

            // Login করা থাকলে শুধু নিজের অর্ডার দেখানো হয় (অন্যের অর্ডার নম্বর দিয়ে
            // খুঁজলে info leak হবে না)। Guest হলে track করতে লগইন করতে বলা হয়।
            if ($request->user()) {
                $query->where('user_id', $request->user()->id);
            } else {
                return redirect()->route('login')->with('error', 'অর্ডার ট্র্যাক করতে আগে লগইন করুন।');
            }

            $order = $query->where('order_no', $request->order_no)->first();
            $notFound = ! $order;
        }

        return view('site.track', compact('order', 'notFound'));
    }
}
