<?php

namespace App\Http\Controllers\Site;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Product;

class HomeController extends Controller
{
    public function index()
    {
        $stats = [
            'buyers'   => \App\Models\User::where('role', 'customer')->count(),
            'pieces'   => (int) Order::sum('quantity'),
            'products' => Product::count(),
        ];

        // হোমপেজের "live order" প্রিভিউ — সাম্প্রতিক একটা বাস্তব অর্ডার দেখানো হয় (থাকলে)
        $sampleOrder = Order::with('product', 'productionEntry', 'deliveryEntry', 'invoice')
            ->latest()
            ->first();

        return view('site.home', compact('stats', 'sampleOrder'));
    }
}
