<?php

namespace App\Http\Controllers\Site;

use App\Http\Controllers\Controller;
use App\Models\Product;
use Illuminate\Http\Request;

class CatalogController extends Controller
{
    public function index(Request $request)
    {
        $products = Product::query()
            ->when($request->search, fn ($q, $s) => $q->where('name', 'like', "%{$s}%"))
            ->when($request->category, fn ($q, $c) => $q->where('category', $c))
            ->orderBy('name')
            ->paginate(12)
            ->withQueryString();

        $categories = Product::select('category')->distinct()->whereNotNull('category')->pluck('category');

        return view('site.catalog', compact('products', 'categories'));
    }

    public function show(Product $product)
    {
        return view('site.product', compact('product'));
    }
}
