<?php

namespace App\Http\Controllers\Site;

use App\Http\Controllers\Controller;
use App\Modules\CRM\Models\Lead;
use Illuminate\Http\Request;

class StaticPageController extends Controller
{
    public function about()
    {
        return view('site.about');
    }

    public function contact()
    {
        return view('site.contact');
    }

    public function contactSubmit(Request $request)
    {
        $validated = $request->validate([
            'name'    => ['required', 'string', 'max:255'],
            'phone'   => ['nullable', 'string', 'max:50'],
            'email'   => ['nullable', 'email', 'max:255'],
            'message' => ['required', 'string', 'max:2000'],
        ]);

        // Contact form সাবমিট হলেই এটা CRM এ একটা Lead হিসেবে জমা হয়,
        // এবং phone/email/message একটা Activity note হিসেবে সেই Lead-এর
        // সাথে যুক্ত থাকে — admin CRM > Leads থেকে দেখে follow-up করতে পারবে।
        $lead = Lead::create([
            'name'   => $validated['name'],
            'source' => 'website',
            'status' => 'new',
        ]);

        $contactLine = collect([
            $validated['phone'] ?? null,
            $validated['email'] ?? null,
        ])->filter()->implode(' · ');

        $lead->activities()->create([
            'type'       => 'note',
            'notes'      => trim(($contactLine ? "[{$contactLine}]\n" : '') . $validated['message']),
            'created_by' => optional(\App\Models\User::where('role', 'admin')->first())->id
                ?? \App\Models\User::first()?->id,
        ]);

        return back()->with('success', 'আপনার মেসেজ পাঠানো হয়েছে, আমরা শীঘ্রই যোগাযোগ করবো।');
    }
}
