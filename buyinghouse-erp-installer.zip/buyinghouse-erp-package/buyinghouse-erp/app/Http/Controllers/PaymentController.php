<?php

namespace App\Http\Controllers;

use App\Models\AuditLog;
use App\Models\Invoice;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class PaymentController extends Controller
{
    /**
     * AmarPay এর ডকুমেন্টেড JSON POST API সরাসরি কল করা হচ্ছে —
     * কোনো 3rd-party Composer প্যাকেজের উপর নির্ভরতা নেই, তাই
     * "প্যাকেজ আসলে আছে কিনা" এই অনিশ্চয়তা দূর হলো।
     *
     * ⚠️ গুরুত্বপূর্ণ: নিচের endpoint ও field নাম AmarPay এর প্রকাশিত
     * API ডকুমেন্টেশন অনুযায়ী লেখা, কিন্তু আমি নিজে sandbox এ কল করে
     * যাচাই করতে পারিনি (নেটওয়ার্ক নেই)। লাইভে যাওয়ার আগে অবশ্যই
     * sandbox credentials দিয়ে একবার টেস্ট ট্রানজেকশন করে confirm
     * করুন যে field নামগুলো মিলছে। মিলে না গেলে AmarPay এর merchant
     * ড্যাশবোর্ডের API ডকুমেন্ট দেখে ঠিক করে দিন বা আমাকে সেই ডকুমেন্ট
     * পাঠান, আমি সাথে সাথে ঠিক করে দেব।
     */
    public function initiate(Request $request, Invoice $invoice)
    {
        abort_unless($invoice->order->user_id === $request->user()->id, 403);
        abort_if($invoice->payment_status === 'paid', 400, 'এই ইনভয়েস ইতিমধ্যে পরিশোধ করা হয়েছে।');

        $tranId = 'INV' . $invoice->id . '-' . uniqid();
        $currency = $request->query('currency', 'BDT');

        $endpoint = config('aamarpay.sandbox')
            ? 'https://sandbox.aamarpay.com/jsonpost.php'
            : 'https://secure.aamarpay.com/jsonpost.php';

        $payload = [
            'store_id'      => config('aamarpay.store_id'),
            'signature_key' => config('aamarpay.signature_key'),
            'tran_id'       => $tranId,
            'amount'        => (string) $invoice->amount,
            'currency'      => $currency,
            'cus_name'      => $request->user()->name,
            'cus_email'     => $request->user()->email,
            'cus_phone'     => $request->user()->phone ?? '01700000000',
            'cus_add1'      => $request->user()->address ?? 'N/A',
            'desc'          => "Invoice {$invoice->invoice_no}",
            'success_url'   => route('payment.success'),
            'fail_url'      => route('payment.failed'),
            'cancel_url'    => route('payment.cancel'),
            'type'          => 'json',
        ];

        $response = Http::asForm()->post($endpoint, $payload);

        if (! $response->successful()) {
            Log::error('AmarPay initiate failed', ['response' => $response->body()]);
            return back()->with('error', 'পেমেন্ট গেটওয়ে থেকে সাড়া পাওয়া যায়নি, পরে আবার চেষ্টা করুন।');
        }

        $data = $response->json();

        if (empty($data['payment_url'])) {
            Log::error('AmarPay: payment_url missing', ['response' => $data]);
            return back()->with('error', 'পেমেন্ট লিংক তৈরি করা যায়নি।');
        }

        // ট্রানজেকশনটা কোন invoice-এর জন্য তা পরে যাচাই করার জন্য সেভ রাখা
        session(["pending_payment_{$tranId}" => $invoice->id]);

        return redirect()->away($data['payment_url']);
    }

    public function success(Request $request)
    {
        $tranId = $request->input('tran_id') ?? $request->input('mer_txnid');
        $invoice = $this->resolveInvoiceFromTranId($tranId);

        if (! $invoice) {
            Log::warning('AmarPay success callback: invoice not found', $request->all());
            return redirect()->route('orders.index')->with('error', 'পেমেন্ট যাচাই ব্যর্থ হয়েছে।');
        }

        // amount মিলছে কিনা যাচাই — gateway থেকে আসা amount ও invoice amount তুলনা
        $receivedAmount = (float) ($request->input('amount') ?? 0);
        if (round($receivedAmount, 2) !== round((float) $invoice->amount, 2)) {
            Log::warning('AmarPay amount mismatch', [
                'invoice_id' => $invoice->id,
                'expected' => $invoice->amount,
                'received' => $receivedAmount,
            ]);
            return redirect()->route('orders.index')->with('error', 'পেমেন্ট পরিমাণ মিলছে না, সাপোর্টে যোগাযোগ করুন।');
        }

        $invoice->update(['payment_status' => 'paid']);
        AuditLog::record('updated', $invoice, "Invoice {$invoice->invoice_no} পেমেন্ট সম্পন্ন হয়েছে (AmarPay)");

        return redirect()
            ->route('orders.show', $invoice->order)
            ->with('success', 'পেমেন্ট সফল হয়েছে!');
    }

    public function failed(Request $request)
    {
        return redirect()->route('orders.index')->with('error', 'পেমেন্ট ব্যর্থ হয়েছে, আবার চেষ্টা করুন।');
    }

    public function cancel(Request $request)
    {
        return redirect()->route('orders.index')->with('error', 'পেমেন্ট বাতিল করা হয়েছে।');
    }

    private function resolveInvoiceFromTranId(?string $tranId): ?Invoice
    {
        if (! $tranId || ! str_starts_with($tranId, 'INV')) {
            return null;
        }

        $rest = substr($tranId, 3);
        $dashPos = strpos($rest, '-');
        $invoiceId = (int) ($dashPos !== false ? substr($rest, 0, $dashPos) : $rest);

        return Invoice::find($invoiceId);
    }
}
