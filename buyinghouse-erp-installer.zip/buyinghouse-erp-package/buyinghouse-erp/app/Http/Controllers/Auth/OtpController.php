<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Mail\OtpMail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class OtpController extends Controller
{
    public function show(Request $request)
    {
        if (! config('otp.enabled') || $request->user()->hasVerifiedEmail()) {
            return redirect()->intended('/dashboard');
        }

        return view('auth.verify-otp');
    }

    public function resend(Request $request)
    {
        $this->generateAndSend($request->user());

        return back()->with('success', 'নতুন কোড পাঠানো হয়েছে।');
    }

    public function verify(Request $request)
    {
        $validated = $request->validate(['code' => ['required', 'digits:6']]);

        $user = $request->user();

        if (
            $user->otp_code !== $validated['code']
            || ! $user->otp_expires_at
            || now()->greaterThan($user->otp_expires_at)
        ) {
            return back()->withErrors(['code' => 'কোডটি সঠিক নয় অথবা মেয়াদ শেষ হয়ে গেছে।']);
        }

        $user->forceFill([
            'email_verified_at' => now(),
            'otp_code' => null,
            'otp_expires_at' => null,
        ])->save();

        return redirect('/dashboard')->with('success', 'ভেরিফিকেশন সফল হয়েছে!');
    }

    public function generateAndSend($user): void
    {
        $code = (string) random_int(100000, 999999);

        $user->forceFill([
            'otp_code' => $code,
            'otp_expires_at' => now()->addMinutes(config('otp.expiry_minutes')),
        ])->save();

        Mail::to($user->email)->queue(new OtpMail($code));
    }
}
