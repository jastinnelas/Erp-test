<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use PragmaRX\Google2FA\Google2FA;

class TwoFactorController extends Controller
{
    private function engine(): Google2FA
    {
        return new Google2FA();
    }

    /**
     * GET /2fa/setup — QR কোড দেখায় (এখনো enable হয়নি)
     */
    public function setup(Request $request)
    {
        $user = $request->user();
        $engine = $this->engine();

        if (! $user->google2fa_secret) {
            $user->forceFill(['google2fa_secret' => $engine->generateSecretKey()])->save();
        }

        $otpAuthUrl = $engine->getQRCodeUrl(
            config('app.name'),
            $user->email,
            $user->google2fa_secret
        );

        return view('auth.two-factor-setup', compact('otpAuthUrl', 'user'));
    }

    /**
     * POST /2fa/enable — কোড যাচাই করে 2FA চালু করে
     */
    public function enable(Request $request)
    {
        $validated = $request->validate(['code' => ['required', 'digits:6']]);

        $valid = $this->engine()->verifyKey($request->user()->google2fa_secret, $validated['code']);

        if (! $valid) {
            return back()->withErrors(['code' => 'কোডটি সঠিক নয়।']);
        }

        $request->user()->update(['two_factor_enabled' => true]);
        session(['2fa_verified' => true]);

        return redirect('/dashboard')->with('success', '2FA সফলভাবে চালু হয়েছে।');
    }

    /**
     * POST /2fa/disable
     */
    public function disable(Request $request)
    {
        $request->user()->update([
            'two_factor_enabled' => false,
            'google2fa_secret' => null,
        ]);
        session()->forget('2fa_verified');

        return back()->with('success', '2FA বন্ধ করা হয়েছে।');
    }

    /**
     * GET /2fa/challenge — লগইন এর পর কোড চাওয়া হয় (2FA চালু থাকলে)
     */
    public function challenge(Request $request)
    {
        if (! $request->user()->two_factor_enabled || session('2fa_verified')) {
            return redirect()->intended('/dashboard');
        }

        return view('auth.two-factor-challenge');
    }

    public function verifyChallenge(Request $request)
    {
        $validated = $request->validate(['code' => ['required', 'digits:6']]);

        $valid = $this->engine()->verifyKey($request->user()->google2fa_secret, $validated['code']);

        if (! $valid) {
            return back()->withErrors(['code' => 'কোডটি সঠিক নয়।']);
        }

        session(['2fa_verified' => true]);

        return redirect()->intended('/dashboard');
    }
}
