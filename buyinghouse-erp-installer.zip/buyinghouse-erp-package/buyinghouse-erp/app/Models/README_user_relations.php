<?php

// এই ফাইলটা চালানোর জন্য না — নির্দেশনা।
// আপনার app/Models/User.php ক্লাসের ভেতরে নিচের দুটো relation method যোগ করুন:

/*
public function sentMessages()
{
    return $this->hasMany(\App\Models\Message::class, 'sender_id');
}

public function receivedMessages()
{
    return $this->hasMany(\App\Models\Message::class, 'receiver_id');
}
*/
