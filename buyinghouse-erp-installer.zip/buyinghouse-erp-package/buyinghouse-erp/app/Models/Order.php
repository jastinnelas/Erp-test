<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Order extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'order_no', 'user_id', 'product_id', 'quantity',
        'order_date', 'delivery_date', 'status', 'attachment_path',
    ];

    protected $casts = [
        'order_date' => 'date',
        'delivery_date' => 'date',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function product()
    {
        return $this->belongsTo(Product::class);
    }

    public function productionEntry()
    {
        return $this->hasOne(ProductionEntry::class);
    }

    public function deliveryEntry()
    {
        return $this->hasOne(DeliveryEntry::class);
    }

    public function invoice()
    {
        return $this->hasOne(Invoice::class);
    }
}
