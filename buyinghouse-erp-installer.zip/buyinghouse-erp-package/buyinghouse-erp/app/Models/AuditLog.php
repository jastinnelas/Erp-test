<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AuditLog extends Model
{
    protected $fillable = [
        'user_id', 'action', 'model_type', 'model_id',
        'description', 'old_values', 'new_values',
    ];

    protected $casts = [
        'old_values' => 'array',
        'new_values' => 'array',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * ব্যবহার: AuditLog::record('status_changed', $order, "Order marked as delivered", ['status' => 'in_production'], ['status' => 'delivered']);
     */
    public static function record(string $action, Model $model, string $description, ?array $old = null, ?array $new = null): void
    {
        static::create([
            'user_id' => request()->user()?->id,
            'action' => $action,
            'model_type' => class_basename($model),
            'model_id' => $model->getKey(),
            'description' => $description,
            'old_values' => $old,
            'new_values' => $new,
        ]);
    }
}
