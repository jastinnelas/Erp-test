<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DeliveryEntry extends Model
{
    use HasFactory;

    protected $fillable = [
        'order_id', 'courier', 'tracking_no', 'delivery_address', 'status',
    ];

    public function order()
    {
        return $this->belongsTo(Order::class);
    }
}
