<?php

namespace App\Modules\Sample\Models;

use App\Models\Order;
use App\Models\Product;
use App\Models\User;
use Illuminate\Database\Eloquent\Model;

class Sample extends Model
{
    protected $fillable = [
        'product_id', 'order_id', 'stage', 'requested_by', 'sent_at', 'feedback',
    ];

    protected $casts = [
        'sent_at' => 'datetime',
    ];

    public function product()
    {
        return $this->belongsTo(Product::class);
    }

    public function order()
    {
        return $this->belongsTo(Order::class);
    }

    public function requestedBy()
    {
        return $this->belongsTo(User::class, 'requested_by');
    }
}
