<?php

namespace App\Modules\Sample\Controllers;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Models\Order;
use App\Models\Product;
use App\Modules\Sample\Models\Sample;
use Illuminate\Http\Request;

class SampleController extends Controller
{
    private const STAGES = [
        'requested', 'proto', 'fit', 'size_set', 'pp_sample', 'sent', 'approved', 'rejected',
    ];

    public function index(Request $request)
    {
        $samples = Sample::with('product', 'order', 'requestedBy')
            ->when($request->stage, fn ($q, $s) => $q->where('stage', $s))
            ->latest()
            ->paginate(15);

        return view('modules.sample.index', ['samples' => $samples, 'stages' => self::STAGES]);
    }

    public function create()
    {
        $products = Product::orderBy('name')->get();
        $orders = Order::whereDoesntHave('productionEntry')->with('product', 'user')->latest()->get();

        return view('modules.sample.create', compact('products', 'orders'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'product_id' => ['nullable', 'exists:products,id'],
            'order_id'   => ['nullable', 'exists:orders,id'],
        ]);

        $validated['requested_by'] = $request->user()->id;
        $validated['stage'] = 'requested';

        $sample = Sample::create($validated);
        AuditLog::record('created', $sample, "Sample requested (#{$sample->id})");

        return redirect()->route('admin.sample.show', $sample)->with('success', 'Sample request created.');
    }

    public function show(Sample $sample)
    {
        $sample->load('product', 'order', 'requestedBy');

        return view('modules.sample.show', ['sample' => $sample, 'stages' => self::STAGES]);
    }

    public function updateStage(Request $request, Sample $sample)
    {
        $validated = $request->validate([
            'stage'    => ['required', 'in:' . implode(',', self::STAGES)],
            'feedback' => ['nullable', 'string', 'max:2000'],
        ]);

        $oldStage = $sample->stage;

        $sample->fill($validated);
        if ($validated['stage'] === 'sent' && ! $sample->sent_at) {
            $sample->sent_at = now();
        }
        $sample->save();

        AuditLog::record(
            'status_changed',
            $sample,
            "Sample #{$sample->id} moved {$oldStage} → {$sample->stage}"
        );

        return redirect()->route('admin.sample.show', $sample)->with('success', 'Sample stage updated.');
    }
}
