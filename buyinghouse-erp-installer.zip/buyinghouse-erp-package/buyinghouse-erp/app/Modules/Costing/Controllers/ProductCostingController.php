<?php

namespace App\Modules\Costing\Controllers;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Models\Product;
use App\Modules\Costing\Models\ProductCosting;
use Illuminate\Http\Request;

class ProductCostingController extends Controller
{
    public function index()
    {
        $costings = ProductCosting::with('product', 'approver')->latest()->paginate(15);

        return view('modules.costing.index', compact('costings'));
    }

    public function create()
    {
        $products = Product::orderBy('name')->get();

        return view('modules.costing.create', compact('products'));
    }

    private function costRules(): array
    {
        return [
            'product_id'       => ['required', 'exists:products,id'],
            'fabric_cost'      => ['required', 'numeric', 'min:0'],
            'trims_cost'       => ['required', 'numeric', 'min:0'],
            'cm_cost'          => ['required', 'numeric', 'min:0'],
            'washing_cost'     => ['nullable', 'numeric', 'min:0'],
            'printing_cost'    => ['nullable', 'numeric', 'min:0'],
            'packaging_cost'   => ['nullable', 'numeric', 'min:0'],
            'freight_cost'     => ['nullable', 'numeric', 'min:0'],
            'commission_cost'  => ['nullable', 'numeric', 'min:0'],
            'other_cost'       => ['nullable', 'numeric', 'min:0'],
            'margin_percent'   => ['required', 'numeric', 'min:0', 'max:500'],
        ];
    }

    public function store(Request $request)
    {
        $validated = $request->validate($this->costRules());

        $latestVersion = ProductCosting::where('product_id', $validated['product_id'])->max('version') ?? 0;
        $validated['version'] = $latestVersion + 1;
        $validated['status'] = 'draft';

        $costing = new ProductCosting($validated);
        $costing->selling_price = $costing->calculateSellingPrice();
        $costing->save();

        AuditLog::record('created', $costing, "Costing v{$costing->version} drafted for {$costing->product->name}");

        return redirect()->route('admin.costing.show', $costing)->with('success', 'Costing draft created.');
    }

    public function show(ProductCosting $costing)
    {
        $costing->load('product', 'approver');

        return view('modules.costing.show', compact('costing'));
    }

    public function edit(ProductCosting $costing)
    {
        abort_if($costing->status === 'approved', 400, 'Approved costing এডিট করা যায় না — নতুন version বানান।');
        $products = Product::orderBy('name')->get();

        return view('modules.costing.edit', compact('costing', 'products'));
    }

    public function update(Request $request, ProductCosting $costing)
    {
        abort_if($costing->status === 'approved', 400, 'Approved costing এডিট করা যায় না — নতুন version বানান।');

        $rules = $this->costRules();
        unset($rules['product_id']); // product পরিবর্তন করা যাবে না, নতুন version বানাতে হবে

        $validated = $request->validate($rules);
        $costing->fill($validated);
        $costing->selling_price = $costing->calculateSellingPrice();
        $costing->save();

        return redirect()->route('admin.costing.show', $costing)->with('success', 'Costing updated.');
    }

    public function approve(Request $request, ProductCosting $costing)
    {
        $costing->update([
            'status'      => 'approved',
            'approved_by' => $request->user()->id,
            'approved_at' => now(),
        ]);

        AuditLog::record('status_changed', $costing, "Costing v{$costing->version} approved for {$costing->product->name}");

        return back()->with('success', 'Costing approved.');
    }
}
