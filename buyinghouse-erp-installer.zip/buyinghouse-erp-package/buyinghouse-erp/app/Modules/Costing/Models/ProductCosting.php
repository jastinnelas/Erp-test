<?php

namespace App\Modules\Costing\Models;

use App\Models\Product;
use App\Models\User;
use Illuminate\Database\Eloquent\Model;

class ProductCosting extends Model
{
    protected $fillable = [
        'product_id', 'version', 'fabric_cost', 'trims_cost', 'cm_cost',
        'washing_cost', 'printing_cost', 'packaging_cost', 'freight_cost',
        'commission_cost', 'other_cost', 'margin_percent', 'selling_price',
        'status', 'approved_by', 'approved_at',
    ];

    protected $casts = [
        'approved_at' => 'datetime',
    ];

    public function product()
    {
        return $this->belongsTo(Product::class);
    }

    public function approver()
    {
        return $this->belongsTo(User::class, 'approved_by');
    }

    /**
     * সব খরচের যোগফল (selling price বাদে)
     */
    public function totalCost(): float
    {
        return (float) $this->fabric_cost
            + (float) $this->trims_cost
            + (float) $this->cm_cost
            + (float) $this->washing_cost
            + (float) $this->printing_cost
            + (float) $this->packaging_cost
            + (float) $this->freight_cost
            + (float) $this->commission_cost
            + (float) $this->other_cost;
    }

    /**
     * margin_percent অনুযায়ী selling price বের করে (কিন্তু সেভ করে না —
     * controller স্পষ্টভাবে save() করবে, যাতে পরিবর্তনটা explicit থাকে)
     */
    public function calculateSellingPrice(): float
    {
        $cost = $this->totalCost();

        return round($cost + ($cost * (float) $this->margin_percent / 100), 2);
    }
}
