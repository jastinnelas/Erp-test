<?php

namespace App\Modules\CRM\Models;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;

class BuyerProfile extends Model
{
    protected $fillable = [
        'user_id', 'company_name', 'country', 'currency',
        'payment_terms', 'shipping_terms',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
