<?php

namespace App\Modules\CRM\Models;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;

class Activity extends Model
{
    protected $fillable = [
        'subject_type', 'subject_id', 'type', 'notes', 'due_at', 'done', 'created_by',
    ];

    protected $casts = [
        'due_at' => 'datetime',
        'done' => 'boolean',
    ];

    public function subject()
    {
        return $this->morphTo();
    }

    public function creator()
    {
        return $this->belongsTo(User::class, 'created_by');
    }
}
