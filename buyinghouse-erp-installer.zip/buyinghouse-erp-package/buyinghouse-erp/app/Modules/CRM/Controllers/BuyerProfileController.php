<?php

namespace App\Modules\CRM\Controllers;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Modules\CRM\Models\BuyerProfile;
use Illuminate\Http\Request;

class BuyerProfileController extends Controller
{
    public function index()
    {
        $buyers = User::where('role', 'customer')
            ->with('buyerProfile')
            ->latest()
            ->paginate(15);

        return view('modules.crm.buyers.index', compact('buyers'));
    }

    public function edit(User $user)
    {
        abort_unless($user->role === 'customer', 404);
        $profile = $user->buyerProfile;

        return view('modules.crm.buyers.edit', compact('user', 'profile'));
    }

    public function update(Request $request, User $user)
    {
        abort_unless($user->role === 'customer', 404);

        $validated = $request->validate([
            'company_name'    => ['required', 'string', 'max:255'],
            'country'         => ['nullable', 'string', 'max:100'],
            'currency'        => ['required', 'string', 'max:10'],
            'payment_terms'   => ['nullable', 'string', 'max:255'],
            'shipping_terms'  => ['nullable', 'string', 'max:255'],
        ]);

        BuyerProfile::updateOrCreate(['user_id' => $user->id], $validated);

        return redirect()->route('admin.crm.buyers.index')->with('success', 'Buyer profile saved.');
    }
}
