<?php

namespace App\Modules\CRM\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\CRM\Models\Lead;
use Illuminate\Http\Request;

class LeadController extends Controller
{
    public function index(Request $request)
    {
        $leads = Lead::with('assignedTo')
            ->when($request->status, fn ($q, $s) => $q->where('status', $s))
            ->latest()
            ->paginate(15);

        return view('modules.crm.leads.index', compact('leads'));
    }

    public function create()
    {
        return view('modules.crm.leads.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name'    => ['required', 'string', 'max:255'],
            'company' => ['nullable', 'string', 'max:255'],
            'source'  => ['nullable', 'string', 'max:100'],
        ]);

        $validated['assigned_to'] = $request->user()->id;

        Lead::create($validated);

        return redirect()->route('admin.crm.leads.index')->with('success', 'Lead added.');
    }

    public function show(Lead $lead)
    {
        $lead->load('activities.creator', 'assignedTo');

        return view('modules.crm.leads.show', compact('lead'));
    }

    public function edit(Lead $lead)
    {
        return view('modules.crm.leads.edit', compact('lead'));
    }

    public function update(Request $request, Lead $lead)
    {
        $validated = $request->validate([
            'name'    => ['required', 'string', 'max:255'],
            'company' => ['nullable', 'string', 'max:255'],
            'source'  => ['nullable', 'string', 'max:100'],
            'status'  => ['required', 'in:new,contacted,qualified,won,lost'],
        ]);

        $lead->update($validated);

        return redirect()->route('admin.crm.leads.show', $lead)->with('success', 'Lead updated.');
    }

    public function destroy(Lead $lead)
    {
        $lead->delete();

        return redirect()->route('admin.crm.leads.index')->with('success', 'Lead removed.');
    }
}
