<?php

namespace App\Modules\CRM\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\CRM\Models\Activity;
use App\Modules\CRM\Models\Lead;
use Illuminate\Http\Request;

class ActivityController extends Controller
{
    public function store(Request $request, Lead $lead)
    {
        $validated = $request->validate([
            'type'   => ['required', 'in:call,email,meeting,note'],
            'notes'  => ['nullable', 'string', 'max:2000'],
            'due_at' => ['nullable', 'date'],
        ]);

        $lead->activities()->create($validated + [
            'created_by' => $request->user()->id,
        ]);

        return redirect()->route('admin.crm.leads.show', $lead)->with('success', 'Activity logged.');
    }

    public function toggleDone(Activity $activity)
    {
        $activity->update(['done' => ! $activity->done]);

        return back()->with('success', 'Activity updated.');
    }
}
