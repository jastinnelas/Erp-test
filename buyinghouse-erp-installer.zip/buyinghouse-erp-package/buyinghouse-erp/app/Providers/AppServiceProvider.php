<?php

namespace App\Providers;

use Illuminate\Support\Facades\URL;
use Illuminate\Support\ServiceProvider;
use Illuminate\Database\Eloquent\Relations\Relation;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        // subject_type কলামে পুরো namespace এর বদলে ছোট নাম (Lead/User) সংরক্ষণ করতে
        Relation::morphMap([
            'Lead' => \App\Modules\CRM\Models\Lead::class,
            'User' => \App\Models\User::class,
        ]);

        // Production এ সব জেনারেট হওয়া URL জোর করে https:// দিয়ে শুরু হবে
        // (Railway এর মতো hosting নিজে থেকেই SSL দেয়, কিন্তু Laravel-generated
        // link/redirect যাতে ভুলবশত http:// না হয়ে যায় তা নিশ্চিত করে)
        if ($this->app->environment('production')) {
            URL::forceScheme('https');
        }
    }
}
