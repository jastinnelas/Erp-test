<?php

namespace App\Listeners;

use App\Http\Controllers\Auth\OtpController;
use Illuminate\Auth\Events\Registered;

class SendOtpOnRegistration
{
    public function handle(Registered $event): void
    {
        if (config('otp.enabled')) {
            app(OtpController::class)->generateAndSend($event->user);
        }
    }
}
