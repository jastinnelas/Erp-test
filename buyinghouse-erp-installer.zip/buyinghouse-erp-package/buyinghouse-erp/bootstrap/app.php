<?php

use App\Http\Middleware\EnsureOtpVerified;
use App\Http\Middleware\EnsureTwoFactorVerified;
use App\Http\Middleware\EnsureUserHasRole;
use App\Http\Middleware\SecurityHeaders;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Http\Request;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->alias([
            'role' => EnsureUserHasRole::class,
            'otp'  => EnsureOtpVerified::class,
            '2fa'  => EnsureTwoFactorVerified::class,
        ]);

        $middleware->web(append: [
            SecurityHeaders::class,
        ]);

        // AmarPay গেটওয়ে আমাদের ডোমেইনের বাইরে থেকে payment/* এ POST করে
        // ফিরে আসে, তাই সেই রুটগুলোকে CSRF চেক থেকে বাদ দেওয়া বাধ্যতামূলক।
        $middleware->validateCsrfTokens(except: [
            'payment/*',
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        $exceptions->shouldRenderJsonWhen(
            fn (Request $request) => $request->is('api/*') || $request->expectsJson(),
        );
    })->create();
