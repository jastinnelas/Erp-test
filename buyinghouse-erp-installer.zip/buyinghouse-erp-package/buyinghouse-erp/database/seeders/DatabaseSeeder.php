<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            UserSeeder::class,
            ProductSupplierSeeder::class,
            OrderPipelineSeeder::class,
        ]);

        $this->command->info('Seeding complete: admin@buyinghouse.test / password');
    }
}
