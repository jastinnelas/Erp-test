<?php

namespace Database\Seeders;

use App\Models\Product;
use App\Models\Supplier;
use Illuminate\Database\Seeder;

class ProductSupplierSeeder extends Seeder
{
    public function run(): void
    {
        $suppliers = [
            ['name' => 'Apex Textile Ltd.', 'contact' => '01711223344', 'rating' => 5],
            ['name' => 'Nova Apparel Group', 'contact' => '01822334455', 'rating' => 4],
            ['name' => 'Orion Sourcing', 'contact' => '01933445566', 'rating' => 4],
            ['name' => 'Urban Stitch Co.', 'contact' => '01644556677', 'rating' => 3],
        ];

        foreach ($suppliers as $supplier) {
            Supplier::create($supplier);
        }

        $products = [
            ['item_code' => 'PTX-7891', 'name' => 'Premium Piqué Polo', 'category' => 'Fashion', 'color' => 'Navy', 'size' => 'M', 'unit_price' => 480],
            ['item_code' => 'RSH-2201', 'name' => 'Running Shoes', 'category' => 'Sports', 'color' => 'Red', 'size' => '42', 'unit_price' => 2200],
            ['item_code' => 'WJK-3310', 'name' => 'Winter Jacket', 'category' => 'Winter', 'color' => 'Charcoal', 'size' => 'XL', 'unit_price' => 4000],
            ['item_code' => 'STH-9912', 'name' => 'Stylish Hoodie', 'category' => 'Casual', 'color' => 'Grey', 'size' => 'L', 'unit_price' => 3000],
            ['item_code' => 'TRS-2215', 'name' => 'Chino Trouser', 'category' => 'Fashion', 'color' => 'Khaki', 'size' => '32', 'unit_price' => 725],
        ];

        foreach ($products as $product) {
            Product::create($product);
        }
    }
}
