<?php

namespace Database\Seeders;

use App\Models\DeliveryEntry;
use App\Models\Invoice;
use App\Models\Order;
use App\Models\Product;
use App\Models\ProductionEntry;
use App\Models\Supplier;
use App\Models\User;
use Illuminate\Database\Seeder;

class OrderPipelineSeeder extends Seeder
{
    public function run(): void
    {
        $customers = User::where('role', 'customer')->get();
        $products = Product::all();
        $suppliers = Supplier::all();

        if ($customers->isEmpty() || $products->isEmpty()) {
            $this->command->warn('Run UserSeeder and ProductSupplierSeeder first.');
            return;
        }

        // ১. পুরো চেইন শেষ হওয়া অর্ডার (order -> production -> delivery -> invoice)
        for ($i = 1; $i <= 4; $i++) {
            $order = Order::create([
                'order_no'   => 'ORD-' . now()->format('Y') . '-' . str_pad($i, 5, '0', STR_PAD_LEFT),
                'user_id'    => $customers->random()->id,
                'product_id' => $products->random()->id,
                'quantity'   => fake()->numberBetween(100, 2000),
                'order_date' => now()->subDays(fake()->numberBetween(15, 30)),
                'delivery_date' => now()->subDays(fake()->numberBetween(1, 10)),
                'status'     => 'delivered',
            ]);

            ProductionEntry::create([
                'order_id' => $order->id,
                'supplier_id' => $suppliers->random()->id,
                'stage' => 'completed',
                'start_time' => $order->order_date->addDay(),
                'finish_time' => $order->order_date->addDays(6),
                'remarks' => 'Completed on time',
            ]);

            DeliveryEntry::create([
                'order_id' => $order->id,
                'courier' => fake()->randomElement(['Pathao', 'Steadfast', 'RedX']),
                'tracking_no' => strtoupper(fake()->bothify('TRK-####??')),
                'delivery_address' => fake()->address(),
                'status' => 'delivered',
            ]);

            Invoice::create([
                'invoice_no' => 'INV-' . now()->format('Y') . '-' . str_pad($i, 4, '0', STR_PAD_LEFT),
                'order_id' => $order->id,
                'amount' => $order->quantity * $order->product->unit_price,
                'payment_status' => fake()->randomElement(['paid', 'paid', 'pending']),
                'issue_date' => $order->delivery_date,
                'due_date' => $order->delivery_date->addDays(15),
            ]);
        }

        // ২. প্রোডাকশনে আছে, এখনো ডেলিভার হয়নি
        for ($i = 5; $i <= 7; $i++) {
            $order = Order::create([
                'order_no'   => 'ORD-' . now()->format('Y') . '-' . str_pad($i, 5, '0', STR_PAD_LEFT),
                'user_id'    => $customers->random()->id,
                'product_id' => $products->random()->id,
                'quantity'   => fake()->numberBetween(100, 1500),
                'order_date' => now()->subDays(fake()->numberBetween(3, 10)),
                'status'     => 'in_production',
            ]);

            ProductionEntry::create([
                'order_id' => $order->id,
                'supplier_id' => $suppliers->random()->id,
                'stage' => fake()->randomElement(['in_production', 'quality_check']),
                'start_time' => $order->order_date->addDay(),
                'remarks' => 'On schedule',
            ]);
        }

        // ৩. একদম নতুন, প্রোডাকশনে যায়নি
        for ($i = 8; $i <= 10; $i++) {
            Order::create([
                'order_no'   => 'ORD-' . now()->format('Y') . '-' . str_pad($i, 5, '0', STR_PAD_LEFT),
                'user_id'    => $customers->random()->id,
                'product_id' => $products->random()->id,
                'quantity'   => fake()->numberBetween(100, 800),
                'order_date' => now()->subDays(fake()->numberBetween(0, 2)),
                'status'     => 'pending',
            ]);
        }
    }
}
