<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    public function run(): void
    {
        User::create([
            'name' => 'Admin User',
            'email' => 'admin@buyinghouse.test',
            'password' => 'password',
            'role' => 'admin',
            'email_verified_at' => now(),
        ]);

        $customers = [
            ['name' => 'ABC Industries', 'email' => 'abc@example.com'],
            ['name' => 'XYZ Corporation', 'email' => 'xyz@example.com'],
            ['name' => 'PQR Enterprises', 'email' => 'pqr@example.com'],
            ['name' => 'LMN Solutions', 'email' => 'lmn@example.com'],
            ['name' => 'Techno Pvt Ltd', 'email' => 'techno@example.com'],
        ];

        foreach ($customers as $customer) {
            User::create([
                'name' => $customer['name'],
                'email' => $customer['email'],
                'password' => 'password',
                'role' => 'customer',
                'email_verified_at' => now(),
            ]);
        }
    }
}
