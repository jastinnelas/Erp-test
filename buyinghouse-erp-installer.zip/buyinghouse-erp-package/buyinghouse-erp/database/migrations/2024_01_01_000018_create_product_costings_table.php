<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('product_costings', function (Blueprint $table) {
            $table->id();
            $table->foreignId('product_id')->constrained()->cascadeOnDelete();
            $table->unsignedInteger('version')->default(1);
            $table->decimal('fabric_cost', 12, 2)->default(0);
            $table->decimal('trims_cost', 12, 2)->default(0);
            $table->decimal('cm_cost', 12, 2)->default(0); // cut-and-make labor cost
            $table->decimal('washing_cost', 12, 2)->default(0);
            $table->decimal('printing_cost', 12, 2)->default(0);
            $table->decimal('packaging_cost', 12, 2)->default(0);
            $table->decimal('freight_cost', 12, 2)->default(0);
            $table->decimal('commission_cost', 12, 2)->default(0);
            $table->decimal('other_cost', 12, 2)->default(0);
            $table->decimal('margin_percent', 5, 2)->default(0);
            $table->decimal('selling_price', 12, 2)->default(0); // computed & stored
            $table->string('status')->default('draft'); // draft | approved
            $table->foreignId('approved_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('approved_at')->nullable();
            $table->timestamps();

            $table->unique(['product_id', 'version']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('product_costings');
    }
};
