<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('products', function (Blueprint $table) {
            $table->string('image_path')->nullable()->after('unit_price');
        });

        Schema::table('orders', function (Blueprint $table) {
            $table->string('attachment_path')->nullable()->after('status');
        });
    }

    public function down(): void
    {
        Schema::table('products', fn (Blueprint $table) => $table->dropColumn('image_path'));
        Schema::table('orders', fn (Blueprint $table) => $table->dropColumn('attachment_path'));
    }
};
