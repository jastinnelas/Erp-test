<?php

use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\OrderApiController;
use App\Http\Controllers\Api\ProductApiController;
use Illuminate\Support\Facades\Route;

// ============================================================
// এই ফাইলটা routes/api.php এর নিচে একটা require লাইন দিয়ে
// যোগ হয়ে যাবে install.sh স্বয়ংক্রিয়ভাবে করে দেয়।
// টেস্ট করতে Postman/curl দিয়ে POST /api/login কল করুন প্রথমে,
// তারপর পাওয়া token টা "Authorization: Bearer <token>" header
// এ বসিয়ে বাকি রুটগুলো কল করুন।
// ============================================================

Route::post('/login', [AuthController::class, 'login'])->middleware('throttle:5,1');

Route::get('/products', [ProductApiController::class, 'index']);
Route::get('/products/{product}', [ProductApiController::class, 'show']);

Route::middleware('auth:sanctum')->group(function () {
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::get('/me', [AuthController::class, 'me']);

    Route::get('/orders', [OrderApiController::class, 'index']);
    Route::get('/orders/{order}', [OrderApiController::class, 'show']);
    Route::post('/orders', [OrderApiController::class, 'store']);
});
