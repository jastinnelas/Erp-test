<?php

use App\Http\Controllers\Admin\AuditLogController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\DeliveryEntryController;
use App\Http\Controllers\Admin\ExportController;
use App\Http\Controllers\Admin\InventoryController;
use App\Http\Controllers\Admin\InvoiceController;
use App\Http\Controllers\Admin\ProductController;
use App\Http\Controllers\Admin\ProductionEntryController;
use App\Http\Controllers\Admin\SupplierController;
use App\Http\Controllers\Auth\OtpController;
use App\Http\Controllers\Auth\TwoFactorController;
use App\Http\Controllers\MessageController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\Site\CatalogController;
use App\Http\Controllers\Site\HomeController;
use App\Http\Controllers\Site\StaticPageController;
use App\Http\Controllers\Site\TrackController;
use App\Modules\CRM\Controllers\ActivityController;
use App\Modules\CRM\Controllers\BuyerProfileController;
use App\Modules\CRM\Controllers\LeadController;
use App\Modules\Costing\Controllers\ProductCostingController;
use App\Modules\Sample\Controllers\SampleController;
use Illuminate\Support\Facades\Route;

// ============================================================
// এই ফাইলটা routes/web.php তে যোগ করার দরকার নেই আলাদা করে।
// শুধু routes/web.php এর একদম শেষে এই একটা লাইন যোগ করুন:
//
//     require __DIR__.'/erp.php';
//
// এতে সব module এর route একসাথে লোড হবে, কোনো duplicate
// "use" স্টেটমেন্ট সমস্যা হবে না, কারণ এই ফাইলে "use" শুধু
// একবারই লেখা আছে।
// ============================================================

// ============================================================
// পাবলিক পেজ (BuyingCore ব্র্যান্ডেড মার্কেটিং সাইট) — লগইন লাগে না
// ============================================================
Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/catalog', [CatalogController::class, 'index'])->name('catalog.index');
Route::get('/catalog/{product}', [CatalogController::class, 'show'])->name('catalog.show');
Route::get('/track', [TrackController::class, 'show'])->name('track.show');
Route::get('/about', [StaticPageController::class, 'about'])->name('about');
Route::get('/contact', [StaticPageController::class, 'contact'])->name('contact');
Route::post('/contact', [StaticPageController::class, 'contactSubmit'])->name('contact.submit');

Route::middleware(['auth', 'otp', '2fa'])->group(function () {
    Route::get('/otp/verify', [OtpController::class, 'show'])->name('otp.show');
    Route::post('/otp/verify', [OtpController::class, 'verify'])->name('otp.verify');
    Route::post('/otp/resend', [OtpController::class, 'resend'])->name('otp.resend');

    Route::get('/2fa/setup', [TwoFactorController::class, 'setup'])->name('two-factor.setup');
    Route::post('/2fa/enable', [TwoFactorController::class, 'enable'])->name('two-factor.enable');
    Route::post('/2fa/disable', [TwoFactorController::class, 'disable'])->name('two-factor.disable');
    Route::get('/2fa/challenge', [TwoFactorController::class, 'challenge'])->name('two-factor.challenge');
    Route::post('/2fa/challenge', [TwoFactorController::class, 'verifyChallenge'])->name('two-factor.verify');

    Route::resource('orders', OrderController::class);

    Route::get('/messages', [MessageController::class, 'index'])->name('messages.index');
    Route::get('/messages/{user}', [MessageController::class, 'show'])->name('messages.show');
    Route::post('/messages/{user}', [MessageController::class, 'store'])->name('messages.store');

    Route::get('/pay/invoice/{invoice}', [PaymentController::class, 'initiate'])->name('payment.initiate');
});

// AmarPay গেটওয়ে থেকে POST হয়ে ফিরে আসে — auth middleware এর বাইরে,
// কারণ ব্যবহারকারীর ব্রাউজার session cookie ছাড়াই ফিরে আসতে পারে।
Route::post('/payment/success', [PaymentController::class, 'success'])->name('payment.success');
Route::post('/payment/failed', [PaymentController::class, 'failed'])->name('payment.failed');
Route::post('/payment/cancel', [PaymentController::class, 'cancel'])->name('payment.cancel');

Route::middleware(['auth', 'otp', '2fa', 'role:admin'])
    ->prefix('admin')
    ->name('admin.')
    ->group(function () {
        Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

        Route::resource('production', ProductionEntryController::class)->except(['show']);
        Route::resource('delivery', DeliveryEntryController::class)->except(['show']);
        Route::resource('invoices', InvoiceController::class);
        Route::get('/invoices/{invoice}/pdf', [InvoiceController::class, 'downloadPdf'])->name('invoices.pdf');
        Route::resource('suppliers', SupplierController::class)->except(['show']);
        Route::resource('inventory', InventoryController::class)->except(['show']);
        Route::resource('products', ProductController::class)->except(['show']);
        Route::get('/audit-logs', [AuditLogController::class, 'index'])->name('audit-logs.index');
        Route::get('/export/orders', [ExportController::class, 'orders'])->name('export.orders');
        Route::get('/export/invoices', [ExportController::class, 'invoices'])->name('export.invoices');

        // ==== Phase 2 — CRM ====
        Route::prefix('crm')->name('crm.')->group(function () {
            Route::resource('leads', LeadController::class);
            Route::post('leads/{lead}/activities', [ActivityController::class, 'store'])->name('leads.activities.store');
            Route::post('activities/{activity}/toggle-done', [ActivityController::class, 'toggleDone'])->name('activities.toggle-done');

            Route::get('buyers', [BuyerProfileController::class, 'index'])->name('buyers.index');
            Route::get('buyers/{user}/edit', [BuyerProfileController::class, 'edit'])->name('buyers.edit');
            Route::put('buyers/{user}', [BuyerProfileController::class, 'update'])->name('buyers.update');
        });

        // ==== Phase 2 — Costing ====
        Route::prefix('costing')->name('costing.')->group(function () {
            Route::get('/', [ProductCostingController::class, 'index'])->name('index');
            Route::get('/create', [ProductCostingController::class, 'create'])->name('create');
            Route::post('/', [ProductCostingController::class, 'store'])->name('store');
            Route::get('/{costing}', [ProductCostingController::class, 'show'])->name('show');
            Route::get('/{costing}/edit', [ProductCostingController::class, 'edit'])->name('edit');
            Route::put('/{costing}', [ProductCostingController::class, 'update'])->name('update');
            Route::post('/{costing}/approve', [ProductCostingController::class, 'approve'])->name('approve');
        });

        // ==== Phase 2 — Sample ====
        Route::prefix('sample')->name('sample.')->group(function () {
            Route::get('/', [SampleController::class, 'index'])->name('index');
            Route::get('/create', [SampleController::class, 'create'])->name('create');
            Route::post('/', [SampleController::class, 'store'])->name('store');
            Route::get('/{sample}', [SampleController::class, 'show'])->name('show');
            Route::put('/{sample}/stage', [SampleController::class, 'updateStage'])->name('update-stage');
        });
    });
