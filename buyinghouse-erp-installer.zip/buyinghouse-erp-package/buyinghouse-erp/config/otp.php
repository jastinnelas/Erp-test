<?php

return [
    // .env এ OTP_ENABLED=true করলেই registration এর পর OTP verification বাধ্যতামূলক হবে।
    // false থাকলে সিস্টেম আগের মতোই কাজ করবে (কোনো OTP লাগবে না)।
    'enabled' => env('OTP_ENABLED', false),

    'expiry_minutes' => env('OTP_EXPIRY_MINUTES', 10),
];
