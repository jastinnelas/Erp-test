<?php

return [
    // AmarPay মার্চেন্ট ড্যাশবোর্ড থেকে পাওয়া তথ্য — .env এ বসান
    'store_id' => env('AAMARPAY_STORE_ID', ''),
    'signature_key' => env('AAMARPAY_SIGNATURE_KEY', ''),

    // true = sandbox/test মোড (আসল টাকা কাটবে না), লাইভে যেতে false করুন
    'sandbox' => env('AAMARPAY_SANDBOX', true),

    'redirect_url' => [
        'success' => ['route' => 'payment.success'],
        'cancel' => ['route' => 'payment.cancel'],
    ],
];
