# Buying House ERP — Laravel Starter Kit (v2 — simplified)

## এই ভার্সনে যা ঠিক করা হয়েছে
- Seeder এর ডাবল-হ্যাশ বাগ ফিক্স (password এখন সঠিকভাবে সেভ হবে)
- ৩টা আলাদা route ফাইলের বদলে **একটাই `routes/erp.php`** — duplicate
  `use` স্টেটমেন্ট সমস্যা আর হবে না
- `bootstrap/app.php` এবং `app/Models/User.php` — এখন **সম্পূর্ণ
  replacement ফাইল**, python দিয়ে প্যাচ করা লাগবে না, শুধু overwrite
  করলেই হবে

## সেটআপ ধাপ (Termux বা যেকোনো টার্মিনাল)

```bash
composer create-project laravel/laravel buyinghouse-erp --no-interaction
cd buyinghouse-erp
composer require laravel/breeze --dev --no-interaction
php artisan breeze:install blade --no-interaction
npm install && npm run build
```

এই zip এর ফাইলগুলো এখন **overwrite করে বসিয়ে দিন** (নিজের প্রজেক্ট রুট থেকে):

```bash
cp -f /path/to/buyinghouse-erp/app/Models/*.php app/Models/
cp -rf /path/to/buyinghouse-erp/app/Http/Controllers/* app/Http/Controllers/
mkdir -p app/Http/Middleware
cp -f /path/to/buyinghouse-erp/app/Http/Middleware/*.php app/Http/Middleware/
cp -f /path/to/buyinghouse-erp/database/migrations/*.php database/migrations/
cp -f /path/to/buyinghouse-erp/database/seeders/*.php database/seeders/
cp -rf /path/to/buyinghouse-erp/resources/views/* resources/views/
cp -f /path/to/buyinghouse-erp/routes/erp.php routes/erp.php
cp -f /path/to/buyinghouse-erp/bootstrap/app.php bootstrap/app.php
```

`routes/web.php` এর **একদম শেষে** এই একটা লাইন যোগ করুন:
```bash
echo "" >> routes/web.php
echo "require __DIR__.'/erp.php';" >> routes/web.php
```

ডাটাবেস (SQLite দিয়ে সহজ):
```bash
touch database/database.sqlite
```
`.env` এ:
```
DB_CONNECTION=sqlite
```
(`DB_HOST`, `DB_PORT`, `DB_DATABASE`, `DB_USERNAME`, `DB_PASSWORD` লাইনগুলো মুছে দিন বা কমেন্ট করুন)

তারপর:
```bash
php artisan key:generate
composer dump-autoload
php artisan migrate:fresh --seed --force
php artisan serve
```

**Demo login:**
- Admin: `admin@buyinghouse.test` / `password` → `/admin/dashboard`
- Customer: `abc@example.com` / `password` → `/orders`
